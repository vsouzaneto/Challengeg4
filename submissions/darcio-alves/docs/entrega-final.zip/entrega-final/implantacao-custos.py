"""Estratégia de implantação (v22): custo, prazo e payback em 3 cenários.

PREMISSA DE APRESENTAÇÃO DO CASE (não vem dos dados): a empresa já tem um sistema de gestão de
chamados, e os canais (social media, chat, e-mail e telefone) já estão integrados a ele. O projeto
implementa as Recomendações 1-13 e o Mapa de automação da submissão. Não há compra de helpdesk,
nem integração de canais, nem desenvolvimento de plataforma do zero.

Ganhos (h/ano) vêm da seção 5 da submissão (v11+), valorados a R$ 60/h, para 30 mil chamados/ano.
"""
import json
ENC = 1.70      # custo CLT total / salário (Lucro Presumido/Real: 1,62-1,71)
H = 168
VOL = 30000
SAL = {'cons': {'PM': 20000, 'DS': 15000, 'ENG': 15000},
       'base': {'PM': 16000, 'DS': 12000, 'ENG': 12000},
       'otim': {'PM': 12000, 'DS': 9000,  'ENG': 9000}}
OPS = 60 * H    # especialista da operação a R$ 60/h (mesmo valor da seção 5)
GAIN = {'cons': dict(tri=510, A=350, B=590, pend=170, dup=70, aud=-520),
        'base': dict(tri=780, A=730, B=1580, pend=440, dup=100, aud=-347),
        'otim': dict(tri=1030, A=1220, B=2630, pend=830, dup=120, aud=-173)}
DUR = {'cons': 1.3, 'base': 1.0, 'otim': 0.85}
LLM = {'cons': 30000, 'base': 12000, 'otim': 6000}   # R$/ano: 1ª resposta, coleta, rascunhos, resumos
INFRA = 800                                          # R$/mês: serviço do classificador/roteador + monitoramento
SUST = {'DS': .1, 'ENG': .1}
# fases: (nome, recomendações, meses, alocação FTE, ganhos ligados ao terminar)
FASES = [
    ('1 Fundação', '1, 2, 3, 9 e 12', 1.5, {'PM': .25, 'DS': .25, 'ENG': .25, 'OPS': .5}, {}),
    ('2 Triagem automática', '4, 5, 6 e 10', 2.0, {'PM': .25, 'DS': .75, 'ENG': .5, 'OPS': .5}, {'tri': 1, 'aud': 1}),
    ('3 Fluxo sem retrabalho', '7 (1ª resposta e coleta), 11 e 13', 2.0, {'PM': .25, 'DS': .5, 'ENG': .5, 'OPS': .5}, {'pend': 1, 'dup': 1}),
    ('4 Respostas com IA', '7 (nível A) e 8', 2.5, {'PM': .25, 'DS': .75, 'ENG': .5, 'OPS': .5}, {'A': 1, 'B': 1}),
]

def mc(alloc, s):
    return sum(v * (OPS if k == 'OPS' else SAL[s][k] * ENC) for k, v in alloc.items())

out = {}
for s in ['otim', 'base', 'cons']:
    g = GAIN[s]
    full = sum(v * 60 for v in g.values())
    rec_total = mc(SUST, s) * 12 + INFRA * 12 + LLM[s]
    on = {k: 0 for k in g}; steps = []; impl = 0; ph = []; acc = 0
    rec_on = {'infra': False, 'llm': False}
    for nome, recs, m, al, lig in FASES:
        m = m * DUR[s]; c = mc(al, s) * m; impl += c
        ph.append({'fase': nome, 'recomendacoes': recs, 'inicio': round(acc, 1), 'meses': round(m, 1), 'custo': round(c),
                   'horas_ano': round(sum(g[k] * f for k, f in lig.items()))})
        acc += m
        if nome.startswith('2'): rec_on['infra'] = True
        if nome.startswith('3'): rec_on['llm'] = True
        for _ in range(int(round(m * 2))):
            steps.append((mc(al, s) / 2, dict(on), dict(rec_on)))
        on.update(lig)
    T = len(steps) / 2
    cum = 0; pay = None; curve = []
    for i in range(120):
        if i < len(steps):
            c, o2, r = steps[i]; gain = sum(g[k] * 60 * o2[k] for k in g) / 24
            rc = (INFRA * 12 * r['infra'] + LLM[s] * r['llm']) / 24
        else:
            c = 0; gain = full / 24; rc = rec_total / 24
        cum += gain - c - rc
        curve.append(round(cum))
        if pay is None and i >= len(steps) and cum >= 0: pay = (i + 1) / 2
    gpv = full / VOL
    out[s] = {'meses_impl': T, 'custo_impl': round(impl), 'recorrente_ano': round(rec_total),
              'rec_detalhe': {'sustentacao': round(mc(SUST, s) * 12), 'infra': INFRA * 12, 'llm': LLM[s]},
              'ganho_ano_pleno': round(full), 'liquido_ano_pleno': round(full - rec_total),
              'payback_meses': pay, 'saldo_36m': curve[71], 'saldo_60m': curve[119],
              'volume_equilibrio': round(rec_total / gpv, -3),
              'volume_payback_24m': round((impl + 2 * rec_total) / (2 * gpv), -3), 'fases': ph}
    o = out[s]
    print(f"{s}: {T} m | impl R$ {impl/1e3:.0f} mil | rec R$ {rec_total/1e3:.0f} mil {o['rec_detalhe']} | ganho R$ {full/1e3:.0f} mil | "
          f"líq R$ {(full-rec_total)/1e3:.0f} mil | payback {pay} | 36m {curve[71]/1e3:.0f} | 60m {curve[119]/1e3:.0f} | "
          f"eq {o['volume_equilibrio']:.0f} | v24 {o['volume_payback_24m']:.0f}")
    for p in ph: print('   ', p)
json.dump(out, open('implantacao-custos.json', 'w'), ensure_ascii=False, indent=1)
