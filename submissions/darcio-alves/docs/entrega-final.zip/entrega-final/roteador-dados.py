"""Gera router_data.json: estatísticas do roteador no conjunto de teste (9.568) e 400 tickets de teste para simular chegada."""
import json, re, pickle, numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
df = pd.read_csv('/home/claude/clf/ds2.csv')
tr, te = train_test_split(df, test_size=.2, stratify=df.Topic_group, random_state=0)
vec, clf = pickle.load(open('/home/claude/clf/m.pkl','rb'))
P = clf.predict_proba(vec.transform(te.Document.fillna('')))
cls = clf.classes_; pred = cls[P.argmax(1)]; conf = P.max(1)
t = te.Document.fillna('').str.lower()
URG=r'\b(?:urgent|urgently|asap|immediately|critical|emergency)\b'
COB=r'\b(?:reminder|chasing|chase|any update|following up|follow up|escalat\w*|still waiting)\b'
FAL=r'\b(?:error|failed|failure|not working|unable|cannot)\b'
IMP=r'\b(?:all users|everyone|whole team|entire team|nobody can|outage|down for|is down|server down|production|cannot work|can not work|blocked|stopped working)\b'
urg=t.str.contains(URG).values; cob=t.str.contains(COB).values; fal=t.str.contains(FAL).values; imp=t.str.contains(IMP).values
prio=np.where(urg&(fal|imp),'P1',np.where(urg|cob|imp,'P2',np.where(fal,'P3','P4')))
human_q=np.isin(pred,['Administrative rights','Miscellaneous'])
dec=np.select([np.isin(prio,['P1','P2']),conf<.5,human_q,conf>=.9],['urgente','triagem','confirma','auto'],'sugere')
ok=pred==te.Topic_group.values
n=len(te); st={'n':n,'prio':{p:round((prio==p).mean()*100,1) for p in ['P1','P2','P3','P4']},'dec':{}}
for d in ['auto','sugere','confirma','triagem','urgente']:
    m=dec==d; st['dec'][d]={'share':round(m.mean()*100,1),'acc':round(ok[m].mean()*100,1),'n':int(m.sum())}
st['auto_err']=int((~ok&(dec=='auto')).sum())
print(json.dumps(st,ensure_ascii=False,indent=1))
rng=np.random.RandomState(1); te2=te.assign(nw=te.Document.str.split().str.len()); te2=te2[(te2.nw>=6)&(te2.nw<=60)]
# amostra enriquecida de urgências para a simulação mostrar todas as faixas
tt=te2.Document.str.lower(); u=te2[tt.str.contains(URG)|tt.str.contains(COB)|tt.str.contains(IMP)]
s=pd.concat([te2.sample(340,random_state=1),u.sample(min(60,len(u)),random_state=1)]).drop_duplicates('Document').sample(frac=1,random_state=2)
json.dump({'stats':st,'sample':[{'t':d[:400],'real':r} for d,r in zip(s.Document,s.Topic_group)]},open('router_data.json','w'),ensure_ascii=False)
print(len(s))
