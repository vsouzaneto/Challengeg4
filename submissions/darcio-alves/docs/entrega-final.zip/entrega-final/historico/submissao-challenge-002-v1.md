# Submissão — Darcio Alves — Challenge 002

## Sobre mim

- **Nome:** Darcio Alves
- **LinkedIn:** [A PREENCHER]
- **Challenge escolhido:** 002 — Redesign de Suporte (Operações / CX)

---

## Executive Summary

_[RASCUNHO — revisar ao final]_

Analisei os dois datasets antes de propor qualquer automação. O Dataset 1 (métricas operacionais) tem 8.469 tickets, não ~30 mil, e é sintético: tempos, CSAT e texto são aleatórios e independentes entre si (Cramér's V ≤ 0,07; CSAT uniforme, p = 0,80), então não sustenta diagnóstico de gargalos nem de satisfação — serve como modelo do que instrumentar. O Dataset 2 (47.837 e-mails reais de service desk) sustenta a automação: um classificador simples acerta a fila em 86,3% (top-2: 96,4%), e roteando automaticamente só os tickets com confiança ≥ 90% cobrimos 51,3% do volume com 98,6% de acerto. Recomendação principal: roteamento automático com limiar de confiança + sugestão de 2 filas para o restante, com humano no circuito e instrumentação das métricas que hoje não existem.

---

## Solução

### Abordagem

_[RASCUNHO]_

1. **Auditar os dados antes de analisar.** Contagem real de registros, padrão de nulos, distribuições e dependência entre variáveis em ambos os datasets.
2. **Separar o que é sinal do que é ruído.** Dataset 1 testado contra a hipótese de geração aleatória (poder estatístico, simulação de faixas esperadas por acaso). Dataset 2 lido como e-mails reais pré-processados.
3. **Priorizar o que os dados sustentam:** triagem e roteamento (Dataset 2), com política de confiança em vez de "automatizar tudo".
4. **Construir o protótipo** sobre os dados reais, com validação cruzada 5-fold.
5. **Transformar lacunas em KPIs a coletar** (tempo, reatribuição, FCR, CSAT, custo).

### Resultados / Findings

#### Dataset 1 — o diagnóstico que os dados permitem

- **8.469 tickets, não ~30 mil.** O CSV tem 29.808 linhas físicas porque 72,6% das descrições têm quebras de linha dentro do campo; quem conta linhas do arquivo chega a ~30 mil.
- **Nulos seguem o status:** Open (2.819) sem resposta/resolução/nota; Pending (2.881) só com 1ª resposta; Closed (2.769) completo. CSAT existe apenas para fechados.
- **Dado sintético:** nomes/e-mails do Faker, gênero não bate com nome, tempos aleatórios no mesmo dia (49% de tempos de resolução negativos), CSAT uniforme 1–5 sem relação com canal, prioridade, tipo, produto ou tempo.
- **Armadilha evitada:** a "pior combinação" (Phone/High/Refund, CSAT 2,29) está dentro da faixa esperada por acaso para 80 grupos (simulação: 2,31–3,63). Reportá-la como gargalo seria um falso achado.
- **Poder estatístico:** o teste detectaria diferença de ~0,2 ponto de CSAT entre canais — a ausência de efeito é um nulo forte, não falta de amostra.

_[A DEFINIR com o Darcio: como apresentar "onde perdemos tempo" e "quanto desperdiçamos" — via Dataset 2 + hipóteses de calculadora?]_

#### Dataset 2 — onde a IA ajuda

- **Rótulo = fila resolvedora, não assunto** (só 22% dos tickets com "access" são da classe Access). O classificador aprende roteamento, que é o que a operação precisa.
- **Desempenho (TF-IDF 1–2 gramas + regressão logística, CV 5-fold):** 86,3% de acerto; top-2 96,4%.
- **Política de confiança:** ≥ 90% → 51,3% dos tickets (24.560) com 98,6% de acerto; erro de 0,72% do total. Rotear tudo erraria 13,7% (6.576).
- **Filas frágeis:** Administrative rights (recall 68,6%, 23,1% confundidos com Hardware), Internal Project 81,0%, Miscellaneous 83,8%.
- **Viés para Hardware:** 41,6% dos erros do modelo apontam Hardware — e o rótulo humano também manda para Hardware ~20% dos pedidos de senha e pasta/drive.
- **Demanda repetitiva:** 28 modelos de texto cobrem 1.779 tickets (3,7%); 13 intenções por palavra-chave cobrem 40,4%.
- **Sinais de prioridade só no texto:** urgência ou cobrança em 6,9%; falha/erro em 18,5% (29,0% em Admin rights).

#### Protótipo

_[A PREENCHER: o que foi construído, link, screenshots, como rodar]_

### Recomendações

_[RASCUNHO — priorizar com o Darcio]_

1. **Roteamento automático com limiar de confiança (≥ 90%)** — metade do volume sem triagem manual, erro < 1%.
2. **Sugestão top-2 para o restante** — o agente escolhe entre 2 filas (96,4% de cobertura).
3. **Não automatizar:** Administrative rights e Miscellaneous (baixa separabilidade, sem dono claro), tickets com urgência/cobrança/escalação, e casos de baixa confiança — ficam com humano.
4. **Atacar a demanda repetitiva** (formulários disfarçados de e-mail, ex.: "new purchase po") com formulários estruturados ou fluxos automáticos.
5. **Auditar os 344 rótulos suspeitos** antes de implantar e definir dono para Miscellaneous e alertas automáticos.
6. **Instrumentar a operação:** 1ª resposta, resolução, reatribuições, reabertura/FCR, backlog, CSAT, canal e custo por ticket — usando o esquema do Dataset 1 como referência.

### Limitações

- Dataset 1 não permite medir gargalos, satisfação ou desperdício reais; qualquer número de horas/custo depende de hipóteses explícitas.
- Dataset 2 não tem tempo, canal, prioridade, resolução nem CSAT; não se sabe se a fila foi atribuída por pessoa ou regra.
- Domínios diferentes (varejo vs. TI interna), idioma inglês, texto já pré-processado — em produção o texto novo precisa da mesma limpeza.
- Intenções, re/fw e cabeçalhos identificados por padrão de texto (re/fw é faixa: 0,9%–19,6%).

---

## Process Log — Como usei IA

> **Este bloco é obrigatório.** Sem ele, a submissão é desclassificada.

### Ferramentas usadas

| Ferramenta | Para que usou |
|------------|--------------|
| Claude (Cowork) | Análise exploratória dos datasets, testes estatísticos, classificador, dashboard de KPIs, estruturação da submissão |
| _[A PREENCHER]_ | _[ex.: ferramenta usada no protótipo]_ |

### Workflow

_[A PREENCHER com o Darcio]_

1.
2.
3.

### Onde a IA errou e como corrigi

_[A PREENCHER — candidatos já registrados no projeto:]_

- Primeira versão do dashboard (v1 → v2): re/fw reportado como 21,3% em vez de faixa; destaque de erro do "rotear tudo" em vez da política proposta; cabeçalho de e-mail superestimado (58,5% → 31,3%); dupla contagem na calculadora de horas; "Hardware como ralo" atribuído só ao modelo, sem separar do rótulo humano.
- _[outros]_

### O que eu adicionei que a IA sozinha não faria

_[A PREENCHER]_

---

## Evidências

- [ ] Screenshots das conversas com IA
- [ ] Screen recording do workflow
- [ ] Chat exports
- [ ] Git history (se construiu código)
- [ ] Outro: _____________

---

_Submissão enviada em: [data]_
