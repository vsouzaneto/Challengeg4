# Submissão — Darcio Alves — Challenge 002

## Sobre mim

- **Nome:** Darcio Alves
- **LinkedIn:** [A PREENCHER]
- **Challenge escolhido:** 002 — Redesign de Suporte (Operações / CX)

---

## Executive Summary

Li os dois datasets como uma operação real e montei um painel para cada um. No Dataset 1 (8.469 chamados), o fluxo trava antes do atendimento. 67,3% dos chamados estão fora de Closed, e 2.819 nunca receberam uma 1ª resposta. A prioridade é só um rótulo: o tempo não muda entre as faixas (p = 0,09). Nenhuma variável registrada explica a satisfação (todos os p ≥ 0,28). O maior problema é de processo e de registro, não de velocidade.

No Dataset 2 (47.837 e-mails de service desk), um classificador simples acerta a fila em 86,3% dos casos (top-2: 96,4%). Roteando automaticamente só os tickets com confiança ≥ 90%, metade do volume dispensa triagem manual, com erro de 0,72%. Somando as mensagens padronizadas, isso dá cerca de 1.339 h/ano (≈ R$ 80 mil) sob hipóteses explícitas.

A recomendação principal é instrumentar os tempos, dar dono à fila e regra à prioridade, e então automatizar a triagem com um limiar de confiança. O humano fica nos casos ambíguos, urgentes e nas filas sem critério.

---

## Solução

### Abordagem

1. **Auditar antes de analisar.** Verifiquei a contagem real de registros, o padrão de nulos e as distribuições. O "~30 mil" do enunciado são as linhas físicas do CSV do Dataset 1: 72,6% das descrições têm quebra de linha dentro do campo. Os registros reais são 8.469.
2. **Reconstruir o processo que o dado representa**, para saber o que cada dataset mede e o que fica fora dele. O Dataset 1 vira um fluxo em 5 raias com pontos de medição de A a F (diagrama em Resultados, seção 1). O Dataset 2 é mais simples: usuário interno → e-mail → caixa do service desk → atribuição de fila.
3. **Testar toda comparação.** Usei Kruskal-Wallis para tempo e CSAT, qui-quadrado para backlog e z-score com correção de Bonferroni para o mapa canal × prioridade. Diferença sem significância não vira ação.
4. **Cruzar os datasets.** O Dataset 1 mostra a taxonomia quebrada e a prioridade sem efeito. O Dataset 2 mostra que dá para rotear pelo texto e extrair a urgência dele.
5. **Desenhar a automação por política de confiança**, não "automatizar tudo". Medi o acerto por faixa de confiança e por fila para decidir onde a IA decide sozinha, onde só sugere e onde não entra.
6. **Construir os painéis** com os dados completos (8.469 e 47.837 registros), não com exemplos escolhidos a dedo.

### Resultados / Findings

#### 1. Onde o fluxo trava (Dataset 1)

Reconstruí o processo a partir dos campos registrados nos 8.469 chamados (8.320 clientes distintos). As letras A a F marcam os pontos de medição, explicados na legenda. Em vermelho estão as etapas que um suporte normalmente tem, mas que o registro não captura.

![Processo de suporte reconstruído a partir do Dataset 1: 5 raias, pontos de medição A a F e pontos cegos do registro](processo-dataset1.png)

_Fonte: aba Processo do [Painel de Suporte](https://claude.ai/artifact/XFA3f1Mc3XC2LfM8HCDRSh)._

**Estados do chamado.** Open (sem resposta ou em fila) → Pending (aguardando o cliente) → Closed. Só os chamados Closed têm todos os campos preenchidos. Por isso, tempo e satisfação descrevem apenas o que terminou, e o que está aberto ou pendente precisa ser lido à parte, como backlog.

| Ponto | O que encontrei |
|---|---|
| **A** Entrada e mix | Volume quase igual entre canais e entre prioridades (cerca de 25% cada) |
| **B** Classificação | Os 16 assuntos aparecem nos 5 tipos, então não dá para rotear pelo tipo. A prioridade não segue critério |
| **C** Primeira resposta | **2.819 chamados Open (33,3%) sem nenhuma resposta.** Sem horário de abertura, o tempo não pode ser medido |
| **D** Resolução | Mediana de 6,3 h e P90 de 16,0 h¹. Em 49,3% dos casos, a resolução foi registrada antes da 1ª resposta |
| **E** Fila parada | **Backlog de 67,3%** (2.819 Open + 2.881 Pending), sendo **2.783 High ou Critical** |
| **F** Satisfação | CSAT de 2,99. Nenhuma variável registrada explica a nota (seção 2) |

¹ Considera só os chamados com resolução depois da 1ª resposta (n = 1.404 de 2.769). 96,2% dos horários caem no mesmo dia.

O que os testes mostram sobre os pontos B e D:

- **A prioridade não ordena o atendimento.** As medianas são Critical 6,0 h, High 7,1 h, Medium 5,9 h e Low 7,1 h (Kruskal-Wallis p = 0,09).
- **Nenhuma combinação canal × prioridade é gargalo.** Nenhuma das 16 células do mapa difere da média geral (|z| ≥ 2,96 com correção de Bonferroni). O canal também não altera o tempo (p = 0,79).
- **Conclusão:** o fluxo trava antes do atendimento, nos pontos C e E. A causa está na falta de dono da fila e de critério de prioridade, não na velocidade do agente.

#### 2. O que impacta satisfação (Dataset 1, ponto F)

- CSAT médio de 2,99, com 39,8% de notas 1 e 2. A distribuição é plana, com cerca de 20% em cada nota.
- **Nenhuma dimensão registrada explica a nota:**

| Dimensão | p (Kruskal-Wallis) |
|---|---|
| Canal | 0,28 |
| Tipo | 0,70 |
| Prioridade | 0,63 |
| Produto | 0,67 |
| Faixa etária | 0,80 |
| Gênero | 0,63 |

- A maior diferença é de 0,13 ponto (Chat 3,08 contra Phone 2,95), dentro do ruído.
- **Tempo × nota:** correlação de −0,00 (p = 0,89). Demorar mais não derruba a nota.
- **Leitura:** a satisfação depende do que não se registra hoje, como qualidade da resolução, agente e reabertura. Por isso não recomendo nenhuma ação por canal ou produto com base no CSAT.
- **Cobertura da pesquisa de 100% dos fechados.** Isso é incomum e merece auditoria da coleta.

#### 3. Onde a IA ajuda: roteamento (Dataset 2)

- **O rótulo indica a fila que resolve, não o assunto do texto.** Só 22% dos tickets com a palavra "access" estão na fila Access. O classificador aprende roteamento, que é o que a operação precisa.
- **Modelo:** TF-IDF de 1 e 2 palavras com regressão logística, em validação cruzada 5-fold sobre os 47.837 tickets. Acerto de **86,3%**, top-2 de **96,4%**.
- **Curva de confiança:**

| Confiança | % dos tickets | Acerto | Política |
|---|---|---|---|
| ≥ 90% | 51,3% | 98,6% | Roteia automaticamente |
| 70–90% | 26,7% | 86,2% | Sugere 1 fila |
| 50–70% | 16,3% | 62,1% | Sugere 2 filas |
| < 50% | 5,7% | 44,5% | Triagem humana |

- **Erro da política:** 344 tickets (0,72% do total). Rotear tudo automaticamente erraria 6.576 (13,7%).
- **Filas frágeis (recall):** Administrative rights 68,6% (23,1% dos casos previstos como Hardware), Internal Project 81,0% e Miscellaneous 83,8%. As demais ficam entre 85,6% e 88,9%.

#### 4. Falhas de processo visíveis no texto (Dataset 2)

- **Miscellaneous é uma fila sem dono:** 7.060 tickets que misturam relatórios Oracle, aprovação de despesas e pesquisas do ServiceNow.
- **Alertas automáticos sem destino fixo:** 220 tickets divididos entre Hardware (46%) e Miscellaneous (43%).
- **Pedidos de outras filas vão para Hardware.** No rótulo humano, Hardware recebe 19,9% dos resets de senha, 19,8% dos pedidos de pasta/drive e 22,6% dos pedidos de acesso.
- **Mensagens padronizadas com fila previsível.** 28 aberturas que se repetem cobrem 1.779 tickets (3,7%): 1.541 são modelos de pedido (compras, novo colaborador, desligamento, código de projeto, acesso) e 238 são alertas de sistema (caixa de e-mail cheia, avisos de ponto do Oracle). Em 25 das 28 aberturas, 90% ou mais vai para uma única fila (1.611 tickets), então dá para rotear por regra, sem modelo. As exceções são dois pedidos de acesso e o alerta crítico.
- **Treze intenções cobrem 40,4% da demanda.**
- **A prioridade só aparece no texto.** 2.806 tickets pedem urgência e 643 cobram resposta (6,9% no total), sem campo nem SLA. Relatos de falha ou erro são 18,5% (29,0% em Admin rights).
- **Ruído:** 87,8% têm saudação e 31,3% trazem cabeçalho de e-mail colado.
- **Follow-ups podem estar virando tickets novos.** A faixa vai de 0,9% (começam com re/fw) a 19,6% (re/fw em qualquer ponto do texto).

#### 5. Quanto estamos desperdiçando

- **Fila parada (Dataset 1):** 2.819 chamados sem nenhuma resposta, a maioria High ou Critical. É o maior desperdício recuperável, mas não dá para medir em horas porque não existe horário de abertura.
- **Triagem manual (Dataset 2), em calculadora com hipóteses editáveis:**
  - 47.837 tickets/ano;
  - 3 min por triagem;
  - 4 min extras por pedido em texto livre, só nos 1.541 modelos de pedido;
  - R$ 60/h.

  O resultado é 1.237 h de triagem evitada (51,7% dos tickets) mais 103 h de formulário, **≈ 1.339 h/ano, cerca de R$ 80 mil**. Os 238 alertas economizam só a triagem. Não há dupla contagem: 1.608 das 1.779 mensagens padronizadas já estão na faixa de alta confiança.

#### Protótipo

| Entregável | O que faz |
|---|---|
| [Painel de Suporte — Dataset 1](https://claude.ai/artifact/XFA3f1Mc3XC2LfM8HCDRSh) | Três abas: Processo (diagrama com pontos de medição), Painel de KPIs (com testes estatísticos) e Guia de KPIs. Roda sobre os 8.469 chamados e aceita carregar outro CSV. |
| [Painel do service desk de TI — Dataset 2](https://claude.ai/artifact/Q8mQ2pcZZ68qnGerUAgmPC) | Representação do dado, KPIs em três grupos (medidos, proxy, a coletar), falhas de roteamento, demanda repetitiva, as 28 mensagens padronizadas, sinais no texto e calculadora de horas. |
| `painel-suporte-dataset2-analise.py` | Treina e avalia o classificador sobre os 47.837 tickets e gera todos os números do painel (≈ 2 min). |

_[A DEFINIR: incluir um classificador interativo (texto → fila + confiança + ação da política)?]_

### Recomendações

**Prioridade 1 — pré-requisitos (sem eles, nenhuma automação é mensurável)**

1. **Instrumentar os tempos.** Registrar Created At, First Response At, Resolved At e Closed At, além de agente/fila, reatribuições, reabertura e meta de SLA.
2. **Dar dono à fila parada.** Atacar os 2.819 chamados sem resposta, a começar pelos High e Critical, e criar um alerta de chamado sem 1ª resposta.
3. **Definir uma regra de prioridade** (impacto × urgência) com SLA e fila por faixa. Hoje a prioridade não muda nada.

**Prioridade 2 — automação de baixo risco**

4. **Regra fixa para alertas automáticos e mensagens padronizadas** (1.979 tickets, 4,1%). Também converter os 1.541 modelos de pedido em formulários estruturados.
5. **Rotear automaticamente com confiança ≥ 90%** e sugerir fila nos demais casos, conforme a tabela acima. Auditar 200 tickets por semana e suspender se o acerto cair abaixo de 97%.
6. **Detectar urgência e cobrança no texto** para alimentar o campo de prioridade (6,9%).

**Prioridade 3 — qualidade da entrada**

7. **Criar critério de entrada para Miscellaneous e Administrative rights** (8.820 tickets, 18,4%) e corrigir a taxonomia tipo × assunto.
8. **Limpar saudação, assinatura e thread** antes de o agente ler o ticket (87,8% têm esse ruído).
9. **Vincular re/fw ao ticket original.**
10. **Criar modelos de resolução e um formulário estruturado.** Hoje a resolução tem em média 5,5 palavras e a descrição é padronizada.

**O que NÃO automatizar**

- **Tickets com confiança abaixo de 50%:** o acerto é de 44,5%, pior que deixar uma pessoa decidir.
- **Administrative rights:** pelo texto, não se distingue de Hardware (recall de 68,6%). Envolve concessão de privilégio, então exige aprovação humana.
- **Miscellaneous:** enquanto não houver critério de entrada, o modelo só reproduz a bagunça da fila.
- **Urgência, cobrança e escalação:** a IA sinaliza e prioriza, mas quem responde é uma pessoa.
- **Decisões que afetam a satisfação** (qualidade da resolução, reembolso, cancelamento): os dados mostram que a nota não é explicada pelo que se registra, então não há base para delegar.

**Fluxo proposto**

1. O ticket entra por qualquer canal.
2. A IA limpa o texto (saudação, assinatura, thread) e verifica se é follow-up de um ticket existente.
3. Regras fixas tratam alertas e mensagens padronizadas conhecidas.
4. O classificador escolhe a fila e calcula a confiança. Abaixo de 90%, o atendente recebe a sugestão de 1 ou 2 filas e decide.
5. A IA detecta urgência e cobrança. O humano confirma a prioridade, que dispara o SLA.
6. O atendente resolve, usando modelos de resolução.
7. A pesquisa de satisfação é enviada, e a auditoria semanal da política fecha o ciclo.

### Limitações

- **Dataset 1:** tratei os dados como reais, mas há sinais fortes de geração sintética:
  - nomes do Faker;
  - tempos aleatórios no mesmo dia, com 49% negativos;
  - variáveis categóricas independentes (Cramér's V ≤ 0,07);
  - CSAT uniforme;
  - placeholder `{product_purchased}` em 100% das descrições.

  Por isso, os achados do Dataset 1 valem mais como falhas de registro do que como medida do desempenho da operação.
- **Tempos do Dataset 1:** usam só as durações positivas (n = 1.404). Cortar os negativos puxa a mediana para baixo.
- **Dataset 2:** não tem tempo, canal, prioridade, resolução nem CSAT. Também não diz se a fila foi atribuída por pessoa ou por regra. O rótulo foi tratado como verdade, e os 344 erros da política coincidem com rótulos suspeitos que ainda não foram auditados.
- **Horas e custo:** dependem das hipóteses da calculadora. Intenções, re/fw e cabeçalhos foram detectados por padrão de texto (o re/fw é uma faixa, não um número). As mensagens padronizadas são inferidas por aberturas repetidas (5 primeiras palavras, 20 repetições ou mais), com o tipo definido lendo exemplos; o dataset não tem campo de formulário.
- **Domínios e idioma:** os domínios são diferentes (varejo e TI interna), o texto é em inglês e o Dataset 2 já vem pré-processado. Em produção, o texto novo precisa passar pela mesma limpeza.

---

## Process Log — Como usei IA

> **Este bloco é obrigatório.** Sem ele, a submissão é desclassificada.

### Ferramentas usadas

| Ferramenta | Para que usou |
|------------|--------------|
| Claude (Cowork) — Sonnet 5.5 | Primeira versão do painel do Dataset 2 |
| Claude (Cowork) — Opus 5.5 | Auditoria dos datasets, testes estatísticos, revisão crítica da v1, painéis finais, estruturação da submissão |
| Claude Artifacts | Publicação dos dois painéis interativos |
| Python (pandas, scipy, scikit-learn) via Claude | Cálculo dos KPIs, testes e classificador com validação cruzada |
| Projeto no Claude | Memória compartilhada entre as sessões (análises, JSONs de KPIs, código) |

### Workflow

_[REVISAR com o Darcio]_

1. Pedi uma auditoria de cada dataset antes de qualquer análise: contagem, nulos, distribuições e origem do dado.
2. Decidi tratar os datasets como operação real e pedi para reconstruir o processo que cada um representa.
3. Pedi um painel de KPIs por dataset, com os KPIs separados em medidos, proxy e a coletar.
4. Troquei de modelo (Sonnet → Opus) e pedi uma revisão crítica da v1 antes de qualquer alteração. Aprovei os ajustes um a um.
5. Exigi teste estatístico em toda comparação e defini o filtro de tempo (só durações positivas, sempre citado junto do número).
6. Salvei análises, números e código no projeto para consolidar tudo nesta submissão.

### Onde a IA errou e como corrigi

**Dataset 1**

- **Dashboard sem testes.** O painel comparava grupos sem teste e concluía que "a prioridade altera o tempo" olhando só Critical contra Low. Na revisão, Medium era a faixa mais rápida e a diferença não era significativa (p = 0,09).
- **Fuso horário.** O agrupamento por data usava UTC e mostrava 89,8% dos horários no mesmo dia. O valor correto é 96,2%, obtido lendo a data direto do texto.
- **Mapa de calor exagerado.** A escala ia do menor ao maior valor, fazendo ruído parecer gargalo. Troquei por uma escala fixa centrada na média, com teste de significância.
- **Cobertura da pesquisa.** Os 100% apareciam como "Ok" e passaram a ser sinal de atenção.

**Dataset 2 (revisão da v1)**

- **Re/fw superestimado.** O valor de 21,3% contava "re" em qualquer posição, inclusive "re enter". Virou uma faixa de 0,9% a 19,6%.
- **Destaque de erro enganoso.** O painel mostrava 13,7% de erro (rotear tudo), mas a proposta roteia só os tickets ≥ 90%, cujo erro é 0,72%.
- **"Hardware como ralo".** Misturava viés do modelo com falha da operação. Separei o viés do modelo (31,0% previsto contra 28,5% real) do sinal no rótulo humano.
- **Cabeçalho de e-mail.** O valor de 58,5% contava qualquer dia da semana no texto; o padrão real de cabeçalho é 31,3%.
- **Calculadora.** Contava duas vezes a triagem das mensagens padronizadas que já estavam na faixa de alta confiança.
- **"Formulários disfarçados de e-mail."** Perguntei de onde vinha o dado de formulário. Era uma inferência por aberturas repetidas, e 7 das 28 (238 tickets) eram alertas de sistema, não formulários. O achado virou "mensagens padronizadas", separado em pedidos e alertas, e o tempo extra da calculadora passou a valer só para os pedidos (119 h → 103 h).
- **Conclusões fortes demais.** O diagrama afirmava "triagem humana" sem base, e as intenções apareciam como "sem regra clara" a partir de uma simples busca por palavra-chave.

### O que eu adicionei que a IA sozinha não faria

_[A PREENCHER — sugestões a partir do histórico:]_

- A decisão de ler os dados como operação real e transformar as anomalias em falhas de processo e de registro.
- A exigência de revisão crítica antes de aceitar a v1, e de teste estatístico em toda comparação.
- A decisão de método sobre os tempos negativos, com a ressalva sempre explícita.
- _[sua experiência com processos e dados operacionais]_

---

## Evidências

- [ ] Screenshots das conversas com IA
- [ ] Screen recording do workflow
- [ ] Chat exports
- [x] Código: `painel-suporte-dataset2-analise.py` e fonte dos painéis
- [x] Outro: painéis publicados (links na seção Protótipo) e JSONs com todos os KPIs

---

_Submissão enviada em: [data]_
