# Análise das três perguntas do Diretor (05/10/2026)

Base da submissão v8 (`claude/submissao/submissao-challenge-002-v8.md`). Complementa `painel-suporte-dataset1.md` e `painel-suporte-dataset2.md`. Use estes números em vez de reabrir os datasets.

## O que veio do projeto e o que precisou de reanálise

- **Do projeto, sem reabrir:** os p-valores por dimensão (CSAT, tempo e backlog), o mapa canal × prioridade, os números do classificador, as intenções, as mensagens padronizadas e a calculadora do Dataset 2 (`painel-suporte-dataset*-kpis.json`).
- **Reanalisado (só o Dataset 1):** o projeto não tinha os cruzamentos triplos, a premissa P2 para os tempos, um modelo multivariado de CSAT nem o volume por assunto. Os dados foram lidos do CSV embutido no Painel de Suporte (artifact XFA3f1Mc3XC2LfM8HCDRSh), sem baixar de novo do Kaggle. O Dataset 2 não foi reaberto.

## 1. Onde o fluxo trava

Premissas para o tempo entre a 1ª resposta e a resolução:

- **P1 — só durações positivas:** n = 1.404, mediana 6,3 h.
- **P2 — resolução no dia seguinte:** negativo + 24 h; n = 2.769, mediana 11,6 h, P90 21,7 h.

"Acaso" é o percentil 95 da pior mediana em 200 a 300 simulações com os tempos embaralhados e grupos do mesmo tamanho.

| Cruzamento | Pior em P1 | Pior em P2 | Acaso, 5–95% (P1 / P2) | Kruskal-Wallis p (P1 / P2) |
|---|---|---|---|---|
| Canal | Chat 6,5 h | Phone 12,3 h | 6,4–7,3 / 11,6–12,6 | 0,79 / 0,41 |
| Prioridade | High 7,1 h | High 12,1 h | 6,3–7,4 / 11,6–12,6 | 0,09 / 0,49 |
| Tipo | Product inquiry 7,0 h | Product inquiry 12,2 h | 6,5–7,5 / 11,8–12,9 | 0,16 / 0,37 |
| Canal × prioridade | Chat · High 8,4 h | Social · Medium 13,7 h | 7,2–8,9 / 12,4–14,3 | 0,25 / 0,24 |
| Canal × tipo | Chat · Cancellation 7,3 h | Phone · Product inquiry 14,0 h | 7,5–9,1 / 12,8–14,8 | 0,83 / 0,80 |
| Prioridade × tipo | High · Refund 8,8 h | High · Refund 13,4 h | 7,5–9,0 / 12,9–14,9 | 0,12 / 0,14 |
| Canal × prioridade × tipo | Chat · Low · Technical 13,2 h (n = 15) | Social · Medium · Technical 16,2 h | 9,6–13,1 / 15,6–18,3 | 0,56 / 0,55 |

**Open sem resposta (33,3% no geral):**

- Pior canal × prioridade: Phone · Low, 38,9% (acaso até 39,0%; qui-quadrado p = 0,45).
- Canal × prioridade × tipo: p = 0,55. Assunto: p = 0,15. Prioridade × assunto: p = 0,73.
- 1.396 dos 2.819 sem resposta (49,5%) são High ou Critical. Correção: o texto anterior dizia "a maioria".

**Fora de Closed:** o pior cruzamento é Low · Payment issue, com 81,7% (acaso até 79,2%). É uma célula em 64, e o teste global dá p = 0,17.

## 2. O que impacta a satisfação

- **Modelos com todas as variáveis:** usei canal, prioridade, tipo, assunto, produto, gênero, faixa etária, tempo P2 e hora da 1ª resposta.
  - R² em validação cruzada 5-fold: −0,036 na regressão linear e −0,033 na floresta aleatória.
  - AUC para prever nota 1 ou 2: 0,498 na regressão logística e 0,491 na floresta aleatória.
- **Maior diferença por variável (IC95 por bootstrap; eta² = parte da variação da nota explicada pela variável):**

| Variável | Maior diferença | IC95 | Eta² | p |
|---|---|---|---|---|
| Canal | 0,13 (Chat contra Phone) | −0,02 a 0,28 | 0,0014 | 0,28 |
| Tipo | 0,09 | −0,07 a 0,27 | 0,0008 | 0,70 |
| Prioridade | 0,09 | −0,05 a 0,24 | 0,0006 | 0,63 |
| Assunto | 0,38 (Installation support contra Delivery problem) | 0,06 a 0,69, mas é o melhor contra o pior entre 16 | 0,0037 | 0,81 |

- **Tempo:** Spearman 0,003 em P1 (p = 0,92) e −0,019 em P2 (p = 0,33). Nota média por quartil de tempo: P1 2,99 / 3,01 / 3,13 / 2,97; P2 2,97 / 3,07 / 2,98 / 2,94.
- **Hora da 1ª resposta:** Spearman −0,04 (p = 0,03). É um resultado isolado entre cerca de dez testes.
- **Frase de abertura da descrição:** p = 0,45.

## 3. Desperdício: modelo de premissas

Nível de automação por assunto (Dataset 1):

| Nível | Assuntos | Chamados |
|---|---|---|
| A — a IA resolve sozinha | Account access, Product recommendation, Product setup, Installation support, Delivery problem | 2.646 (31,2%) |
| B — a IA sugere, o humano decide | Software bug, Network problem, Battery life, Display issue, Product compatibility, Peripheral compatibility, Payment issue, Refund request, Cancellation request | 4.785 (56,5%) |
| C — humano | Hardware issue, Data loss | 1.038 (12,3%) |

Pending: 2.881 (34,0%). O resultado é anualizado para 30 mil chamados (fator 30.000 / 8.469), a R$ 60/h.

| Cenário | Tempo A / B / C | Nível A pela IA | Redução no B | Triagem | Pending: min por rodada, redução | Horas/ano | R$/ano | % do esforço |
|---|---|---|---|---|---|---|---|---|
| Conservador | 8 / 15 / 30 min | 30% | 15% | 2 min × 51,3% | 5 min, 25% | 1.736 | 104 mil | 18,9% |
| Base | 10 / 20 / 40 min | 50% | 30% | 3 min × 51,7% | 8 min, 40% | 3.796 | 228 mil | 30,3% |
| Otimista | 12 / 25 / 45 min | 70% | 40% | 4 min × 51,7% | 10 min, 60% | 6.192 | 372 mil | 40,2% |

Componentes do cenário base, em horas por ano:

| Componente | Horas |
|---|---|
| Triagem | 780 |
| Nível A | 780 |
| Nível B | 1.690 |
| Pending | 550 |

O que a automação resolve sozinha, segundo o Dataset 2 (vem do JSON do painel):

| Tipo de chamado | Volume | Evidência |
|---|---|---|
| Alertas de sistema | 238 | — |
| Mensagens padronizadas com fila previsível | 1.611 | — |
| Novo colaborador (starter) | 2.256 | 91,5% na mesma fila; o modelo acerta 95,7% |
| Pedido de compra (PO) | 1.708 | 86,3% na mesma fila; o modelo acerta 96,5% |
| Reset de senha / conta | 1.950 | 70,2% em Access; o modelo acerta 87,2% |

## 4. Recálculo após o fluxo proposto (submissão v11)

O fluxo da v10 trouxe quatro ajustes ao modelo de premissas:

- **Urgências:** 6,9% vão direto para a esteira humana, então os ganhos dos níveis A e B são multiplicados por 0,931.
- **Pending:** a coleta de dados só acontece nas esteiras automática e híbrida. A redução vale para (A + B) / N = 87,7% dos chamados, também multiplicada por 0,931.
- **Duplicatas:** 0,9% dos chamados, multiplicados pelo tempo médio de atendimento ponderado mais a triagem. É o piso medido: os tickets que começam com re/fw.
- **Auditoria:** 200 tickets por semana × 52 semanas × 3, 2 ou 1 min, conforme o cenário.

| Cenário | Triagem | Nível A | Nível B | Pending | Duplicatas | Auditoria | Líquido (h/ano) | R$/ano | % do esforço |
|---|---|---|---|---|---|---|---|---|---|
| Conservador | 510 | 350 | 590 | 170 | 70 | −520 | 1.182 | 71 mil | 13% |
| Base | 780 | 730 | 1.580 | 440 | 100 | −347 | 3.279 | 197 mil | 26% |
| Otimista | 1.030 | 1.220 | 2.630 | 830 | 120 | −173 | 5.669 | 340 mil | 37% |

Os valores não incluem o custo das ferramentas de IA.
