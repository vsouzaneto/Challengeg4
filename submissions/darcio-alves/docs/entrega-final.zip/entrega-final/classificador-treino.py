"""Treina o modelo do Classificador de Tickets (protótipo) e exporta model.json para a página.
Uso: python3 classificador-treino.py all_tickets_processed_improved_v3.csv
Depois: substituir __MODEL__ em classificador-tickets-template.html pelo conteúdo de model.json e publicar."""
import sys, json, numpy as np, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import train_test_split
df = pd.read_csv(sys.argv[1])
tr, te = train_test_split(df, test_size=.2, stratify=df.Topic_group, random_state=0)  # 38.269 treino / 9.568 teste
v = TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True, max_features=30000)
Xtr = v.fit_transform(tr.Document); Xte = v.transform(te.Document)
c = SGDClassifier(loss='log_loss', alpha=2e-6, max_iter=30, random_state=0).fit(Xtr, tr.Topic_group)
P = c.predict_proba(Xte); cls = list(c.classes_); pred = np.array(cls)[P.argmax(1)]; conf = P.max(1); yt = te.Topic_group.values; ok = pred == yt
top2 = np.argsort(-P, 1)[:, :2]
bands = []
for lo, hi, l, acao in [(.9, 1.01, '≥ 90%', 'Roteia sozinho'), (.7, .9, '70–90%', 'Sugere 1 fila'), (.5, .7, '50–70%', 'Sugere 2 filas'), (0, .5, '< 50%', 'Triagem humana')]:
    m = (conf >= lo) & (conf < hi); bands.append(dict(b=l, acao=acao, share=round(float(m.mean()*100), 1), acc=round(float(ok[m].mean()*100), 1), n=int(m.sum())))
metrics = dict(n_train=len(tr), n_test=len(te), acc=round(float(ok.mean()*100), 1), top2=round(float(np.mean([cls.index(a) in b for a, b in zip(yt, top2)])*100), 1),
               bands=bands, recall={k: round(float(ok[yt == k].mean()*100), 1) for k in cls}, policy_err=int(((conf >= .9) & ~ok).sum()))
terms = [None]*len(v.vocabulary_)
for t, i in v.vocabulary_.items(): terms[i] = t
te2 = te.assign(conf=conf, ok=ok, n=te.Document.str.split().str.len()); te2 = te2[(te2.n >= 8) & (te2.n <= 40)]
rng = np.random.default_rng(3); ex = []
def pick(q, k, label):
    s = te2[q]
    for _, r in s.sample(min(k, len(s)), random_state=int(rng.integers(1e6))).iterrows(): ex.append(dict(t=r.Document, real=r.Topic_group, tag=label))
pick((te2.conf >= .9) & te2.ok, 3, 'alta confiança'); pick((te2.conf >= .7) & (te2.conf < .9), 2, 'confiança média')
pick((te2.conf >= .5) & (te2.conf < .7), 2, 'duas filas'); pick(te2.conf < .5, 2, 'triagem humana'); pick((te2.conf >= .9) & ~te2.ok, 1, 'erro com alta confiança')
json.dump(dict(cls=cls, terms=terms, idf=np.round(v.idf_, 4).tolist(), W=np.round(c.coef_.T, 3).tolist(), b=np.round(c.intercept_, 4).tolist(),
               metrics=metrics, examples=ex), open('model.json', 'w'), separators=(',', ':'), ensure_ascii=False)
print(metrics)
