# Reclassificação do Dataset 2 — resumo para análise

Arquivo gerado: `all_tickets_processed_improved_v3_ajuste_reclassificacao.csv`. Tem os mesmos 47.837 tickets e as colunas originais (`Document`, `Topic_group`) intactas, mais estas colunas:

| Coluna | O que é |
|---|---|
| `Sugestao_classificacao` | Minha fila sugerida. Igual à original quando não sugiro mudança |
| `Reclassificado` | Sim ou Não |
| `Nivel_confianca` | Alta, Média ou Baixa (revisar). Vazio quando não há mudança |
| `Prob_sugestao` | Probabilidade média que os dois modelos dão à fila sugerida |
| `Prob_rotulo_original` | Probabilidade que os modelos dão à fila original |

Nenhum outro arquivo foi alterado. Nada foi para o projeto nem para a submissão.

## Como reclassifiquei

1. **Dois modelos independentes**, um por palavras e outro por pedaços de palavras (que pega erros de digitação e palavras coladas). Cada ticket foi classificado por modelos que **não viram aquele ticket no treino** (validação cruzada em 5 partes). Assim, o rótulo do próprio ticket não influencia a sugestão.
2. **Só sugiro mudança quando os dois modelos concordam** numa fila diferente da original, com confiança alta na nova fila e baixa na original:

   | Nível | Fila sugerida | Fila original | Tickets |
   |---|---|---|---|
   | Alta | ≥ 90% | ≤ 5% | 171 |
   | Média | 80–90% | ≤ 10% | 324 |
   | Baixa (revisar) | 60–80% | ≤ 20% | 1.231 |

3. **Leitura humana de uma amostra.** Li 115 sugestões, sorteadas em todos os níveis, e julguei cada uma pelo texto (arquivo `amostra_validacao_reclassificacao.csv`).

## Resultado em números

**1.726 tickets reclassificados (3,6% do total).** Somando os níveis a partir do mais confiável:

| Se aceitar | Tickets | % do dataset |
|---|---|---|
| Só Alta | 171 | 0,4% |
| Alta + Média | 495 | 1,0% |
| Alta + Média + Baixa | 1.726 | 3,6% |

**O que a leitura da amostra mostrou:**

| Nível | Sugestão melhor | Original melhor | Ambíguo |
|---|---|---|---|
| Alta (30 lidos) | 17 (57%) | 4 (13%) | 9 (30%) |
| Média (30) | 16 (53%) | 4 (13%) | 10 (33%) |
| Baixa (55) | 25 (45%) | 10 (18%) | 20 (36%) |

Leitura: quando dá para decidir, a sugestão acerta cerca de **4 em cada 5 vezes nos níveis Alta e Média** e cerca de 7 em 10 na Baixa. Um terço dos casos é ambíguo: texto curto, quebrado ou que serviria a mais de uma fila.

**Volume por fila, antes e depois (todos os níveis):**

| Fila | Antes | Saem | Entram | Depois | Saldo |
|---|---|---|---|---|---|
| Access | 7.125 | 216 (3,0%) | 130 | 7.039 | −86 |
| Administrative rights | 1.760 | 185 (10,5%) | 50 | 1.625 | −135 |
| HR Support | 10.915 | 366 (3,4%) | 364 | 10.913 | −2 |
| Hardware | 13.617 | 356 (2,6%) | 838 | 14.099 | +482 |
| Internal Project | 2.119 | 93 (4,4%) | 38 | 2.064 | −55 |
| Miscellaneous | 7.060 | 291 (4,1%) | 246 | 7.015 | −45 |
| Purchase | 2.464 | 114 (4,6%) | 16 | 2.366 | −98 |
| Storage | 2.777 | 105 (3,8%) | 44 | 2.716 | −61 |

**Trocas mais frequentes:**

| Original → Sugestão | Tickets |
|---|---|
| HR Support → Hardware | 224 |
| Administrative rights → Hardware | 164 |
| Miscellaneous → Hardware | 162 |
| Hardware → HR Support | 145 |
| Access → Hardware | 120 |
| Miscellaneous → HR Support | 87 |
| Hardware → Miscellaneous | 81 |
| HR Support → Miscellaneous | 78 |
| Purchase → Hardware | 76 |
| Hardware → Access | 66 |
| Storage → Hardware | 57 |
| Access → HR Support | 57 |
| Internal Project → HR Support | 38 |
| Internal Project → Hardware | 35 |
| HR Support → Access | 31 |

## Pontos de atenção antes de decidir

- **Hardware é a grande receptora (+482 no saldo).** Isso combina com o viés conhecido do modelo, que já prevê Hardware em excesso (31,0% contra 28,5% reais). Parte dessas sugestões é viés do modelo, não erro do rótulo. As trocas para Hardware pedem mais cuidado, sobretudo as que saem de Administrative rights (164) e Miscellaneous (162).
- **Erros claros que a amostra confirmou:**
  - pedidos de senha que estavam em Hardware sugeridos para Access;
  - avisos de ponto e timesheet do Oracle que estavam em Hardware, Access ou Internal Project sugeridos para HR Support;
  - problemas de equipamento, rede e laptop que estavam em HR Support ou Administrative rights sugeridos para Hardware;
  - acesso a pastas e sites que estava em Hardware sugerido para Storage.
- **Onde a sugestão costuma errar:**
  - temas de RH com palavras técnicas, como "vacation approval error" e "leaver";
  - pedidos financeiros de Miscellaneous, como forecast e month end, que o modelo puxa para Hardware;
  - pedidos de crachá de acesso.
- **O rótulo original é a fila que resolve nesta organização**, e não necessariamente o assunto. Algumas "correções" podem contrariar uma convenção interna legítima, por exemplo pedidos de acesso a pastas resolvidos por Storage.
- **Os modelos aprendem com os próprios rótulos.** Por isso não detectam erros sistemáticos, quando uma fila inteira recebe um tipo de pedido errado de forma consistente. Esses só aparecem lendo os textos ou ouvindo os donos das filas.

## Sugestão de próximo passo (para você decidir)

1. Aceitar automaticamente só o nível **Alta** (171) ou **Alta + Média** (495).
2. Mandar o nível **Baixa** (1.231) para revisão humana no Classificador, começando pelas trocas para Hardware.
3. Retreinar com os rótulos corrigidos e medir de novo. Para não inflar o número, a medição tem que ser feita num conjunto revisado por pessoas, e não contra as sugestões do próprio modelo.
