import pandas as pd, numpy as np
from scipy import stats
df=pd.read_csv('d1.csv')
df.columns=['id','name','email','age','gender','prod','dop','type','subj','desc','status','res','prio','chan','frt','ttr','csat']
c=df[df.status=='Closed'].copy()
c['d']=(pd.to_datetime(c.ttr)-pd.to_datetime(c.frt)).dt.total_seconds()/3600
c['p1']=c.d.where(c.d>=0)            # só positivas
c['p2']=np.where(c.d<0,c.d+24,c.d)   # negativa = dia seguinte
print('P1 n',c.p1.notna().sum(),'med',c.p1.median(),'P2 med',c.p2.median(),'p90',c.p2.quantile(.9))
rng=np.random.default_rng(0)
def worst(col,keys,minn=20,B=500):
    g=c.dropna(subset=[col]).groupby(keys)[col]
    t=g.agg(['median','count']).query('count>=@minn').sort_values('median',ascending=False)
    # null: max median among same-size groups under random shuffle
    vals=c[col].dropna().values; sizes=t['count'].values
    mx=[max(np.median(rng.choice(vals,s,replace=False)) for s in sizes) for _ in range(B)]
    kw=stats.kruskal(*[x.values for _,x in g if len(x)>=minn])
    return t, np.percentile(mx,[5,95]), kw.pvalue
for col in ['p1','p2']:
  for keys in [['chan'],['prio'],['type'],['chan','prio'],['chan','type'],['prio','type'],['chan','prio','type']]:
    t,ci,p=worst(col,keys,minn=15 if len(keys)==3 else 20,B=300 if len(keys)<3 else 200)
    print(col,keys,'groups',len(t),'KW p=%.2f'%p,'| pior:',t.index[0],'%.1fh n=%d'%(t['median'].iloc[0],t['count'].iloc[0]),'| máx esperado ao acaso 5-95%%: %.1f–%.1f'%tuple(ci))
c.to_pickle('closed.pkl')
import pandas as pd, json
df=pd.read_csv('d1.csv'); df.columns=['id','name','email','age','gender','prod','dop','type','subj','desc','status','res','prio','chan','frt','ttr','csat']
A=['Account access','Product recommendation','Product setup','Installation support','Delivery problem']
C=['Hardware issue','Data loss']
df['tier']=df.subj.map(lambda s:'A' if s in A else 'C' if s in C else 'B')
N=len(df); vt=df.tier.value_counts().to_dict(); pend=(df.status=='Pending Customer Response').sum()
print(N,vt,pend, {t:round(v/N*100,1) for t,v in vt.items()})
ANUAL=30000; f=ANUAL/N
S={ # cenário: (AHT A,B,C min), deflexão A, redução B, triagem min, cobertura triagem auto, min por rodada pending, redução pending
 'conservador':dict(aht=(8,15,30),defA=.30,redB=.15,tri=2,cov=.513,rp=5,redP=.25),
 'base':       dict(aht=(10,20,40),defA=.50,redB=.30,tri=3,cov=.517,rp=8,redP=.40),
 'otimista':   dict(aht=(12,25,45),defA=.70,redB=.40,tri=4,cov=.517,rp=10,redP=.60)}
out={}
for k,p in S.items():
    a,b,c=p['aht']
    total=(vt['A']*a+vt['B']*b+vt['C']*c+N*p['tri']+pend*p['rp'])/60
    sv={'triagem':N*p['cov']*p['tri']/60,'autosserv_A':vt['A']*p['defA']*a/60,'assist_B':vt['B']*p['redB']*b/60,'pending':pend*p['redP']*p['rp']/60}
    s=sum(sv.values())
    out[k]={'horas_atuais_dataset':round(total),'economia_dataset':{x:round(v) for x,v in sv.items()},'economia_total_dataset':round(s),'pct':round(s/total*100,1),
            'anual_h':round(s*f),'anual_RS':round(s*f*60,-3),'total_anual_h':round(total*f)}
print(json.dumps(out,indent=1,ensure_ascii=False))
json.dump({'tiers':vt,'pending':int(pend),'N':N,'cenarios':out,'premissas':S},open('waste.json','w'),ensure_ascii=False,indent=1)
