"""Reproduz todos os números do Painel do service desk de TI (Dataset 2, v2).
Entrada: all_tickets_processed_improved_v3.csv (Kaggle adisongoh). Saída: painel-suporte-dataset2-kpis.json
Uso: python3 painel-suporte-dataset2-analise.py caminho/do.csv   (≈2 min; validação cruzada 5-fold)"""
import sys, json, numpy as np, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import cross_val_predict, StratifiedKFold
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support as prf

df = pd.read_csv(sys.argv[1]); d = df.Document; y = df.Topic_group; N = len(df)
df['n'] = d.str.split().str.len(); cls = sorted(y.unique())
pct = lambda m: round(float(m.mean()*100), 1)

# --- classificador (TF-IDF 1-2 gramas + regressão logística via SGD, CV 5-fold estratificada)
X = TfidfVectorizer(ngram_range=(1,2), min_df=2, sublinear_tf=True).fit_transform(d)
clf = SGDClassifier(loss='log_loss', alpha=2e-6, max_iter=30, random_state=0)
P = cross_val_predict(clf, X, y, cv=StratifiedKFold(5, shuffle=True, random_state=0), method='predict_proba')
pred = np.array(cls)[P.argmax(1)]; conf = P.max(1); err = pred != y; hi = conf >= .9
top2 = np.argsort(-P, 1)[:, :2]
p, r, f, _ = prf(y, pred, labels=cls)

# --- intenções por palavra-chave
I = {
 'Reset de senha / conta': r'\bpasswords?\b|\bunlock|\blocked out|\baccount locked',
 'Novo colaborador (starter)': r'\bnew starter\b|\bstarter\b',
 'Desligamento (leaver)': r'\bleavers?\b|\bleave date\b',
 'Timecard / ponto (Oracle)': r'\btime ?cards?\b|\btimesheets?\b|\bmissing time\b|\btime entries\b',
 'Pedido de compra (PO)': r'\bpurchase po\b|\bpurchase order\b|\brequisition\b|\bnew purchase\b',
 'Alerta automático (impressora/dispositivo/update)': r'\bdevice alert\b|\bprinter alert\b|\bwindows updates\b|\bdevice recovery\b|\bnotification monthly\b',
 'Instalar / atualizar software': r'\binstall\w*|\bupgrade\b|\bsoftware\b',
 'VPN / rede': r'\bvpn\b|\bwifi\b|\bnetwork\b|\btunnel\w*',
 'E-mail / Outlook': r'\boutlook\b|\bmailbox\b',
 'Pasta / drive / quota': r'\bshared drive\b|\bfolder\b|\bquota\b|\bdrive\b|\bsharepoint\b',
 'Equipamento (laptop/monitor/periférico)': r'\blaptop\b|\bmonitor\b|\bkeyboard\b|\bmouse\b|\bheadset\b|\bdocking\b',
 'Impressora': r'\bprinters?\b|\bprinting\b',
 'Pedido de acesso': r'\baccess request\b|\brequest access\b|\bwants? to access\b|\bpermissions?\b',
}
intents = []; cov = pd.Series(False, index=df.index)
for k, v in I.items():
    m = d.str.contains(v, regex=True); cov |= m; vc = y[m].value_counts(normalize=True)
    intents.append(dict(intent=k, n=int(m.sum()), pct=round(m.mean()*100, 2), top=vc.index[0], toppct=round(vc.iloc[0]*100, 1),
                        dist={c: round(float(vc.get(c, 0))*100, 1) for c in cls}, acc=round(float((pred[m] == y[m]).mean()*100), 1)))

# --- sinais de texto (v2: re/fw em faixa, cabeçalho em vez de dia da semana)
any_re = d.str.contains(r'\b(?:re|fw|fwd)\b')
fp = d.str.contains(r'\bre (?:enter|install|run|set|start|send|try|activate|image|assign|open)\w*')
start = d.str.match(r'^\s*(?:re|fw|fwd)\b'); upper = any_re & ~fp
header = d.str.contains(r'\bsent (?:monday|tuesday|wednesday|thursday|friday)\b|\b(?:monday|tuesday|wednesday|thursday|friday) (?:pm|am)\b')
sig = {'urgência explícita': r'\b(?:urgent|urgently|asap|immediately|critical|emergency)\b',
       'cobrança/follow-up': r'\b(?:reminder|chasing|chase|any update|following up|follow up|escalat\w*|still waiting)\b',
       'falha / erro': r'\b(?:error|failed|failure|not working|unable|cannot)\b'}
S = {k: d.str.contains(v, regex=True) for k, v in sig.items()}
f5 = d.str.split().str[:5].str.join(' '); vc5 = f5.value_counts(); tpl = f5.isin(vc5[vc5 >= 20].index)
bins = [0,10,20,30,50,80,150,300,1000]; h = pd.cut(df.n, bins).value_counts(sort=False)


# --- mensagens padronizadas (v3): 28 aberturas de 5 palavras repetidas >= 20 vezes, separadas por quem origina
ALERTAS = {'your mailbox is almost full', 'critical alert original message sent', 'device alert notification paper at',
           'please action direct reports missing', 'please action submit your time', 'time card error card error',
           'there is error submission of'}
def tipo_modelo(k): return 'alerta' if k in ALERTAS else 'pedido'
grupos = []
for k, v in vc5[vc5 >= 20].items():
    m = f5 == k; q = y[m].value_counts(normalize=True)
    grupos.append(dict(abertura=k, n=int(v), tipo=tipo_modelo(k), fila=q.index[0], fila_pct=round(float(q.iloc[0]*100), 1), alta_conf=int((m & hi).sum())))
ped = f5.isin([g['abertura'] for g in grupos if g['tipo'] == 'pedido']); ale = f5.isin([g['abertura'] for g in grupos if g['tipo'] == 'alerta'])
modelos = dict(
 total=int(tpl.sum()), grupos=len(grupos),
 pedido_n=int(ped.sum()), pedido_grupos=sum(g['tipo'] == 'pedido' for g in grupos), alerta_n=int(ale.sum()), alerta_grupos=sum(g['tipo'] == 'alerta' for g in grupos),
 grupos_fila_unica_90=sum(g['fila_pct'] >= 90 for g in grupos), n_fila_unica_90=sum(g['n'] for g in grupos if g['fila_pct'] >= 90),
 lista=grupos)

res = dict(
 versao='v3', n=N, accuracy=round(float((~err).mean()*100), 1), top2=round(float(np.mean([cls.index(t) in tt for t, tt in zip(y, top2)])*100), 1),
 err_total=int(err.sum()), err_pct=pct(err), err_to_hw=round(float((pred[err] == 'Hardware').mean()*100), 1),
 hw_pred_share=pct(pd.Series(pred == 'Hardware')), pred_share={c: pct(pd.Series(pred == c)) for c in cls},
 classes={c: int((y == c).sum()) for c in cls}, perclass={c: dict(p=round(float(p[i])*100, 1), r=round(float(r[i])*100, 1), f=round(float(f[i])*100, 1)) for i, c in enumerate(cls)},
 cm=dict(cls=cls, cm=confusion_matrix(y, pred, labels=cls).tolist()),
 conf=[dict(b=l, share=pct((conf >= lo) & (conf < hi_)), acc=round(float((~err[(conf >= lo) & (conf < hi_)]).mean()*100), 1))
       for lo, hi_, l in [(0, .5, '<50%'), (.5, .7, '50–70%'), (.7, .9, '70–90%'), (.9, 1.01, '≥90%')]],
 hi_n=int(hi.sum()), hi_conf_share=pct(pd.Series(hi)), hi_conf_acc=round(float((~err[hi]).mean()*100), 1),
 policy_err_n=int((hi & err).sum()), policy_err_pct=round(float((hi & err).sum()/N*100), 2),
 bad90=int((hi & err).sum()), bad90_pct=round(float((hi & err).sum()/N*100), 2),
 template_rows=int(tpl.sum()), template_groups=int((vc5 >= 20).sum()), template_in_hi=int((tpl & hi).sum()), hi_nontpl=int((hi & ~tpl).sum()),
 top_templates=[[k, int(v)] for k, v in vc5.head(8).items()], modelos=modelos, pedido_rows=int(ped.sum()),
 intents=intents, intent_cov=pct(cov),
 label_hw_share={k['intent']: k['dist']['Hardware'] for k in intents},
 refw=dict(qualquer=int(any_re.sum()), inicio=int(start.sum()), inicio_pct=pct(start), falsos_positivos=int((any_re & fp).sum()), teto=int(upper.sum()), teto_pct=pct(upper)),
 noise={'saudação': pct(d.str.contains(r'\b(?:hi|hello|dear|good morning|good afternoon)\b')),
        'fechamento': pct(d.str.contains(r'\b(?:regards|thanks|thank|best|kind regards|cheers)\b')),
        'cabeçalho de e-mail (sent/pm)': pct(header), 're/fw no texto (teto)': pct(upper),
        'aviso legal': pct(d.str.contains(r'confidential|privileged|unauthorized|intended recipient'))},
 dia_semana_qualquer=pct(d.str.contains(r'\b(?:monday|tuesday|wednesday|thursday|friday)\b')),
 signals={k: dict(pct=pct(m), n=int(m.sum()), by={c: round(float((m & (y == c)).sum()/(y == c).sum()*100), 1) for c in cls}) for k, m in S.items()},
 urg_ou_cobranca=pct(S['urgência explícita'] | S['cobrança/follow-up']),
 hist=[[f'{int(b.left)+1}–{int(b.right)}', int(c)] for b, c in h.items()],
 long80_all=pct(df.n > 80), short10_all=pct(df.n <= 10), words_pct={q: float(df.n.quantile(q/100)) for q in (10,25,50,75,90,95,99)},
)
res['class'] = res.pop('classes')
json.dump(res, open('painel-suporte-dataset2-kpis.json', 'w'), ensure_ascii=False, indent=1)
print(res['modelos']['pedido_n'], res['modelos']['alerta_n'], res['modelos']['grupos_fila_unica_90'], res['modelos']['n_fila_unica_90'], int((ped&hi).sum()))
print({k: res[k] for k in ['accuracy','top2','hi_conf_share','hi_conf_acc','policy_err_n','err_to_hw','template_in_hi','intent_cov','urg_ou_cobranca']}, res['refw'], res['noise'])
