#!/usr/bin/env python3
"""QA visual V2 em bytes locais, com capturas reabertas e autenticadas."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

from playwright.sync_api import sync_playwright


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def canonical_json(payload: object) -> str:
    return json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n"


def load_specs(root: Path):
    path = root / "scripts/build_all.py"
    spec = importlib.util.spec_from_file_location("challenge004_builder", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("não foi possível carregar o contrato de QA")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.QA_CAPTURE_SPECS


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    args = parser.parse_args()
    root = args.root.resolve()
    specs = load_specs(root)
    document_path = root / "dist/index.html"
    document_bytes = document_path.read_bytes()
    document_sha256 = sha256_bytes(document_bytes)
    document_url = document_path.as_uri()
    shots = root / "reports/screenshots"
    shots.mkdir(parents=True, exist_ok=True)

    console_errors: list[str] = []
    page_errors: list[str] = []
    request_urls: set[str] = set()
    navigated_hashes: set[str] = set()
    viewports: list[dict[str, object]] = []

    with sync_playwright() as runtime:
        browser = runtime.chromium.launch(headless=True)
        browser_version = browser.version
        for name, width, height, target, zoom_percent in specs:
            page = browser.new_page(viewport={"width": width, "height": height}, device_scale_factor=1)
            page.on("console", lambda message: console_errors.append(message.text) if message.type == "error" else None)
            page.on("pageerror", lambda error: page_errors.append(str(error)))
            page.on("request", lambda request: request_urls.add(request.url))
            response = page.goto(document_url, wait_until="load")
            if response is None or not response.ok:
                raise RuntimeError(f"falha ao abrir bytes locais em {name}")
            navigated_hash = sha256_bytes(response.body())
            if navigated_hash != document_sha256:
                raise RuntimeError(f"bytes navegados divergem de dist/index.html em {name}")
            navigated_hashes.add(navigated_hash)
            if zoom_percent != 100:
                page.evaluate("percent => { document.body.style.zoom = String(percent / 100); }", zoom_percent)
            locator = page.locator(target)
            locator.scroll_into_view_if_needed()
            layout = page.evaluate(
                """() => {
                    const root = document.documentElement;
                    const pairs = [
                      [document.querySelector('#hero h1'), document.querySelector('#hero .lead')],
                      ...Array.from(document.querySelectorAll('.section-head')).map(head => [head.querySelector('h2'), head.querySelector('p')])
                    ];
                    const overlap = pairs.some(([a,b]) => {
                      if (!a || !b) return false;
                      const ar = a.getBoundingClientRect(), br = b.getBoundingClientRect();
                      return ar.bottom > br.top + 0.5;
                    });
                    const y = window.scrollY;
                    window.scrollTo(999999, y);
                    const reached = window.scrollX;
                    window.scrollTo(0, y);
                    return { horizontal: root.scrollWidth > root.clientWidth + 1 || reached > 0, overlap };
                }"""
            )
            screenshot_path = shots / f"{name}.png"
            locator.screenshot(path=str(screenshot_path))
            first_hash = sha256(screenshot_path)
            reopened = screenshot_path.read_bytes()
            reopened_hash = sha256_bytes(reopened)
            if first_hash != reopened_hash or not reopened:
                raise RuntimeError(f"screenshot não autenticado em {name}")
            viewports.append({
                "name": name,
                "width": width,
                "height": height,
                "target": target,
                "zoom_percent": zoom_percent,
                "horizontal_overflow": bool(layout["horizontal"]),
                "vertical_overlap": bool(layout["overlap"]),
                "screenshot_path": str(screenshot_path.relative_to(root)),
                "screenshot_sha256": reopened_hash,
            })
            page.close()
        browser.close()

    external = sorted(url for url in request_urls if url != document_url and not url.startswith("data:"))
    if navigated_hashes != {document_sha256}:
        raise RuntimeError("identidade navegada inconsistente")
    failed = bool(console_errors or page_errors or external or any(item["horizontal_overflow"] or item["vertical_overlap"] for item in viewports))
    payload = {
        "schema_version": 2,
        "status": "FAILED" if failed else "PASSED",
        "browser": "chromium",
        "browser_version": browser_version,
        "index_html_sha256": document_sha256,
        "reviewed_document_path": "dist/index.html",
        "reviewed_document_sha256": document_sha256,
        "prototype_data_sha256": sha256(root / "evidence/prototype-data.json"),
        "console_errors": len(console_errors),
        "page_errors": len(page_errors),
        "external_network_requests": len(external),
        "console_error_messages": console_errors,
        "page_error_messages": page_errors,
        "external_request_urls": external,
        "viewports": viewports,
    }
    output = root / "evidence/qa-evidence.json"
    output.write_text(canonical_json(payload), encoding="utf-8")
    print(canonical_json(payload), end="")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
