#!/usr/bin/env python3
"""Builder determinístico da narrativa executiva V2 do Challenge 004."""

from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import html
import json
import math
import platform
import re
import stat
import statistics
import sys
from datetime import datetime
from pathlib import Path
from typing import Mapping, Sequence
from urllib.parse import urlsplit

DATASET_SHA256 = "693a2df6e609d1c099f3430d9a5b894b224fe12b2420c0d93e6defe90d15f18e"
HASH_RE = re.compile(r"^[0-9a-f]{64}$")
CANONICAL_BUILD_COMMAND = "PYTHONDONTWRITEBYTECODE=1 python3 -B scripts/build_all.py"
CANONICAL_TEST_COMMAND = "PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest discover -v"
CANONICAL_QA_COMMAND = "PYTHONDONTWRITEBYTECODE=1 /usr/local/lib/hermes-agent/venv/bin/python -B scripts/run_visual_qa.py --root ."
WORKFLOW_TRANSITION = "EXECUTIVE_REFINEMENT_IMPLEMENTED_PENDING_REVIEW -> SKEPTIC_REMEDIATION_IMPLEMENTED_PENDING_REVIEW"
EXECUTED_METHOD_IDS = frozenset({
    "row_count_and_descriptive_cuts",
    "ratio_of_sums_per_1000",
    "quarterly_ratio_of_sums",
    "creator_identity_cardinality",
    "raw_publication_rate_and_adjusted_components",
    "audience_publication_rate_amplitude",
    "hashtag_welch_normal_holm",
    "strategy_decision_matrix",
    "gatekeeper_rule_contract",
    "file_integrity_and_provenance",
    "prospective_experiment_contract",
    "curated_process_timeline",
    "operational_glossary",
})

# nome, largura, altura, alvo, zoom. Capturas de seção são completas, não só do viewport.
QA_CAPTURE_SPECS = (
    ("desktop-hero", 1440, 1000, "#hero", 100),
    ("desktop-performance", 1440, 1000, "#o-que-gera-engajamento", 100),
    ("desktop-distribution", 1440, 1000, "#qualidade-distribuicao", 100),
    ("desktop-identity", 1440, 1000, "#identidade", 100),
    ("desktop-sponsorship", 1440, 1000, "#patrocinio", 100),
    ("desktop-audience", 1440, 1000, "#audiencia", 100),
    ("desktop-hashtags", 1440, 1000, "#hashtags", 100),
    ("desktop-strategy", 1440, 1000, "#estrategia", 100),
    ("desktop-strategy-matrix", 1440, 1000, "#matriz-estrategica", 100),
    ("desktop-gatekeeper", 1440, 1000, "#gatekeeper", 100),
    ("desktop-process", 1440, 1000, "#processo-ia", 100),
    ("wide-hero", 1280, 900, "#hero", 125),
    ("wide-strategy-matrix", 1280, 900, "#matriz-estrategica", 125),
    ("intermediate-performance", 1024, 900, "#o-que-gera-engajamento", 100),
    ("intermediate-sponsorship", 1024, 900, "#patrocinio", 100),
    ("intermediate-strategy", 1024, 900, "#estrategia", 150),
    ("intermediate-strategy-matrix", 1024, 900, "#matriz-estrategica", 150),
    ("intermediate-gatekeeper", 1024, 900, "#gatekeeper", 100),
    ("tablet-strategy", 768, 1024, "#estrategia", 125),
    ("mobile-hero", 390, 844, "#hero", 100),
    ("mobile-performance", 390, 844, "#o-que-gera-engajamento", 100),
    ("mobile-distribution", 390, 844, "#qualidade-distribuicao", 100),
    ("mobile-identity", 390, 844, "#identidade", 100),
    ("mobile-sponsorship", 390, 844, "#patrocinio", 100),
    ("mobile-audience", 390, 844, "#audiencia", 100),
    ("mobile-hashtags", 390, 844, "#hashtags", 100),
    ("mobile-strategy", 390, 844, "#estrategia", 100),
    ("mobile-strategy-matrix", 390, 844, "#matriz-estrategica", 100),
    ("mobile-gatekeeper", 390, 844, "#gatekeeper", 100),
    ("mobile-process", 390, 844, "#processo-ia", 100),
)

INPUT_PATHS = (
    "README.md",
    "data/extracted/social_media_dataset.csv",
    "data/raw/social-media-sponsorship-and-engagement-dataset.zip",
    "docs/prototype-scope.md",
    "evidence/claim-evidence-map.json",
    "evidence/dataset-audit.json",
    "evidence/decision-map.json",
    "evidence/experiment-contracts.json",
    "evidence/process-timeline.json",
    "evidence/test-results-red-v2-remediation.txt",
    "reports/human-review-v2.md",
    "reports/refutation-log.md",
    "reports/visual-qa.md",
    "scripts/build_all.py",
    "scripts/run_visual_qa.py",
    "tests/test_build_all.py",
)


def canonical_json(payload: object) -> bytes:
    return (json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n").encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> dict[str, object]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"JSON inválido: {path}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"raiz JSON deve ser objeto: {path}")
    return value


def engagement_rate_per_view(likes: object, shares: object, comments: object, views: object) -> float:
    values = []
    for value in (likes, shares, comments, views):
        if isinstance(value, bool):
            raise ValueError("valor booleano não é métrica")
        number = float(value)
        if not math.isfinite(number) or number < 0:
            raise ValueError("métrica inválida")
        values.append(number)
    if values[3] == 0:
        raise ValueError("visualizações devem ser maiores que zero")
    return sum(values[:3]) / values[3]


def _read_rows(path: Path) -> list[dict[str, object]]:
    if sha256_file(path) != DATASET_SHA256:
        raise ValueError("hash do dataset diverge do checkpoint")
    rows: list[dict[str, object]] = []
    required = {
        "platform", "content_type", "content_category", "post_date", "views", "likes", "shares",
        "comments_count", "follower_count", "creator_id", "creator_name", "content_url", "hashtags",
        "is_sponsored", "audience_age_distribution", "audience_gender_distribution", "audience_location",
    }
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            raise ValueError("schema do CSV incompleto")
        for row in reader:
            clean: dict[str, object] = dict(row)
            for key in ("views", "likes", "shares", "comments_count", "follower_count"):
                clean[key] = int(row[key])
                if clean[key] < 0:
                    raise ValueError("métrica negativa")
            clean["date"] = datetime.strptime(row["post_date"], "%m/%d/%y %I:%M %p")
            clean["depth_actions"] = int(clean["shares"]) + int(clean["comments_count"])
            clean["interactions"] = int(clean["likes"]) + int(clean["depth_actions"])
            if int(clean["views"]) == 0:
                raise ValueError("visualizações zero impedem a unidade por visualização")
            rows.append(clean)
    if len(rows) != 52214:
        raise ValueError("contagem de linhas diverge do checkpoint")
    return rows


def _mean_per_1000(rows: Sequence[Mapping[str, object]], metric: str) -> float:
    return statistics.fmean(float(row[metric]) / float(row["views"]) * 1000 for row in rows)


def _ratio_per_1000(rows: Sequence[Mapping[str, object]], metric: str) -> float:
    return sum(float(row[metric]) for row in rows) / sum(float(row["views"]) for row in rows) * 1000


def _hashtag_analysis(rows: Sequence[Mapping[str, object]], minimum_present: int = 100, alpha: float = 0.05) -> dict[str, object]:
    """Exploração termo presente/ausente com Welch normal bilateral e Holm."""
    term_stats: dict[str, list[float]] = collections.defaultdict(lambda: [0.0, 0.0, 0.0])
    total_n = len(rows)
    total_sum = 0.0
    total_sumsq = 0.0
    combinations = collections.Counter()
    for row in rows:
        value = float(row["interactions"]) / float(row["views"]) * 1000.0
        total_sum += value
        total_sumsq += value * value
        tags = tuple(sorted(set(term.strip().lower() for term in str(row["hashtags"]).split(",") if term.strip())))
        if tags:
            combinations[tags] += 1
        for term in tags:
            stats = term_stats[term]
            stats[0] += 1.0
            stats[1] += value
            stats[2] += value * value

    results: list[dict[str, object]] = []
    for term, (present_count, present_sum, present_sumsq) in sorted(term_stats.items()):
        n_present = int(present_count)
        if n_present < minimum_present:
            continue
        n_absent = total_n - n_present
        absent_sum = total_sum - present_sum
        absent_sumsq = total_sumsq - present_sumsq
        mean_present = present_sum / n_present
        mean_absent = absent_sum / n_absent
        variance_present = max(0.0, (present_sumsq - present_sum * present_sum / n_present) / (n_present - 1))
        variance_absent = max(0.0, (absent_sumsq - absent_sum * absent_sum / n_absent) / (n_absent - 1))
        standard_error = math.sqrt(variance_present / n_present + variance_absent / n_absent)
        effect = mean_present - mean_absent
        p_value = math.erfc(abs(effect / standard_error) / math.sqrt(2.0)) if standard_error else (0.0 if effect else 1.0)
        results.append({
            "term": term,
            "n_present": n_present,
            "mean_present": mean_present,
            "mean_absent": mean_absent,
            "effect_per_1000": effect,
            "standard_error_welch": standard_error,
            "p_value": p_value,
            "p_holm": 1.0,
            "significant_holm": False,
        })

    ordered = sorted(results, key=lambda item: (float(item["p_value"]), str(item["term"])))
    running = 0.0
    for rank, item in enumerate(ordered, 1):
        running = min(1.0, max(running, (len(ordered) - rank + 1) * float(item["p_value"])))
        item["p_holm"] = running
        item["significant_holm"] = running <= alpha
    return {
        "terms": len(term_stats),
        "tested_n_gte_100": len(results),
        "survive_multiple_comparisons": sum(bool(item["significant_holm"]) for item in results),
        "combinations": len(combinations),
        "unique_combinations": sum(count == 1 for count in combinations.values()),
        "method": "welch_normal_two_sided_holm",
        "definition": "termo presente versus ausente na taxa total por publicação; diferença média em ações por 1.000 visualizações",
        "normal_approximation": True,
        "exploratory": True,
        "minimum_present": minimum_present,
        "alpha": alpha,
        "results": sorted(results, key=lambda item: str(item["term"])),
    }


def _group_cut(rows: Sequence[Mapping[str, object]], dimension: str) -> list[dict[str, object]]:
    groups: dict[str, list[Mapping[str, object]]] = collections.defaultdict(list)
    for row in rows:
        groups[str(row[dimension])].append(row)
    return [
        {
            "group": name,
            "n": len(group),
            "likes_per_1000": _ratio_per_1000(group, "likes"),
            "shares_per_1000": _ratio_per_1000(group, "shares"),
            "comments_per_1000": _ratio_per_1000(group, "comments_count"),
            "depth_actions_per_1000": _ratio_per_1000(group, "depth_actions"),
            "engagement_rate_percent": _ratio_per_1000(group, "interactions") / 10,
        }
        for name, group in sorted(groups.items())
    ]


def _build_data(rows: Sequence[Mapping[str, object]], claims: Mapping[str, object], timeline: Mapping[str, object], decisions: Mapping[str, object], audit: Mapping[str, object]) -> dict[str, object]:
    claim_records = claims.get("claims")
    if not isinstance(claim_records, list) or not claim_records:
        raise ValueError("mapa de claims vazio")
    claim_ids = []
    for claim in claim_records:
        if not isinstance(claim, dict) or not isinstance(claim.get("claim_id"), str):
            raise ValueError("claim inválido")
        for field in ("source_path", "source_sha256", "method", "limitations"):
            if not isinstance(claim.get(field), str) or not str(claim[field]).strip():
                raise ValueError(f"claim sem {field}")
        claim_ids.append(str(claim["claim_id"]))
    if len(set(claim_ids)) != len(claim_ids):
        raise ValueError("claim_id duplicado")

    follower_bands = ((0, 10000, "1 mil a 10 mil"), (10000, 50000, "10 mil a 50 mil"), (50000, 100000, "50 mil a 100 mil"), (100000, 500000, "100 mil a 500 mil"), (500000, 10**9, "500 mil ou mais"))
    band_rows: dict[str, list[Mapping[str, object]]] = collections.defaultdict(list)
    for row in rows:
        for low, high, label in follower_bands:
            if low <= int(row["follower_count"]) < high:
                item = dict(row)
                item["follower_band"] = label
                band_rows[label].append(item)
                break
    cuts = {
        "platform": _group_cut(rows, "platform"),
        "content_type": _group_cut(rows, "content_type"),
        "content_category": _group_cut(rows, "content_category"),
        "follower_band": [item for label in [b[2] for b in follower_bands] for item in _group_cut(band_rows[label], "follower_band")],
    }
    quarter_rows: dict[str, list[Mapping[str, object]]] = collections.defaultdict(list)
    for row in rows:
        date = row["date"]
        assert isinstance(date, datetime)
        quarter_rows[f"{date.year}-T{(date.month - 1) // 3 + 1}"].append(row)
    cuts["quarter"] = [
        {"group": name, "n": len(group), "engagement_rate_percent": _ratio_per_1000(group, "interactions") / 10,
         "likes_per_1000": _ratio_per_1000(group, "likes"), "shares_per_1000": _ratio_per_1000(group, "shares"),
         "comments_per_1000": _ratio_per_1000(group, "comments_count"), "depth_actions_per_1000": _ratio_per_1000(group, "depth_actions")}
        for name, group in sorted(quarter_rows.items())
    ]

    creator_names: dict[str, set[str]] = collections.defaultdict(set)
    keys = collections.Counter()
    ranges: dict[str, list[int]] = collections.defaultdict(list)
    urls: dict[tuple[str, str, str], list[Mapping[str, object]]] = collections.defaultdict(list)
    for row in rows:
        creator_names[str(row["creator_id"])].add(str(row["creator_name"]))
        keys[(str(row["creator_id"]), str(row["creator_name"]), str(row["platform"]))] += 1
        ranges[str(row["platform"])].append(int(row["follower_count"]))
        parsed = urlsplit(str(row["content_url"]))
        parts = [part for part in parsed.path.split("/") if part]
        urls[(parsed.scheme, parsed.netloc, parts[0] if parts else "")].append(row)
    reused = [group for group in urls.values() if len(group) > 1]
    hashtag_analysis = _hashtag_analysis(rows)

    audience: dict[str, object] = {}
    for key, dimension in (("age", "audience_age_distribution"), ("gender", "audience_gender_distribution"), ("location", "audience_location")):
        groups: dict[str, list[Mapping[str, object]]] = collections.defaultdict(list)
        for row in rows:
            groups[str(row[dimension])].append(row)
        means = {name: _mean_per_1000(group, "depth_actions") for name, group in groups.items()}
        audience[f"{key}_depth_amplitude_per_1000"] = max(means.values()) - min(means.values())
        audience[f"{key}_groups"] = [{"group": name, "n": len(groups[name]), "depth_actions_per_1000": means[name]} for name in sorted(groups)]

    organic = [row for row in rows if row["is_sponsored"] == "FALSE"]
    sponsored = [row for row in rows if row["is_sponsored"] == "TRUE"]
    organic_rate = _mean_per_1000(organic, "interactions") / 10
    sponsored_rate = _mean_per_1000(sponsored, "interactions") / 10
    dates = [row["date"] for row in rows]
    assert all(isinstance(value, datetime) for value in dates)
    quarter_rates = [float(item["engagement_rate_percent"]) for item in cuts["quarter"]]

    return {
        "schema_version": 2,
        "artifact": "challenge_004_offline_executive_narrative_v2",
        "language": "pt-BR",
        "workflow_transition": WORKFLOW_TRANSITION,
        "registered_claim_ids": sorted(claim_ids),
        "hero": {"publications": len(rows), "decision_signal": "nenhum sinal decisório material"},
        "engagement": {
            "estimand": "ratio_of_sums_per_1000_views",
            "baseline_per_1000_views": {
                "likes": _ratio_per_1000(rows, "likes"),
                "shares": _ratio_per_1000(rows, "shares"),
                "comments": _ratio_per_1000(rows, "comments_count"),
                "depth_actions": _ratio_per_1000(rows, "depth_actions"),
            },
            "cuts": cuts,
            "interpretation": "diferenças descritivas pequenas que não sustentam decisões operacionais",
        },
        "distribution_quality": {
            "period": [min(dates).strftime("%Y-%m-%d"), max(dates).strftime("%Y-%m-%d")],
            "quarter_rate_range_percent": [min(quarter_rates), max(quarter_rates)],
            "zero_rows": {metric: sum(int(row[source]) == 0 for row in rows) for metric, source in (("views", "views"), ("likes", "likes"), ("shares", "shares"), ("comments", "comments_count"), ("interactions", "interactions"))},
        },
        "creator_identity": {
            "creator_ids": len(creator_names),
            "multi_name_creator_ids": sum(len(names) > 1 for names in creator_names.values()),
            "id_name_platform_keys": len(keys),
            "singleton_keys": sum(count == 1 for count in keys.values()),
            "reported_follower_base_range_by_platform": {name: [min(values), max(values)] for name, values in sorted(ranges.items())},
        },
        "sponsorship": {
            "organic_n": len(organic), "sponsored_n": len(sponsored),
            "organic_rate_percent": organic_rate, "sponsored_rate_percent": sponsored_rate,
            "difference_pp": sponsored_rate - organic_rate,
            "raw_composite_estimand": "mean_of_publication_rates",
            "adjusted_components": audit["adjusted_sponsorship_effects"]["metrics"],
            "url_reuse": {"distinct_roots": len(urls), "reused_roots": len(reused), "rows_in_reused_roots": sum(len(group) for group in reused), "mixed_flags": sum(len({row["is_sponsored"] for row in group}) > 1 for group in reused)},
        },
        "audience": audience,
        "hashtags": hashtag_analysis,
        "strategy_matrix": decisions.get("strategy_matrix", []),
        "executed_method_ids": sorted(EXECUTED_METHOD_IDS),
        "data_quality_gatekeeper": {
            "state": "INSUFICIENTE_PARA_DECISAO",
            "states": ["APTO_PARA_DECISAO", "APTO_APENAS_PARA_EXPLORACAO", "INSUFICIENTE_PARA_DECISAO", "BLOQUEADO_POR_INTEGRIDADE"],
            "rules": {key: value for key, value in (
                ("schema", "PASSA"), ("provenance", "PASSA_COM_RESTRICAO"), ("identity", "FALHA_PARA_DECISAO"),
                ("uniqueness", "FALHA_PARA_DECISAO"), ("unit", "PASSA_COM_RESTRICAO"), ("dispersion_covariance", "FALHA_PARA_DECISAO"),
                ("zero_events", "FALHA_PARA_DECISAO"), ("attribution", "FALHA_PARA_DECISAO"), ("multiple_comparisons", "FALHA_PARA_DECISAO"))},
            "universal_variance_threshold": False,
        },
        "process": {"events": timeline.get("events", []), "status": timeline.get("current_status"), "rejected_generations_preserved": True},
        "experiments": {"status": "DESIGN_ONLY", "provisional_sesoi_pp": 0.5, "power_plan_required": True},
    }


def _pt(value: float, digits: int = 1) -> str:
    return f"{value:.{digits}f}".replace(".", ",")


def _int(value: int) -> str:
    return f"{value:,}".replace(",", ".")


def _evidence(claim_id: str, source: str, method: str, limitation: str) -> str:
    return (f'<details class="evidence"><summary>Como sabemos</summary><p><strong>Afirmação:</strong> {html.escape(claim_id)} · '
            f'<strong>Fonte:</strong> {html.escape(source)} · <strong>Método:</strong> {html.escape(method)} · '
            f'<strong>Limitação:</strong> {html.escape(limitation)}</p></details>')


def _visible_text(document: str) -> str:
    return " ".join(html.unescape(re.sub(r"<[^>]+>", " ", document)).split()).casefold()


def validate_semantic_maps(claims: Mapping[str, object], decisions: Mapping[str, object], document: str) -> None:
    """Falha fechado quando mapas declaram cobertura que o HTML/método não executa."""
    records = claims.get("claims")
    if not isinstance(records, list) or not records:
        raise ValueError("claims ausentes")
    visible = _visible_text(document)
    claim_ids: set[str] = set()
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("claim inválido")
        claim_id = record.get("claim_id")
        if not isinstance(claim_id, str) or claim_id in claim_ids:
            raise ValueError("claim_id inválido")
        claim_ids.add(claim_id)
        for field in ("allowed_text", "method", "limitations"):
            value = record.get(field)
            if not isinstance(value, str) or value.casefold() not in visible:
                raise ValueError(f"{field} não executado no HTML: {claim_id}")
        method_id = record.get("method_id")
        if method_id not in EXECUTED_METHOD_IDS:
            raise ValueError(f"method_id não executado: {claim_id}")
        forbidden = record.get("forbidden_interpretations")
        if not isinstance(forbidden, list) or not forbidden or any(not isinstance(value, str) or not value.strip() for value in forbidden):
            raise ValueError(f"forbidden_interpretations inválido: {claim_id}")
        for value in forbidden:
            if value.casefold() in visible:
                raise ValueError(f"interpretação proibida presente: {claim_id}")
    used_claims = set(re.findall(r'data-claim-id="([A-Z0-9-]+)"', document))
    if used_claims != claim_ids:
        raise ValueError("cobertura claim_id diverge entre mapa e HTML")

    matrix = decisions.get("strategy_matrix")
    required_items = {
        "onde_concentrar_esforco", "frequencia_de_postagem", "politica_de_patrocinio",
        "perfil_e_threshold_de_influenciador", "o_que_parar", "quick_wins_desta_semana",
    }
    if not isinstance(matrix, list) or len(matrix) != 6 or {item.get("item") for item in matrix if isinstance(item, dict)} != required_items:
        raise ValueError("matriz estratégica não cobre os seis itens")
    for item in matrix:
        if not isinstance(item, dict):
            raise ValueError("item estratégico inválido")
        for field in ("label", "answer", "evidence_or_limitation"):
            value = item.get(field)
            if not isinstance(value, str) or value.casefold() not in visible:
                raise ValueError(f"matriz estratégica sem {field} executado")
    decision_records = decisions.get("decisions")
    if not isinstance(decision_records, list) or not decision_records:
        raise ValueError("mapa de decisões vazio")
    referenced = set()
    for item in decision_records:
        if not isinstance(item, dict) or not isinstance(item.get("claim_ids"), list):
            raise ValueError("decisão inválida")
        referenced.update(str(value) for value in item["claim_ids"])
    if not referenced.issubset(claim_ids):
        raise ValueError("decisão referencia claim ausente")


def _cut_table(items: Sequence[Mapping[str, object]], first: str) -> str:
    visible_groups = {
        "image": "imagem",
        "mixed": "misto",
        "text": "texto",
        "video": "vídeo",
        "beauty": "beleza",
        "lifestyle": "estilo de vida",
        "tech": "tecnologia",
    }
    rows = "".join(
        f'<tr><td>{html.escape(visible_groups.get(str(item["group"]), str(item["group"])))}</td><td>{_int(int(item["n"]))}</td><td>{_pt(float(item["likes_per_1000"]),2)}</td>'
        f'<td>{_pt(float(item["shares_per_1000"]),2)}</td><td>{_pt(float(item["comments_per_1000"]),2)}</td><td>{_pt(float(item["depth_actions_per_1000"]),2)}</td>'
        f'<td>{_pt(float(item["engagement_rate_percent"]),4)}%</td></tr>' for item in items
    )
    return f'<div class="table-wrap"><table><thead><tr><th>{first}</th><th>N</th><th>Curtidas</th><th>Compartilhamentos</th><th>Comentários</th><th>Profundidade</th><th>Taxa</th></tr></thead><tbody>{rows}</tbody></table></div>'


def render_html(data: Mapping[str, object]) -> bytes:
    engagement = data["engagement"]
    assert isinstance(engagement, dict)
    baseline = engagement["baseline_per_1000_views"]
    cuts = engagement["cuts"]
    quality = data["distribution_quality"]
    identity = data["creator_identity"]
    sponsor = data["sponsorship"]
    audience = data["audience"]
    hashtags = data["hashtags"]
    gate = data["data_quality_gatekeeper"]
    process = data["process"]
    strategy = data["strategy_matrix"]
    assert all(isinstance(item, dict) for item in (baseline, cuts, quality, identity, sponsor, audience, hashtags, gate, process))

    metric_cards = "".join(
        f'<article class="metric-card"><span>{label}</span><strong>{_pt(float(baseline[key]),1)}</strong><small>por 1.000 visualizações</small></article>'
        for label, key in (("Reação · curtidas", "likes"), ("Amplificação · compartilhamentos", "shares"), ("Conversa · comentários", "comments"), ("Ações de profundidade", "depth_actions"))
    )
    cut_blocks = "".join(
        f'<details class="cut" {"open" if index == 0 else ""}><summary>{label}</summary>{_cut_table(cuts[key], label)}</details>'
        for index, (label, key) in enumerate((("Plataforma", "platform"), ("Tipo", "content_type"), ("Categoria", "content_category"), ("Porte", "follower_band"), ("Trimestre", "quarter")))
    )
    follower_rows = "".join(
        f'<tr><td>{html.escape(name)}</td><td>{_int(values[0])}</td><td>{_int(values[1])}</td></tr>'
        for name, values in identity["reported_follower_base_range_by_platform"].items()
    )
    audience_cards = "".join(
        f'<article class="mini-card"><span>{label}</span><strong>{_pt(float(audience[key]),4)}</strong><small>ação de profundidade por 1.000 visualizações entre extremos</small></article>'
        for label, key in (("Idade", "age_depth_amplitude_per_1000"), ("Gênero", "gender_depth_amplitude_per_1000"), ("Localização", "location_depth_amplitude_per_1000"))
    )
    rule_labels = {
        "schema": "estrutura de colunas",
        "provenance": "proveniência",
        "identity": "identidade",
        "uniqueness": "unicidade",
        "unit": "unidade de análise",
        "dispersion_covariance": "dispersão e covariância",
        "zero_events": "eventos zero",
        "attribution": "atribuição",
        "multiple_comparisons": "múltiplas comparações",
    }
    gate_status_labels = {
        "PASSA": "PASSA",
        "PASSA_COM_RESTRICAO": "PASSA COM RESTRIÇÃO",
        "FALHA_PARA_DECISAO": "FALHA PARA DECISÃO",
    }
    gate_state_labels = {
        "APTO_PARA_DECISAO": "APTO PARA DECISÃO",
        "APTO_APENAS_PARA_EXPLORACAO": "APTO APENAS PARA EXPLORAÇÃO",
        "INSUFICIENTE_PARA_DECISAO": "INSUFICIENTE PARA DECISÃO",
        "BLOQUEADO_POR_INTEGRIDADE": "BLOQUEADO POR INTEGRIDADE",
    }
    gate_rows = "".join(f'<li><span>{rule_labels[label]}</span><strong>{gate_status_labels[status]}</strong></li>' for label, status in gate["rules"].items())
    visible_gate_states = "".join(f'<li>{gate_state_labels[state]}</li>' for state in gate["states"])
    timeline = "".join(
        f'<li><span>{html.escape(str(event.get("event_id", "")))}</span><div><strong>{html.escape(str(event.get("outcome", "")).replace("V2_IMPLEMENTED_PENDING_REVIEW.", "V2 implementada, aguardando revisão."))}</strong><p>{html.escape(str(event.get("human_decision", "")))}</p><small>IA: {html.escape(str(event.get("ai_contribution", "")))}</small></div></li>'
        for event in process["events"]
    )
    strategy_rows = "".join(
        f'<tr><td>{html.escape(str(item["label"]))}</td><td>{html.escape(str(item["answer"]))}</td><td>{html.escape(str(item["evidence_or_limitation"]))}</td></tr>'
        for item in strategy
    )
    hashtag_survivors = int(hashtags["survive_multiple_comparisons"])
    hashtag_survivor_label = "zero" if hashtag_survivors == 0 else _int(hashtag_survivors)

    quarter_rows = engagement["cuts"]["quarter"]
    quarter_points = []
    quarter_circles = []
    quarter_labels = []
    for index, row in enumerate(quarter_rows):
        rate = float(row["engagement_rate_percent"])
        x = 50 + (800 * index / max(1, len(quarter_rows) - 1))
        # Escala deliberadamente ampla (19,85%–19,95%) para não exagerar a oscilação observada.
        y = 145 - ((rate - 19.85) / 0.10 * 90)
        quarter_points.append(f"{x:.1f},{y:.1f}")
        quarter_circles.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="5" />')
        quarter_labels.append(
            f'<span class="quarter-point"><b>{html.escape(str(row["group"]))}</b><small>{_pt(rate, 4)}%</small></span>'
        )
    quarter_grid = "".join(f'<line x1="{50 + 100 * i}" y1="35" x2="{50 + 100 * i}" y2="155" />' for i in range(9))
    quarter_chart = (
        '<figure class="flatline-chart" aria-labelledby="flatline-title">'
        '<figcaption><strong id="flatline-title">Eletrocardiograma quase plano</strong>'
        '<span>Taxa de engajamento trimestral em uma escala fixa de 19,85% a 19,95%.</span></figcaption>'
        '<p class="chart-scroll-hint">Deslize para ver os 9 trimestres →</p>'
        '<div class="flatline-scroll"><div class="flatline-inner">'
        '<svg viewBox="0 0 900 180" role="img" aria-label="Linha quase plana das nove taxas trimestrais">'
        f'<g class="chart-grid">{quarter_grid}<line x1="50" y1="55" x2="850" y2="55" />'
        '<line x1="50" y1="95" x2="850" y2="95" /><line x1="50" y1="135" x2="850" y2="135" /></g>'
        f'<polyline class="flatline" points="{" ".join(quarter_points)}" />'
        f'<g class="chart-points">{"".join(quarter_circles)}</g></svg>'
        f'<div class="quarter-labels">{"".join(quarter_labels)}</div>'
        '</div></div><p>Amplitude total: 0,0081 ponto percentual. O traçado reforça o diagnóstico de distribuição artificialmente estreita, mas não prova simulação isoladamente; a classificação sintética vem da proveniência declarada.</p></figure>'
    )

    document = f'''<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Desafio 004 · Choque de realidade</title>
<style>
:root{{--ink:#13211c;--muted:#607068;--paper:#f5f1e8;--card:#fffdf8;--line:#d7d2c6;--green:#0d664d;--mint:#dceee6;--amber:#9b5b0d;--amber-bg:#fff0d5;--red:#9d3434;--red-bg:#fae4df;--navy:#17344b;--shadow:0 14px 34px rgba(19,33,28,.08)}}
*{{box-sizing:border-box}}html{{scroll-behavior:smooth}}body{{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif;overflow-wrap:anywhere}}body:before{{content:"";display:block;height:6px;background:linear-gradient(90deg,var(--red),var(--amber),var(--green))}}header,main,footer{{width:min(1180px,calc(100% - 32px));margin-inline:auto;min-width:0}}header{{padding:64px 0 44px}}section{{padding:48px 0;border-top:1px solid var(--line);min-width:0}}.kicker,.eyebrow{{text-transform:uppercase;letter-spacing:.12em;font-size:.73rem;font-weight:850;color:var(--red)}}h1,h2,h3{{font-family:Georgia,serif}}h1{{font-size:clamp(2.7rem,7vw,6.4rem);line-height:.9;letter-spacing:-.055em;margin:.18em 0;max-width:1050px}}h1 em{{color:var(--red);font-style:normal}}.lead{{max-width:880px;font-size:clamp(1.05rem,2vw,1.28rem);color:var(--muted)}}.verdict{{display:grid;grid-template-columns:auto 1fr;gap:16px;align-items:center;margin-top:28px;padding:18px;border:1px solid #d08a72;border-radius:18px;background:var(--red-bg)}}.verdict strong{{font-size:1.2rem;color:var(--red)}}.pill{{display:inline-flex;padding:6px 10px;border-radius:999px;background:var(--red);color:white;font-size:.72rem;font-weight:850;letter-spacing:.06em}}.section-head{{display:flex;flex-direction:column;align-items:flex-start;gap:8px;margin-bottom:24px;max-width:900px}}.section-head h2{{font-size:clamp(2.15rem,5vw,4rem);line-height:1;margin:0}}.section-head p{{margin:0;color:var(--muted);font-size:1.05rem}}.cards,.metrics,.three,.two{{display:grid;gap:14px}}.cards{{grid-template-columns:repeat(4,1fr)}}.metrics{{grid-template-columns:repeat(4,1fr)}}.three{{grid-template-columns:repeat(3,1fr)}}.two{{grid-template-columns:repeat(2,1fr)}}.card,.metric-card,.mini-card,.panel,.priority,.gate-state{{background:var(--card);border:1px solid var(--line);border-radius:18px;box-shadow:var(--shadow);min-width:0}}.card,.panel,.priority,.gate-state{{padding:22px}}.metric-card,.mini-card{{padding:18px}}.card span,.card strong{{display:block}}.card span{{color:var(--muted);font-weight:750}}.card strong{{font:2rem/1 Georgia,serif;margin:.45rem 0;color:var(--navy)}}.metric-card span,.mini-card span{{display:block;color:var(--muted);font-weight:750}}.metric-card strong{{display:block;font:2.3rem/1 Georgia,serif;margin:.3rem 0;color:var(--navy)}}.mini-card strong{{display:block;font:1.8rem/1 Georgia,serif;margin:.4rem 0}}.cards + .panel,.three + .panel{{margin-top:18px}}.cards + .two{{margin-top:18px}}small{{color:var(--muted)}}.flatline-chart{{margin:0 0 22px;padding:20px;background:var(--card);border:1px solid var(--line);border-radius:18px;box-shadow:var(--shadow)}}.flatline-chart figcaption{{display:flex;flex-direction:column;gap:3px}}.flatline-chart figcaption strong{{font:1.45rem/1.2 Georgia,serif;color:var(--navy)}}.flatline-chart figcaption span,.flatline-chart p{{color:var(--muted)}}.flatline-chart>.chart-scroll-hint{{display:none;color:var(--red);font-weight:850;font-size:.78rem}}.flatline-scroll{{overflow-x:auto}}.flatline-inner{{min-width:760px}}.flatline-chart svg{{display:block;width:100%;height:auto;margin-top:8px}}.chart-grid line{{stroke:#ded8cb;stroke-width:1}}.flatline{{fill:none;stroke:var(--red);stroke-width:7;stroke-linecap:round;stroke-linejoin:round}}.chart-points circle{{fill:var(--card);stroke:var(--red);stroke-width:4}}.quarter-labels{{display:grid;grid-template-columns:repeat(9,1fr);gap:4px;text-align:center}}.quarter-point b,.quarter-point small{{display:block}}.quarter-point b{{font-size:.72rem}}.quarter-point small{{font-size:.7rem}}.flatline-chart p{{margin:.8rem 0 0}}.legend{{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:16px 0 22px}}.legend div{{padding:12px;border-left:4px solid var(--green);background:var(--mint);border-radius:8px}}.legend strong,.legend span{{display:block}}.legend span{{font-size:.84rem;color:var(--muted)}}.callout{{padding:20px;border-radius:16px;background:var(--navy);color:white;margin:16px 0}}.callout p{{margin:.4rem 0;color:#dce9ef}}.table-wrap{{overflow-x:auto;max-width:100%;background:var(--card);border:1px solid var(--line);border-radius:14px}}table{{border-collapse:collapse;width:100%;min-width:720px}}th,td{{padding:12px 14px;text-align:left;border-bottom:1px solid var(--line);white-space:nowrap}}#matriz-estrategica table{{table-layout:fixed;min-width:0}}#matriz-estrategica th,#matriz-estrategica td{{white-space:normal;vertical-align:top}}#matriz-estrategica th:first-child,#matriz-estrategica td:first-child{{width:23%}}th{{text-transform:uppercase;letter-spacing:.06em;font-size:.72rem;color:var(--muted);background:#faf7f0}}tr:last-child td{{border-bottom:0}}details.cut{{margin:10px 0}}details.cut>summary{{cursor:pointer;font-weight:850;padding:13px 16px;background:var(--card);border:1px solid var(--line);border-radius:12px}}details.cut[open]>summary{{border-radius:12px 12px 0 0}}details.cut[open] .table-wrap{{border-radius:0 0 12px 12px;border-top:0}}.evidence{{margin-top:18px;border:1px dashed #b5aa98;border-radius:10px;padding:10px 12px;color:var(--muted);font-size:.84rem}}.evidence summary{{cursor:pointer;font-weight:800;color:var(--ink)}}.evidence p{{margin:.55rem 0 0}}.warning{{border-left:5px solid var(--amber);background:var(--amber-bg)}}.danger{{border-left:5px solid var(--red);background:var(--red-bg)}}.safe{{border-left:5px solid var(--green);background:var(--mint)}}.fact-list{{display:grid;gap:10px;padding:0;list-style:none}}.fact-list li{{display:flex;justify-content:space-between;gap:14px;padding:13px;border-bottom:1px solid var(--line)}}.priority b{{display:grid;place-items:center;width:34px;height:34px;border-radius:50%;background:var(--green);color:white;margin-bottom:12px}}.gate-state{{border:3px solid var(--amber)}}.gate-state code{{display:block;font-size:clamp(1rem,2.2vw,1.35rem);font-weight:900;color:var(--amber)}}.state-list{{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:0;list-style:none}}.state-list li{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:10px;font-size:.75rem;font-weight:800}}.timeline{{list-style:none;padding:0;display:grid;gap:10px}}.timeline li{{display:grid;grid-template-columns:70px 1fr;gap:12px;min-width:0}}.timeline li>span{{font-weight:900;color:var(--green)}}.timeline li>div{{min-width:0;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px}}.timeline p{{margin:.3rem 0}}.glossary{{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}}.glossary div{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px}}.glossary dt{{font-weight:900}}.glossary dd{{margin:.25rem 0 0;color:var(--muted)}}footer{{padding:32px 0 50px;color:var(--muted);border-top:1px solid var(--line)}}
.zoom-note{{font-size:.78rem;color:var(--muted)}}
@media(max-width:1024px){{.cards,.metrics{{grid-template-columns:repeat(2,1fr)}}.state-list{{grid-template-columns:repeat(2,1fr)}}}}
@media(max-width:768px){{header,main,footer{{width:min(100% - 24px,1180px)}}.flatline-chart>.chart-scroll-hint{{display:block}}header{{padding-top:44px}}section{{padding:38px 0}}.three,.two,.legend,.glossary{{grid-template-columns:1fr}}#matriz-estrategica .table-wrap{{overflow:visible;border:0;background:transparent}}#matriz-estrategica table,#matriz-estrategica tbody,#matriz-estrategica tr,#matriz-estrategica td{{display:block;min-width:0;width:100%;white-space:normal}}#matriz-estrategica thead{{display:none}}#matriz-estrategica tr{{margin-bottom:12px;padding:14px;background:var(--card);border:1px solid var(--line);border-radius:12px}}#matriz-estrategica td{{padding:5px 0;border:0}}#matriz-estrategica td:before{{display:block;margin-bottom:2px;color:var(--muted);font-size:.7rem;font-weight:850;letter-spacing:.06em;text-transform:uppercase}}#matriz-estrategica td:nth-child(1):before{{content:"Item"}}#matriz-estrategica td:nth-child(2):before{{content:"Resposta"}}#matriz-estrategica td:nth-child(3):before{{content:"Evidência ou limitação"}}}}
@media(max-width:520px){{.cards,.metrics,.state-list{{grid-template-columns:1fr}}h1{{font-size:clamp(2.65rem,15vw,4.2rem)}}.verdict{{grid-template-columns:1fr}}.timeline li{{grid-template-columns:1fr}}}}
</style></head><body>
<header id="hero" data-claim-id="CLM-HERO-001"><span class="kicker">Desafio 004 · Desconstrução + choque de realidade</span><h1><em>52.214 publicações.</em><br>Nenhum sinal decisório material.</h1><p class="lead">As diferenças descritivas pequenas observadas nos cortes desta base sintética não sustentam decisões operacionais sobre plataforma, formato, categoria, porte, hashtag, patrocínio, audiência ou período.</p><div class="verdict"><span class="pill">Decisão</span><div><strong>Não usar a base sintética para escolher vencedores.</strong><br>Usar para demonstrar o diagnóstico, corrigir a medição e desenhar testes prospectivos.</div></div>{_evidence("CLM-HERO-001", "CSV congelado e auditoria V2", "comparações agregadas, estabilidade temporal e testes de múltiplas comparações", "base sintética; diferenças descritivas não provam ausência de efeito real")}</header>
<main>
<section id="o-que-gera-engajamento" data-claim-id="CLM-ENGAGEMENT-001"><div class="section-head"><span class="eyebrow">Resposta 01</span><h2>O que gera engajamento?</h2><p>A base descreve uma linha de referência, não um mecanismo causal. Exposição é o denominador; reação, amplificação e conversa são contagens observadas, sem atribuir psicologia ou intenção.</p></div><div class="legend"><div><strong>Exposição</strong><span>visualizações observadas</span></div><div><strong>Reação</strong><span>curtidas</span></div><div><strong>Amplificação</strong><span>compartilhamentos</span></div><div><strong>Conversa</strong><span>comentários</span></div></div><div class="metrics">{metric_cards}</div><div class="callout"><strong>Linha de referência por 1.000 visualizações</strong><p>A linha de referência e todos os cortes usam o mesmo estimando: razão das somas das ações pela soma das visualizações. Ações de profundidade = compartilhamentos + comentários.</p></div><h3>Cortes descritivos</h3>{cut_blocks}<p class="zoom-note">Tabelas têm rolagem própria em telas estreitas e permanecem legíveis em zoom de 125% e 150%.</p>{_evidence("CLM-ENGAGEMENT-001", "data/extracted/social_media_dataset.csv", "razão das somas por 1.000 visualizações em plataforma, tipo, categoria, porte e trimestre", "comparação observacional em dados simulados; não estima causa")}</section>
<section id="qualidade-distribuicao" data-claim-id="CLM-DISTRIBUTION-001"><div class="section-head"><span class="eyebrow">Choque de realidade</span><h2>Uma distribuição artificialmente estreita</h2><p>Período de 29/05/2023 a 28/05/2025. A taxa trimestral ficou entre 19,8993% e 19,9074%, um intervalo estreito demais para sustentar prioridades de negócio.</p></div>{quarter_chart}<div class="cards"><article class="card"><span>Visualizações zero</span><strong>0 linhas</strong></article><article class="card"><span>Curtidas zero</span><strong>0 linhas</strong></article><article class="card"><span>Compartilhamentos zero</span><strong>0 linhas</strong></article><article class="card"><span>Comentários ou interações zero</span><strong>0 linhas</strong></article></div><article class="panel warning"><strong>Leitura correta</strong><p>A base sintética contém variação, mas não contém o comportamento de cauda e os eventos zero esperados em dados operacionais. Não existe limite universal de variância que, sozinho, classifique uma base.</p></article>{_evidence("CLM-DISTRIBUTION-001", "CSV congelado", "mínimos, eventos zero e agregação trimestral ponderada por visualizações", "estreiteza é diagnóstico contextual, não regra universal")}</section>
<section id="identidade" data-claim-id="CLM-IDENTITY-001"><div class="section-head"><span class="eyebrow">Identidade</span><h2>São registros, não influenciadores</h2><p>Os 5.000 identificadores (IDs) aparecem ligados a vários nomes. A chave ID + nome + plataforma produz 52.214 chaves, todas únicas: não há histórico individual confiável.</p></div><div class="two"><article class="panel danger"><h3>5.000 de 5.000</h3><p>IDs ligados a mais de um nome.</p><h3>52.214 de 52.214</h3><p>chaves ID + nome + plataforma aparecem uma única vez.</p></article><div class="table-wrap"><table><thead><tr><th>Plataforma</th><th>Mínimo</th><th>Máximo</th></tr></thead><tbody>{follower_rows}</tbody></table></div></div><p><strong>Rótulo correto:</strong> base de seguidores informada na publicação. Os mínimos vão de 1.013 a 1.156 e os máximos de 999.896 a 999.998, conforme a plataforma.</p><article class="panel warning identity-impact"><strong>Impacto na estratégia</strong><p>Isso significa que a recomendação de investir em criadores de 10 mil a 50 mil seguidores é inviável com esta base, pois ela não rastreia o histórico real de influência de um mesmo indivíduo ao longo do tempo.</p></article>{_evidence("CLM-IDENTITY-001", "CSV congelado", "unicidade de ID, nome e plataforma; amplitude da base informada por plataforma", "a auditoria detecta identidade inconsistente, mas não reconcilia pessoas reais")}</section>
<section id="patrocinio" data-claim-id="CLM-SPONSOR-001"><div class="section-head"><span class="eyebrow">Resposta 02</span><h2>Patrocínio muda o resultado?</h2><p>A comparação bruta é praticamente idêntica e não estima incrementalidade.</p></div><div class="cards"><article class="card"><span>Orgânico</span><strong>19,9059%</strong><small>29.900 publicações</small></article><article class="card"><span>Patrocinado</span><strong>19,9048%</strong><small>22.314 publicações</small></article><article class="card"><span>Diferença</span><strong>−0,0011 pp</strong><small>ponto percentual; patrocinado menos orgânico</small></article></div><div class="two"><article class="panel danger"><h3>O que a auditoria ajustou</h3><p>A estratificação por plataforma, categoria e porte auditou separadamente visualizações, curtidas, compartilhamentos e comentários. Ela não calculou uma taxa composta ajustada. Isso não estima incrementalidade.</p><p><strong>Sem custo, receita ou retorno sobre investimento (ROI).</strong></p></article><article class="panel"><h3>Raízes repetidas</h3><ul><li>28.037 distintas</li><li>6.074 reutilizadas</li><li>30.251 linhas em raízes reutilizadas</li><li>4.361 misturam marcações de orgânico e patrocinado</li></ul><p><strong>Risco financeiro:</strong> com esta base, sem uma URL única por publicação, custo e conversão atribuída, fica matematicamente impossível calcular o Custo de Aquisição de Cliente (CAC) ou auditar o Retorno Sobre Investimento (ROI).</p></article></div>{_evidence("CLM-SPONSOR-001", "CSV e auditoria estratificada congelados", "média da taxa bruta por publicação e diferenças ajustadas apenas dos quatro componentes", "sem taxa composta ajustada, randomização, custo, receita ou atribuição; não há ROI nem efeito causal")}</section>
<section id="audiencia" data-claim-id="CLM-AUDIENCE-001"><div class="section-head"><span class="eyebrow">Resposta 03</span><h2>A audiência diferencia o desempenho?</h2><p>Idade, gênero e localização não apresentam diferenciação robusta. As amplitudes abaixo são de ações de profundidade por 1.000 visualizações, não perfis psicológicos.</p></div><div class="three">{audience_cards}</div><article class="panel warning"><strong>Leitura executiva</strong><p>Diferenças centesimais na base sintética não autorizam segmentação, exclusão ou orçamento por audiência.</p></article>{_evidence("CLM-AUDIENCE-001", "CSV congelado", "amplitude entre médias de compartilhamentos + comentários por 1.000 visualizações nos grupos declarados", "rótulos agregados e simulados; sem controle causal ou validade externa")}</section>
<section id="hashtags" data-claim-id="CLM-HASHTAG-001"><div class="section-head"><span class="eyebrow">Múltiplas comparações</span><h2>Hashtag sem garimpo de significância</h2><p>Os resultados ficam separados para distinguir universo, amostra testada, correção estatística e combinações observadas.</p></div><div class="cards"><article class="card"><span>Termos encontrados</span><strong>{_int(int(hashtags["terms"]))}</strong></article><article class="card"><span>Termos testados</span><strong>{_int(int(hashtags["tested_n_gte_100"]))}</strong><small>100 ou mais publicações</small></article><article class="card"><span>Sinais após correção estatística</span><strong>{hashtag_survivor_label}</strong></article><article class="card"><span>Combinações</span><strong>{_int(int(hashtags["combinations"]))}</strong><small>{_int(int(hashtags["unique_combinations"]))} únicas</small></article></div><article class="panel danger"><strong>Não transformar candidatos em orçamento.</strong><p>Procurar padrões em {_int(int(hashtags["tested_n_gte_100"]))} hashtags cria candidatos que podem parecer vencedores apenas pelo acaso. Depois de controlar esse volume de testes, nenhum manteve evidência suficiente. Alocar orçamento nesses candidatos seria decidir sem evidência estatística corrigida.</p></article><details class="cut method-details"><summary>Como a análise estatística foi calculada</summary><div class="panel"><p>Para cada termo, comparamos presença versus ausência na taxa total por publicação, medimos a diferença média em ações por 1.000 visualizações, calculamos o erro padrão de Welch e uma aproximação normal bilateral via função erfc, e então aplicamos a correção de Holm aos {_int(int(hashtags["tested_n_gte_100"]))} valores de significância, com alfa {_pt(float(hashtags["alpha"]), 2)}. A análise é exploratória; nenhum termo é exibido como vencedor.</p></div></details>{_evidence("CLM-HASHTAG-001", "CSV congelado", "Welch com aproximação normal bilateral e correção de Holm para termos presentes em 100 ou mais publicações", "análise exploratória em base sintética; a aproximação normal não substitui validação prospectiva")}</section>
<section id="o-que-nao-funciona" data-claim-id="CLM-STRATEGY-001"><div class="section-head"><span class="eyebrow">Resposta 04</span><h2>O que não funciona?</h2><p>Classificações por diferenças marginais, caça a hashtags, leitura causal de patrocínio e seleção de microcriadores como vencedores não são sustentadas por esta base.</p></div><div class="two"><article class="panel danger"><h3>Não fazer</h3><ul><li>Nenhuma verba incremental é justificada só pela base sintética.</li><li>Não escolher microcriadores como vencedores.</li><li>Não chamar taxa de engajamento de retorno financeiro.</li></ul></article><article class="panel safe"><h3>Também não fazer</h3><p>Não cortar operações sustentadas por evidência externa. A insuficiência desta base sintética não invalida experimentos, dados financeiros ou conhecimento operacional obtidos fora dela.</p></article></div>{_evidence("CLM-STRATEGY-001", "síntese das afirmações V2", "mapa decisão-evidência e bloqueios explícitos", "aplica-se à base sintética; decisões com evidência externa exigem revisão própria")}</section>
<section id="estrategia" data-claim-id="CLM-STRATEGY-001"><div class="section-head"><span class="eyebrow">Segunda-feira</span><h2>Estratégia em três movimentos</h2><p>Trocar classificação por medição, e medição por experimento somente quando houver potência estatística predefinida.</p></div><div class="three"><article class="priority"><b>1</b><h3>Congelar novas decisões apoiadas só na base sintética</h3><p>Manter decisões existentes somente quando houver evidência externa documentada.</p></article><article class="priority"><b>2</b><h3>Instrumentar identificadores, rastreamento, eventos, custo e receita</h3><p>Usar identificadores estáveis (IDs) e parâmetros de rastreamento de campanha (UTM). Definir unidade, exposição, conversão atribuída e qualidade da interação.</p></article><article class="priority"><b>3</b><h3>Desenhar experimento após plano de potência</h3><p>Contratos continuam apenas como desenho, sem autorização para uso real. O menor efeito relevante para o negócio (SESOI) de +0,5 ponto percentual (pp) é provisório.</p></article></div><article class="panel safe weekly-goal"><strong>A grande meta da semana</strong><p>Nossa meta da semana não é descobrir qual publicação performou melhor em um passado irreal, mas implementar parâmetros de rastreamento de campanha (UTM) e definir desfecho, amostra, potência e atribuição para que o próximo trimestre possa detectar, com desenho prospectivo, variações reais de pelo menos +0,5 pp caso existam.</p></article>{_evidence("CLM-STRATEGY-001", "evidence/decision-map.json e contratos de experimento", "priorização por dependências de decisão e lacunas de mensuração", "não autoriza teste ao vivo nem define tamanho amostral")}</section>
<section id="matriz-estrategica" data-claim-id="CLM-STRATEGY-MATRIX-001"><div class="section-head"><span class="eyebrow">Seis respostas operacionais</span><h2>Matriz explícita de estratégia</h2><p>Cada resposta liga uma ação à evidência disponível ou à limitação que impede estimá-la.</p></div><div class="table-wrap"><table><thead><tr><th>Item</th><th>Resposta</th><th>Evidência ou limitação</th></tr></thead><tbody>{strategy_rows}</tbody></table></div>{_evidence("CLM-STRATEGY-MATRIX-001", "evidence/decision-map.json", "matriz de seis decisões com resposta e evidência ou limitação", "respostas são restritas à base sintética e não autorizam experimento")}</section>
<section id="gatekeeper" data-claim-id="CLM-GATEKEEPER-001"><div class="section-head"><span class="eyebrow">Diferencial</span><h2>Guardião da Qualidade dos Dados</h2><p>Um contrato de decisão que combina evidências. Integridade de arquivo pode passar enquanto identidade, unidade e atribuição tornam a base insuficiente.</p></div><article class="gate-state"><span>Estado desta base</span><code>{gate_state_labels[str(gate["state"])]}</code><p>Não é base corrompida. É uma base sintética íntegra nos bytes, porém insuficiente para decisões operacionais.</p></article><ul class="state-list">{visible_gate_states}</ul><div class="two"><article class="panel"><h3>Regras combinadas</h3><ul class="fact-list">{gate_rows}</ul></article><article class="panel warning"><h3>Sem limite universal</h3><p>Estrutura de colunas, proveniência, identidade, unicidade, unidade, dispersão e covariância, eventos zero, atribuição e múltiplas comparações entram juntos. Nenhum corte universal de variância decide sozinho.</p></article></div>{_evidence("CLM-GATEKEEPER-001", "auditoria, mapa de afirmações e regras V2", "avaliação composta com bloqueio preventivo por finalidade decisória", "estado é específico desta base e deste uso; não é certificação universal")}</section>
<section id="data-trust-gate" data-claim-id="CLM-TRUST-001"><div class="section-head"><span class="eyebrow">Portão de Confiabilidade dos Dados</span><h2>Bytes íntegros, inferência bloqueada</h2><p>O arquivo mantém sua impressão digital SHA-256 congelada, mas a fonte declara simulação. Integridade técnica não equivale a validade de negócio.</p></div><div class="two"><article class="panel safe"><h3>Permitido</h3><p>Prototipagem, exploração descritiva, geração de hipóteses e desenho de experimento.</p></article><article class="panel danger"><h3>Bloqueado</h3><p>Causalidade, retorno sobre investimento (ROI), verba incremental, classificação de criadores e segmentação operacional.</p></article>{_evidence("CLM-TRUST-001", "auditoria e metadados congelados", "impressão digital, checagem de integridade, proveniência e restrições de uso", "não compara a base sintética com dados reais do G4")}</section>
<section id="experimentos" data-claim-id="CLM-EXPERIMENT-001"><div class="section-head"><span class="eyebrow">Somente desenho</span><h2>Experimentos são desenho, não autorização</h2><p>Patrocínio e formato podem ser testados prospectivamente após instrumentação, plano de potência, tamanho amostral, limites de segurança e aprovação humana.</p></div><article class="panel warning"><h3>Menor efeito relevante para o negócio (SESOI): +0,5 ponto percentual (pp), provisório</h3><p>Esse valor é uma hipótese de desenho, não um limite validado pelo negócio.</p></article>{_evidence("CLM-EXPERIMENT-001", "evidence/experiment-contracts.json", "contratos prospectivos com unidade de randomização e critérios exaustivos", "nenhum experimento foi executado; efeitos e amostra permanecem desconhecidos")}</section>
<section id="processo-ia" data-claim-id="CLM-PROCESS-001"><div class="section-head"><span class="eyebrow">Metodologia e IA</span><h2>Gerações rejeitadas ficam visíveis</h2><p>O histórico completo, do EVT-001 ao EVT-020, registra decisão humana, contribuição de IA, testes, bloqueios e aprovações. Os achados da revisão Cética de 90c3a5b foram remediados e aguardam nova revisão autoritativa.</p></div><ol class="timeline">{timeline}</ol>{_evidence("CLM-PROCESS-001", "evidence/process-timeline.json e relatórios históricos", "timeline curada, hashes, testes RED/GREEN e revisões adversariais", "timeline exclui segredos e contexto privado; validação humana final ainda está pendente")}</section>
<section id="glossario" data-claim-id="CLM-GLOSSARY-001"><div class="section-head"><span class="eyebrow">Linguagem simples</span><h2>Glossário</h2><p>Siglas e termos usados nesta página.</p></div><dl class="glossary"><div><dt>Taxa de engajamento</dt><dd>(curtidas + compartilhamentos + comentários) ÷ visualizações. Não é receita.</dd></div><div><dt>Ponto percentual (pp)</dt><dd>Diferença absoluta entre duas porcentagens. De 10% para 11% é +1 pp.</dd></div><div><dt>Menor efeito relevante para o negócio (SESOI)</dt><dd>Menor mudança que justificaria uma decisão. Aqui, +0,5 pp é provisório.</dd></div><div><dt>Parâmetro de rastreamento de campanha (UTM)</dt><dd>Identifica origem, meio e campanha em um endereço rastreável.</dd></div><div><dt>Retorno sobre investimento (ROI)</dt><dd>Exige custo e resultado financeiro atribuível.</dd></div><div><dt>Identificador (ID)</dt><dd>Precisa ser estável para ligar eventos ao mesmo objeto.</dd></div><div><dt>Inteligência artificial (IA)</dt><dd>Usada para análise, crítica, implementação e revisão.</dd></div><div><dt>N ou n</dt><dd>Quantidade de registros incluídos em um cálculo ou grupo.</dd></div><div><dt>Linha de referência</dt><dd>Valor usado para comparação, sem afirmar causa.</dd></div><div><dt>SHA-256</dt><dd>Impressão digital de bytes usada para detectar qualquer mudança no arquivo.</dd></div><div><dt>CRC</dt><dd>Checagem de integridade do arquivo compactado, não de qualidade de negócio.</dd></div><div><dt>Covariância</dt><dd>Medida de como duas variáveis mudam juntas; não prova causalidade.</dd></div><div><dt>Base sintética</dt><dd>Dados simulados usados para demonstrar o sistema, não a operação real.</dd></div><div><dt>Garimpo de significância</dt><dd>Busca seletiva por resultado favorável entre muitos testes, também chamada p-hacking.</dd></div><div><dt>Somente desenho</dt><dd>Experimento desenhado, mas não autorizado para execução ao vivo.</dd></div></dl>{_evidence("CLM-GLOSSARY-001", "contratos e escopo V2", "definições operacionais em pt-BR", "termos são específicos deste protótipo")}</section>
</main><footer>V2 offline, autocontida e determinística · Estado: refinamentos implementados, aguardando revisão · Sem publicação, telemetria ou recursos remotos.</footer></body></html>'''
    return document.encode("utf-8")


def assert_output_safety(payloads: Sequence[bytes]) -> None:
    text = b"\n".join(payloads).decode("utf-8").lower()
    for token in ("http://", "https://", "creator_name", "content_url", "<link", "<script src", "fetch(", "xmlhttprequest", "@import", "url("):
        if token in text:
            raise ValueError(f"token proibido no output: {token}")
    if re.search(r"creator_[0-9]+|content_[0-9]+", text):
        raise ValueError("identificador bruto no output")


def validate_qa_evidence(payload: Mapping[str, object], output_hashes: Mapping[str, str], evidence_sha256: str, root: Path) -> dict[str, object]:
    required = {"schema_version", "status", "index_html_sha256", "prototype_data_sha256", "reviewed_document_path", "reviewed_document_sha256", "browser", "browser_version", "console_errors", "page_errors", "external_network_requests", "console_error_messages", "page_error_messages", "external_request_urls", "viewports"}
    if set(payload) != required or payload.get("schema_version") != 2 or payload.get("status") != "PASSED":
        raise ValueError("evidência QA V2 inválida")
    if payload.get("index_html_sha256") != output_hashes.get("dist/index.html") or payload.get("reviewed_document_sha256") != output_hashes.get("dist/index.html") or payload.get("prototype_data_sha256") != output_hashes.get("evidence/prototype-data.json") or payload.get("reviewed_document_path") != "dist/index.html":
        raise ValueError("QA não está ligada aos outputs atuais")
    for field in ("console_errors", "page_errors", "external_network_requests"):
        if payload.get(field) != 0:
            raise ValueError("QA registra erro")
    for field in ("console_error_messages", "page_error_messages", "external_request_urls"):
        if payload.get(field) != []:
            raise ValueError("QA registra mensagens inesperadas")
    viewports = payload.get("viewports")
    if not isinstance(viewports, list) or len(viewports) != len(QA_CAPTURE_SPECS):
        raise ValueError("inventário de capturas incompleto")
    expected = {spec[0]: spec for spec in QA_CAPTURE_SPECS}
    screenshots = []
    keys = {"name", "width", "height", "target", "zoom_percent", "horizontal_overflow", "vertical_overlap", "screenshot_path", "screenshot_sha256"}
    seen = set()
    for item in viewports:
        if not isinstance(item, dict) or set(item) != keys or item.get("name") not in expected or item["name"] in seen:
            raise ValueError("registro de captura inválido")
        name, width, height, target, zoom = expected[str(item["name"])]
        if (item["width"], item["height"], item["target"], item["zoom_percent"]) != (width, height, target, zoom):
            raise ValueError("contrato de captura diverge")
        if item["horizontal_overflow"] is not False or item["vertical_overlap"] is not False:
            raise ValueError("overflow ou sobreposição detectado")
        expected_path = f"reports/screenshots/{name}.png"
        if item["screenshot_path"] != expected_path or not isinstance(item["screenshot_sha256"], str) or not HASH_RE.fullmatch(item["screenshot_sha256"]):
            raise ValueError("identidade de screenshot inválida")
        path = root / expected_path
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or sha256_file(path) != item["screenshot_sha256"]:
            raise ValueError("screenshot não autenticado")
        # Reabre os bytes reais antes de aceitar o hash.
        reopened = path.read_bytes()
        if sha256_bytes(reopened) != item["screenshot_sha256"] or not reopened:
            raise ValueError("screenshot reaberto diverge")
        screenshots.append({"name": name, "path": expected_path, "sha256": item["screenshot_sha256"], "size_bytes": len(reopened)})
        seen.add(name)
    if seen != set(expected):
        raise ValueError("capturas esperadas ausentes")
    return {"status": "passed", "claimed_complete": True, "evidence_path": "evidence/qa-evidence.json", "evidence_sha256": evidence_sha256, "browser": payload["browser"], "browser_version": payload["browser_version"], "console_errors": 0, "page_errors": 0, "external_network_requests": 0, "screenshots": sorted(screenshots, key=lambda item: item["name"])}


def _write_atomic(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_bytes(data)
    temporary.replace(path)


def _test_evidence(root: Path) -> dict[str, object]:
    path = root / "evidence/test-results.txt"
    if not path.exists():
        return {"status": "pending", "command": CANONICAL_TEST_COMMAND}
    data = path.read_bytes()
    text = data.decode("utf-8", errors="replace")
    match = re.search(r"^Ran (\d+) tests", text, re.MULTILINE)
    standard_ok = bool(re.search(r"^OK\s*$", text, re.MULTILINE))
    failed_summary = bool(re.search(r"^(?:FAILED|ERROR)(?:\s|$)", text, re.MULTILINE))
    passed = bool(match and standard_ok and not failed_summary)
    return {"status": "passed" if passed else "pending", "command": CANONICAL_TEST_COMMAND, "path": "evidence/test-results.txt", "sha256": sha256_bytes(data), "tests_run": int(match.group(1)) if match else 0}


def build_all(root: Path) -> dict[str, object]:
    root = root.resolve()
    for relative in INPUT_PATHS:
        if not (root / relative).is_file():
            raise ValueError(f"input ausente: {relative}")
    claims = load_json(root / "evidence/claim-evidence-map.json")
    claim_records = claims.get("claims")
    if not isinstance(claim_records, list):
        raise ValueError("mapa de claims inválido")
    for claim in claim_records:
        if not isinstance(claim, dict):
            raise ValueError("claim inválido")
        source_path = str(claim.get("source_path", "")).split("#", 1)[0]
        source_hash = claim.get("source_sha256")
        if not source_path or not isinstance(source_hash, str) or not HASH_RE.fullmatch(source_hash):
            raise ValueError("fonte de claim inválida")
        source = root / source_path
        if not source.is_file() or sha256_file(source) != source_hash:
            raise ValueError(f"fonte de claim diverge: {claim.get('claim_id')}")
    timeline = load_json(root / "evidence/process-timeline.json")
    decisions = load_json(root / "evidence/decision-map.json")
    audit = load_json(root / "evidence/dataset-audit.json")
    rows = _read_rows(root / "data/extracted/social_media_dataset.csv")
    data = _build_data(rows, claims, timeline, decisions, audit)
    data_bytes = canonical_json(data)
    html_bytes = render_html(data)
    validate_semantic_maps(claims, decisions, html_bytes.decode("utf-8"))
    assert_output_safety((data_bytes, html_bytes))
    output_hashes = {"dist/index.html": sha256_bytes(html_bytes), "evidence/prototype-data.json": sha256_bytes(data_bytes)}

    visual_qa: dict[str, object] = {"status": "pending", "claimed_complete": False, "evidence_path": "evidence/qa-evidence.json", "reason": "execute QA V2 against current bytes"}
    qa_path = root / "evidence/qa-evidence.json"
    if qa_path.exists():
        qa_bytes = qa_path.read_bytes()
        try:
            payload = json.loads(qa_bytes)
            if isinstance(payload, dict):
                visual_qa = validate_qa_evidence(payload, output_hashes, sha256_bytes(qa_bytes), root)
        except (ValueError, OSError, json.JSONDecodeError):
            pass

    inputs = {relative: {"sha256": sha256_file(root / relative), "size_bytes": (root / relative).stat().st_size} for relative in INPUT_PATHS}
    test_evidence = _test_evidence(root)
    run_identity = {"inputs": inputs, "outputs": output_hashes, "workflow": WORKFLOW_TRANSITION, "qa": visual_qa.get("evidence_sha256", "pending")}
    manifest = {
        "schema_version": 2,
        "run_id": "g4-004-v2-" + sha256_bytes(canonical_json(run_identity))[:16],
        "build_status": "SKEPTIC_REMEDIATION_IMPLEMENTED_PENDING_REVIEW",
        "workflow_transition": WORKFLOW_TRANSITION,
        "entrypoint": "scripts/build_all.py",
        "environment": {"python": sys.version.split()[0], "python_implementation": platform.python_implementation(), "os": platform.system(), "os_release": platform.release(), "machine": platform.machine()},
        "commands": {"build": CANONICAL_BUILD_COMMAND, "tests": CANONICAL_TEST_COMMAND, "visual_qa": CANONICAL_QA_COMMAND},
        "inputs": inputs,
        "outputs": {"dist/index.html": {"sha256": output_hashes["dist/index.html"], "size_bytes": len(html_bytes)}, "evidence/prototype-data.json": {"sha256": output_hashes["evidence/prototype-data.json"], "size_bytes": len(data_bytes)}},
        "determinism": {"timestamps_embedded": False, "canonical_json": True, "stable_sorting": True},
        "tests": test_evidence,
        "visual_qa": visual_qa,
        "historical_rejected_generations_preserved": True,
        "publication": {"status": "blocked_pending_human_review", "external_actions": False},
    }
    manifest_bytes = canonical_json(manifest)
    assert_output_safety((manifest_bytes,))
    if len(html_bytes) >= 5 * 1024 * 1024 or len(data_bytes) >= 1024 * 1024 or len(manifest_bytes) >= 128 * 1024:
        raise ValueError("output excede limite")
    _write_atomic(root / "evidence/prototype-data.json", data_bytes)
    _write_atomic(root / "dist/index.html", html_bytes)
    _write_atomic(root / "evidence/build-manifest.json", manifest_bytes)
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    manifest = build_all(args.root)
    print(json.dumps({"status": manifest["build_status"], "outputs": manifest["outputs"], "visual_qa": manifest["visual_qa"]["status"]}, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
