#!/usr/bin/env python3
"""Deterministic, dependency-free audit of the Challenge 004 dataset."""

from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
import math
import stat
import statistics
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Iterable, Sequence
from zipfile import ZipFile

NUMERIC_COLUMNS = (
    "content_length",
    "views",
    "likes",
    "shares",
    "comments_count",
    "follower_count",
)
CATEGORICAL_COLUMNS = (
    "platform",
    "content_type",
    "content_category",
    "language",
    "is_sponsored",
    "disclosure_type",
    "sponsor_category",
    "disclosure_location",
    "audience_age_distribution",
    "audience_gender_distribution",
    "audience_location",
)
METRICS = ("views", "likes", "shares", "comments_count")
EXPECTED_CHALLENGE_BRIEF_SHA256 = "1a8d1879d8e2ffed9a5cd51b524663da237b2fc4133892e27de9bff29c9c3f87"
EXPECTED_DATASET_METADATA_SHA256 = "9f8e2fd522d039c76f509f41e23cdf5ab5c85969c732e630ec130ada7e88e2fd"
HARD_MAX_ARCHIVE_BYTES = 100 * 1024 * 1024
HARD_MAX_MEMBER_BYTES = 100 * 1024 * 1024
HARD_MAX_EXPANSION_RATIO = 100.0
SESOI_FRACTION_OF_ORGANIC_MEAN = 0.005
EXPECTED_COLUMNS = (
    "id",
    "platform",
    "content_id",
    "creator_id",
    "creator_name",
    "content_url",
    "content_type",
    "content_category",
    "post_date",
    "language",
    "content_length",
    "content_description",
    "hashtags",
    "views",
    "likes",
    "shares",
    "comments_count",
    "comments_text",
    "follower_count",
    "is_sponsored",
    "disclosure_type",
    "sponsor_name",
    "sponsor_category",
    "disclosure_location",
    "audience_age_distribution",
    "audience_gender_distribution",
    "audience_location",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def quantile(values: Sequence[float], probability: float) -> float:
    if not values:
        raise ValueError("quantile requires at least one value")
    if not 0.0 <= probability <= 1.0:
        raise ValueError("probability must be between 0 and 1")
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = position - lower
    return ordered[lower] + (ordered[upper] - ordered[lower]) * fraction


def pearson(left: Sequence[float], right: Sequence[float]) -> float:
    if len(left) != len(right) or len(left) < 2:
        raise ValueError("pearson requires equal sequences with at least two values")
    mean_left = statistics.fmean(left)
    mean_right = statistics.fmean(right)
    numerator = sum((x - mean_left) * (y - mean_right) for x, y in zip(left, right))
    denominator = math.sqrt(
        sum((x - mean_left) ** 2 for x in left)
        * sum((y - mean_right) ** 2 for y in right)
    )
    if denominator == 0.0:
        raise ValueError("pearson is undefined for a constant sequence")
    return numerator / denominator


def numeric_summary(values: Sequence[float]) -> dict[str, float]:
    return {
        "min": min(values),
        "q25": quantile(values, 0.25),
        "median": quantile(values, 0.50),
        "mean": statistics.fmean(values),
        "q75": quantile(values, 0.75),
        "max": max(values),
        "population_sd": statistics.pstdev(values),
    }


def effect_with_ci(left: Sequence[float], right: Sequence[float]) -> dict[str, object]:
    mean_left = statistics.fmean(left)
    mean_right = statistics.fmean(right)
    difference = mean_left - mean_right
    variance_left = statistics.variance(left)
    variance_right = statistics.variance(right)
    standard_error = math.sqrt(variance_left / len(left) + variance_right / len(right))
    pooled_sd = math.sqrt(
        ((len(left) - 1) * variance_left + (len(right) - 1) * variance_right)
        / (len(left) + len(right) - 2)
    )
    low = difference - 1.96 * standard_error
    high = difference + 1.96 * standard_error
    sesoi = SESOI_FRACTION_OF_ORGANIC_MEAN * abs(mean_right)
    return {
        "sponsored_n": len(left),
        "organic_n": len(right),
        "sponsored_mean": mean_left,
        "organic_mean": mean_right,
        "difference": difference,
        "difference_ci95": [low, high],
        "ci_method": "normal approximation for Welch standard error",
        "cohen_d": difference / pooled_sd,
        "declared_sesoi": sesoi,
        "sesoi_definition": "illustrative ±0.5% of the organic mean; business validation required",
        "equivalent_within_declared_sesoi": low > -sesoi and high < sesoi,
    }


def validate_archive(archive_path: Path, csv_path: Path) -> dict[str, object]:
    if archive_path.stat().st_size > HARD_MAX_ARCHIVE_BYTES:
        raise ValueError("archive exceeds hard size limit")
    with ZipFile(archive_path) as archive:
        infos = archive.infolist()
        if len(infos) != 1:
            raise ValueError("archive must contain exactly one member")
        info = infos[0]
        member_path = PurePosixPath(info.filename)
        safe_name = (
            not member_path.is_absolute()
            and ".." not in member_path.parts
            and "\\" not in info.filename
            and info.filename == "social_media_dataset.csv"
        )
        if not safe_name or info.is_dir():
            raise ValueError("unsafe or unexpected archive member")
        unix_mode = (info.external_attr >> 16) & 0xFFFF
        if unix_mode and not stat.S_ISREG(unix_mode):
            raise ValueError("archive member is not a regular file")
        if info.file_size > HARD_MAX_MEMBER_BYTES:
            raise ValueError("archive member exceeds hard size limit")
        expansion_ratio = info.file_size / max(info.compress_size, 1)
        if expansion_ratio >= HARD_MAX_EXPANSION_RATIO:
            raise ValueError("archive expansion ratio exceeds hard limit")
        if archive.testzip() is not None:
            raise ValueError("archive CRC validation failed")
        member_digest = hashlib.sha256()
        with archive.open(info) as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                member_digest.update(chunk)
    csv_digest = sha256_file(csv_path)
    if member_digest.hexdigest() != csv_digest:
        raise ValueError("archive member and extracted CSV hashes differ")
    return {
        "member_count": 1,
        "member_name": info.filename,
        "member_compressed_bytes": info.compress_size,
        "member_uncompressed_bytes": info.file_size,
        "expansion_ratio": expansion_ratio,
        "hard_max_expansion_ratio": HARD_MAX_EXPANSION_RATIO,
        "safe_member_name": safe_name,
        "regular_file": True,
        "crc_pass": True,
        "member_sha256": member_digest.hexdigest(),
        "member_matches_csv_sha256": True,
    }


def load_source_evidence(challenge_brief_path: Path, dataset_metadata_path: Path) -> dict[str, object]:
    challenge_sha = sha256_file(challenge_brief_path)
    metadata_sha = sha256_file(dataset_metadata_path)
    if challenge_sha != EXPECTED_CHALLENGE_BRIEF_SHA256:
        raise ValueError("challenge brief snapshot hash mismatch")
    if metadata_sha != EXPECTED_DATASET_METADATA_SHA256:
        raise ValueError("dataset metadata snapshot hash mismatch")
    brief = challenge_brief_path.read_text(encoding="utf-8")
    metadata = json.loads(dataset_metadata_path.read_text(encoding="utf-8"))
    description = str(metadata.get("description", ""))
    simulated = "simulate realistic influencer posts" in description.lower()
    challenge_mentions_engagement_rate = "Engagement rate" in brief
    if not simulated:
        raise ValueError("frozen dataset metadata does not declare simulated data")
    if not challenge_mentions_engagement_rate:
        raise ValueError("frozen challenge brief does not mention engagement rate")
    return {
        "repository": "https://github.com/Gestao-Quatro-Ponto-Zero/ai-master-challenge",
        "repository_commit": "4aed364d572fabe0f1fff1f0c6f32960b30fe575",
        "challenge": "marketing-004-social",
        "dataset_page": str(metadata.get("url")),
        "dataset_ref": str(metadata.get("ref")),
        "dataset_version": int(metadata["currentVersionNumber"]),
        "dataset_last_updated": str(metadata.get("lastUpdated")),
        "license": str(metadata["licenseName"]),
        "metadata_declares_simulated": simulated,
        "challenge_mentions_engagement_rate": challenge_mentions_engagement_rate,
        "challenge_brief_sha256": challenge_sha,
        "dataset_metadata_sha256": metadata_sha,
    }


def load_rows(csv_path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with csv_path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        columns = list(reader.fieldnames or [])
        rows = list(reader)
    if tuple(columns) != EXPECTED_COLUMNS:
        raise ValueError(f"unexpected columns: {columns!r}")
    if any(None in row for row in rows):
        raise ValueError("one or more rows have extra fields")
    return columns, rows


def parse_numeric_column(rows: Sequence[dict[str, str]], column: str) -> list[float]:
    parsed: list[float] = []
    for index, row in enumerate(rows, start=2):
        try:
            value = float(row[column])
        except (TypeError, ValueError) as exc:
            raise ValueError(f"invalid numeric value in {column} at CSV row {index}") from exc
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"non-finite or negative value in {column} at CSV row {index}")
        parsed.append(value)
    return parsed


def count_values(rows: Iterable[dict[str, str]], column: str) -> dict[str, int]:
    return dict(sorted(collections.Counter(row[column] for row in rows).items()))


def follower_band(value: str) -> str:
    followers = int(value)
    if followers <= 10_000:
        return "001k-010k"
    if followers <= 50_000:
        return "010k-050k"
    if followers <= 100_000:
        return "050k-100k"
    if followers <= 500_000:
        return "100k-500k"
    return "500k+"


def adjusted_sponsorship_effects(rows: Sequence[dict[str, str]]) -> dict[str, object]:
    strata: dict[tuple[str, str, str], dict[str, list[dict[str, str]]]] = collections.defaultdict(
        lambda: {"TRUE": [], "FALSE": []}
    )
    for row in rows:
        key = (row["platform"], row["content_category"], follower_band(row["follower_count"]))
        strata[key][row["is_sponsored"]].append(row)
    eligible = [groups for groups in strata.values() if len(groups["TRUE"]) >= 2 and len(groups["FALSE"]) >= 2]
    total = sum(len(groups["TRUE"]) + len(groups["FALSE"]) for groups in eligible)
    metrics: dict[str, dict[str, object]] = {}
    for metric in METRICS:
        difference = 0.0
        variance = 0.0
        organic_reference = 0.0
        for groups in eligible:
            sponsored = [float(row[metric]) for row in groups["TRUE"]]
            organic = [float(row[metric]) for row in groups["FALSE"]]
            weight = (len(sponsored) + len(organic)) / total
            difference += weight * (statistics.fmean(sponsored) - statistics.fmean(organic))
            organic_reference += weight * statistics.fmean(organic)
            variance += weight**2 * (
                statistics.variance(sponsored) / len(sponsored)
                + statistics.variance(organic) / len(organic)
            )
        standard_error = math.sqrt(variance)
        low = difference - 1.96 * standard_error
        high = difference + 1.96 * standard_error
        sesoi = SESOI_FRACTION_OF_ORGANIC_MEAN * abs(organic_reference)
        metrics[metric] = {
            "difference": difference,
            "difference_ci95": [low, high],
            "ci_method": "normal approximation over weighted independent-stratum variances",
            "declared_sesoi": sesoi,
            "equivalent_within_declared_sesoi": low > -sesoi and high < sesoi,
        }
    return {
        "method": "stratified standardization by platform, content_category and follower_band",
        "follower_bands": ["001k-010k", "010k-050k", "050k-100k", "100k-500k", "500k+"],
        "eligible_strata": len(eligible),
        "eligible_rows": total,
        "metrics": metrics,
    }


def build_audit(
    csv_path: Path,
    archive_path: Path,
    challenge_brief_path: Path,
    dataset_metadata_path: Path,
) -> dict[str, object]:
    source = load_source_evidence(challenge_brief_path, dataset_metadata_path)
    archive_validation = validate_archive(archive_path, csv_path)
    columns, rows = load_rows(csv_path)
    numeric = {
        column: parse_numeric_column(rows, column)
        for column in NUMERIC_COLUMNS
    }

    missing = {
        column: {
            "count": sum(not row[column].strip() for row in rows),
            "rate": sum(not row[column].strip() for row in rows) / len(rows),
        }
        for column in columns
        if any(not row[column].strip() for row in rows)
    }

    uniqueness: dict[str, dict[str, int]] = {}
    for column in ("id", "content_id", "creator_id", "creator_name", "content_url"):
        counts = collections.Counter(row[column] for row in rows)
        uniqueness[column] = {
            "unique_count": len(counts),
            "duplicate_excess_rows": sum(value - 1 for value in counts.values() if value > 1),
            "maximum_frequency": max(counts.values()),
        }

    exact_duplicate_rows = len(rows) - len({tuple(row[column] for column in columns) for row in rows})

    creators: dict[str, list[dict[str, str]]] = collections.defaultdict(list)
    for row in rows:
        creators[row["creator_id"]].append(row)
    name_counts = [len({row["creator_name"] for row in group}) for group in creators.values()]
    follower_ranges = [
        max(int(row["follower_count"]) for row in group)
        - min(int(row["follower_count"]) for row in group)
        for group in creators.values()
    ]

    urls: dict[str, list[dict[str, str]]] = collections.defaultdict(list)
    for row in rows:
        urls[row["content_url"]].append(row)

    sponsored = [row for row in rows if row["is_sponsored"] == "TRUE"]
    organic = [row for row in rows if row["is_sponsored"] == "FALSE"]
    sponsorship_effects = {
        metric: effect_with_ci(
            [float(row[metric]) for row in sponsored],
            [float(row[metric]) for row in organic],
        )
        for metric in METRICS
    }
    adjusted_effects = adjusted_sponsorship_effects(rows)

    group_spreads: dict[str, dict[str, dict[str, float]]] = {}
    for category in ("platform", "content_type", "content_category", "audience_location"):
        grouped: dict[str, list[dict[str, str]]] = collections.defaultdict(list)
        for row in rows:
            grouped[row[category]].append(row)
        group_spreads[category] = {}
        for metric in METRICS:
            group_means = {
                name: statistics.fmean(float(row[metric]) for row in group)
                for name, group in grouped.items()
            }
            overall = statistics.fmean(numeric[metric])
            spread = max(group_means.values()) - min(group_means.values())
            between_sum_squares = sum(
                len(group) * (group_means[name] - overall) ** 2
                for name, group in grouped.items()
            )
            total_sum_squares = sum((value - overall) ** 2 for value in numeric[metric])
            group_spreads[category][metric] = {
                "minimum_group_mean": min(group_means.values()),
                "maximum_group_mean": max(group_means.values()),
                "absolute_spread": spread,
                "spread_percent_of_overall_mean": 100.0 * spread / overall,
                "eta_squared": between_sum_squares / total_sum_squares,
            }

    dates = [datetime.strptime(row["post_date"], "%m/%d/%y %I:%M %p") for row in rows]
    gaps_minutes = [
        (right - left).total_seconds() / 60.0
        for left, right in zip(dates, dates[1:])
    ]

    content_ids = sorted(int(row["content_id"].removeprefix("content_")) for row in rows)
    content_ids_contiguous = content_ids == list(range(content_ids[0], content_ids[-1] + 1))

    disclosure_checks = {
        "organic_with_non_none_disclosure": sum(
            row["is_sponsored"] == "FALSE" and row["disclosure_type"] != "none"
            for row in rows
        ),
        "organic_with_sponsor_name": sum(
            row["is_sponsored"] == "FALSE" and row["sponsor_name"] != "Not sponsors"
            for row in rows
        ),
        "organic_with_sponsor_category": sum(
            row["is_sponsored"] == "FALSE" and row["sponsor_category"] != "Not sponsors"
            for row in rows
        ),
        "organic_with_disclosure_location": sum(
            row["is_sponsored"] == "FALSE" and row["disclosure_location"] != "none"
            for row in rows
        ),
        "sponsored_with_none_disclosure": sum(
            row["is_sponsored"] == "TRUE" and row["disclosure_type"] == "none"
            for row in rows
        ),
    }

    correlations = {
        "views_vs_likes": pearson(numeric["views"], numeric["likes"]),
        "views_vs_shares": pearson(numeric["views"], numeric["shares"]),
        "views_vs_comments": pearson(numeric["views"], numeric["comments_count"]),
        "followers_vs_views": pearson(numeric["follower_count"], numeric["views"]),
        "followers_vs_likes": pearson(numeric["follower_count"], numeric["likes"]),
        "content_length_vs_views": pearson(numeric["content_length"], numeric["views"]),
    }

    findings = [
        {
            "id": "F-001",
            "severity": "critical-for-inference",
            "finding": "O data card da fonte descreve explicitamente o dataset como simulado.",
            "decision": "Não apresentar os achados como performance observada do G4, verdade causal ou ROI de produção.",
        },
        {
            "id": "F-002",
            "severity": "high",
            "finding": "Todo creator_id está associado a múltiplos creator_name e a contagem de seguidores varia drasticamente dentro do mesmo creator_id.",
            "decision": "Bloquear análise longitudinal por creator e recomendações específicas de creators.",
        },
        {
            "id": "F-003",
            "severity": "high",
            "finding": "As correlações lineares marginais analisadas estão próximas de zero e os spreads de médias entre grupos são muito pequenos.",
            "decision": "Não interpretar isso como independência geral. Tratar rankings marginais como evidência insuficiente e investigar relações condicionais apenas como exploração da fixture sintética.",
        },
        {
            "id": "F-004",
            "severity": "high",
            "finding": "A comparação bruta e a comparação estratificada não detectam diferença média entre patrocinado e orgânico; os ICs ficam dentro de uma SESOI ilustrativa de ±0,5% da média orgânica.",
            "decision": "A SESOI precisa de validação de negócio. O resultado não autoriza causalidade, ROI ou política de patrocínio, mas autoriza registrar ausência de diferença detectável na fixture.",
        },
        {
            "id": "F-005",
            "severity": "medium",
            "finding": "O brief do repositório menciona engagement rate, mas o CSV não contém a coluna engagement_rate.",
            "decision": "Definir explicitamente qualquer métrica de engajamento derivada e não chamá-la de ROI financeiro.",
        },
        {
            "id": "F-006",
            "severity": "medium",
            "finding": "Milhares de valores de content_url são reutilizados entre creators diferentes.",
            "decision": "Não tratar content_url como identificador estável de post e não acessar as URLs geradas.",
        },
    ]

    return {
        "schema_version": 2,
        "source": source,
        "archive_validation": archive_validation,
        "dataset": {
            "archive_path": str(archive_path),
            "archive_size_bytes": archive_path.stat().st_size,
            "archive_sha256": sha256_file(archive_path),
            "csv_path": str(csv_path),
            "csv_size_bytes": csv_path.stat().st_size,
            "csv_sha256": sha256_file(csv_path),
            "row_count": len(rows),
            "column_count": len(columns),
            "columns": columns,
            "exact_duplicate_rows": exact_duplicate_rows,
            "content_id_range": [content_ids[0], content_ids[-1]],
            "content_ids_contiguous": content_ids_contiguous,
            "engagement_rate_column_present": "engagement_rate" in columns,
        },
        "missing_values": missing,
        "categorical_counts": {
            column: count_values(rows, column) for column in CATEGORICAL_COLUMNS
        },
        "numeric_summaries": {
            column: numeric_summary(values) for column, values in numeric.items()
        },
        "uniqueness": uniqueness,
        "entity_integrity": {
            "creator_id_count": len(creators),
            "creator_ids_with_multiple_names": sum(value > 1 for value in name_counts),
            "median_distinct_names_per_creator_id": statistics.median(name_counts),
            "maximum_distinct_names_per_creator_id": max(name_counts),
            "median_follower_range_per_creator": statistics.median(follower_ranges),
            "maximum_follower_range_per_creator": max(follower_ranges),
            "creator_ids_with_follower_range_over_500k": sum(value > 500_000 for value in follower_ranges),
            "reused_urls": sum(len(group) > 1 for group in urls.values()),
            "reused_urls_across_creator_ids": sum(
                len({row["creator_id"] for row in group}) > 1 for group in urls.values()
            ),
        },
        "disclosure_consistency": disclosure_checks,
        "correlations": correlations,
        "sponsorship_effects": sponsorship_effects,
        "adjusted_sponsorship_effects": adjusted_effects,
        "group_mean_spreads": group_spreads,
        "temporal_structure": {
            "minimum": min(dates).isoformat(),
            "maximum": max(dates).isoformat(),
            "rows_are_monotonic_by_date": all(left <= right for left, right in zip(dates, dates[1:])),
            "gap_minutes": numeric_summary(gaps_minutes),
            "zero_minute_gaps": sum(value == 0.0 for value in gaps_minutes),
        },
        "findings": findings,
        "decision_contract": {
            "allowed": [
                "Demonstrar um gate reproduzível de qualidade dos dados.",
                "Demonstrar análise descritiva controlada sobre a fixture do challenge.",
                "Gerar hipóteses e experimentos para validação com dados primários reais.",
                "Construir um protótipo explicável com confiança explícita e estados de bloqueio.",
            ],
            "blocked": [
                "Afirmar efeitos causais de patrocínio ou atributos de conteúdo.",
                "Afirmar ROI financeiro sem custo de campanha e receita atribuível.",
                "Recomendar creators específicos com base em entidades instáveis.",
                "Apresentar rankings sintéticos como verdade operacional do G4.",
            ],
            "overall_status": "SUITABLE_FOR_PROTOTYPE_NOT_FOR_BUSINESS_INFERENCE",
        },
    }


def format_number(value: float) -> str:
    return f"{value:,.4f}".replace(",", "_").replace(".", ",").replace("_", ".")


def render_markdown(audit: dict[str, object]) -> str:
    dataset = audit["dataset"]
    source = audit["source"]
    archive = audit["archive_validation"]
    entity = audit["entity_integrity"]
    effects = audit["sponsorship_effects"]
    adjusted = audit["adjusted_sponsorship_effects"]
    correlations = audit["correlations"]
    findings = audit["findings"]
    decision = audit["decision_contract"]
    missing = audit["missing_values"]
    disclosure = audit["disclosure_consistency"]
    temporal = audit["temporal_structure"]
    spreads = audit["group_mean_spreads"]

    lines = [
        "# Auditoria do Dataset: Challenge 004",
        "",
        "> Auditoria reproduzível dos bytes adquiridos do Kaggle. O objetivo é determinar quais decisões os dados autorizam e quais devem ser bloqueadas.",
        "",
        "## Veredito executivo",
        "",
        f"**Status:** `{decision['overall_status']}`",
        "",
        "O dataset serve como fixture para demonstrar um sistema analítico, mas não valida uma estratégia real de social media. A fonte congelada o declara simulado, as entidades de creator são instáveis e as relações lineares marginais observadas são próximas de zero. Isso não prova independência geral e não substitui análise condicional nem dados reais.",
        "",
        "## Proveniência congelada",
        "",
        f"- Commit do brief: `{source['repository_commit']}`",
        f"- SHA-256 do brief: `{source['challenge_brief_sha256']}`",
        f"- SHA-256 da metadata Kaggle: `{source['dataset_metadata_sha256']}`",
        f"- Versão Kaggle: {source['dataset_version']}",
        f"- Licença reportada: {source['license']}",
        f"- Metadata declara simulação: {source['metadata_declares_simulated']}",
        f"- Brief menciona engagement rate: {source['challenge_mentions_engagement_rate']}",
        "",
        "## Identidade e vínculo dos dados",
        "",
        f"- ZIP: `{dataset['archive_sha256']}` ({dataset['archive_size_bytes']} bytes)",
        f"- CSV: `{dataset['csv_sha256']}` ({dataset['csv_size_bytes']} bytes)",
        f"- ZIP: {archive['member_count']} membro, CRC válido={archive['crc_pass']}, nome seguro={archive['safe_member_name']}",
        f"- Hash do membro igual ao CSV: {archive['member_matches_csv_sha256']}",
        f"- Expansão ZIP: {format_number(archive['expansion_ratio'])}×, teto {format_number(archive['hard_max_expansion_ratio'])}×",
        f"- Linhas: {dataset['row_count']}",
        f"- Colunas: {dataset['column_count']}",
        f"- Duplicatas exatas: {dataset['exact_duplicate_rows']}",
        f"- Coluna `engagement_rate`: {'presente' if dataset['engagement_rate_column_present'] else 'ausente'}",
        "",
        "## Achados bloqueadores",
        "",
    ]
    for item in findings:
        lines.extend([
            f"### {item['id']} | {item['severity']}",
            "",
            str(item["finding"]),
            "",
            f"**Implicação:** {item['decision']}",
            "",
        ])

    lines.extend([
        "## Missingness e consistência",
        "",
        f"- Hashtags ausentes: {missing['hashtags']['count']} ({format_number(100 * missing['hashtags']['rate'])}%)",
        f"- Texto de comentários ausente: {missing['comments_text']['count']} ({format_number(100 * missing['comments_text']['rate'])}%)",
        f"- Inconsistências de disclosure: {sum(disclosure.values())}",
        "",
        "## Integridade da entidade creator",
        "",
        f"- Creator IDs: {entity['creator_id_count']}",
        f"- Creator IDs associados a múltiplos nomes: {entity['creator_ids_with_multiple_names']}",
        f"- Mediana de nomes distintos por creator ID: {format_number(entity['median_distinct_names_per_creator_id'])}",
        f"- Mediana da amplitude de seguidores dentro do mesmo creator ID: {format_number(entity['median_follower_range_per_creator'])}",
        f"- URLs reutilizadas entre creators diferentes: {entity['reused_urls_across_creator_ids']}",
        "",
        "Conclusão: `creator_id` não representa uma entidade estável. Análises longitudinais ou recomendações por creator ficam bloqueadas.",
        "",
        "## Estrutura temporal",
        "",
        f"- Início: {temporal['minimum']}",
        f"- Fim: {temporal['maximum']}",
        f"- Ordenação monotônica: {temporal['rows_are_monotonic_by_date']}",
        f"- Mediana do intervalo: {format_number(temporal['gap_minutes']['median'])} minutos",
        f"- Intervalos de zero minuto: {temporal['zero_minute_gaps']}",
        "",
        "## Spreads entre grupos",
        "",
        "| Dimensão | Métrica | Spread % da média | Eta² |",
        "|---|---|---:|---:|",
    ])
    for dimension, metrics in spreads.items():
        for metric, item in metrics.items():
            lines.append(
                f"| {dimension} | {metric} | {format_number(item['spread_percent_of_overall_mean'])}% | {format_number(item['eta_squared'])} |"
            )

    lines.extend([
        "",
        "Spreads e Eta² pequenos indicam pouca separação marginal nesta fixture. Eles não provam ausência de relações não lineares ou interações.",
        "",
        "## Patrocinado versus orgânico",
        "",
        "Método do IC: aproximação normal com erro-padrão de Welch. SESOI ilustrativa: ±0,5% da média orgânica; deve ser validada pelo negócio antes de uso real.",
        "",
        "| Métrica | N patrocinado | N orgânico | Diferença | IC 95% | Cohen d | Equivalente na SESOI? |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ])
    for metric in METRICS:
        item = effects[metric]
        low, high = item["difference_ci95"]
        lines.append(
            f"| {metric} | {item['sponsored_n']} | {item['organic_n']} | {format_number(item['difference'])} | [{format_number(low)}, {format_number(high)}] | {format_number(item['cohen_d'])} | {item['equivalent_within_declared_sesoi']} |"
        )

    lines.extend([
        "",
        "## Patrocinado versus orgânico com ajuste",
        "",
        f"Método: {adjusted['method']}. Estratos elegíveis: {adjusted['eligible_strata']}; linhas elegíveis: {adjusted['eligible_rows']}.",
        "",
        "| Métrica | Diferença ajustada | IC 95% | Equivalente na SESOI? |",
        "|---|---:|---:|---:|",
    ])
    for metric in METRICS:
        item = adjusted["metrics"][metric]
        low, high = item["difference_ci95"]
        lines.append(
            f"| {metric} | {format_number(item['difference'])} | [{format_number(low)}, {format_number(high)}] | {item['equivalent_within_declared_sesoi']} |"
        )

    lines.extend([
        "",
        "Resultado descritivo da fixture: não foi detectada diferença média relevante sob a SESOI ilustrativa, inclusive após estratificação. Isso não autoriza inferência causal, ROI ou política de patrocínio.",
        "",
        "## Relações lineares marginais",
        "",
        "| Relação | Correlação de Pearson |",
        "|---|---:|",
    ])
    labels = {
        "views_vs_likes": "views × likes",
        "views_vs_shares": "views × shares",
        "views_vs_comments": "views × comments",
        "followers_vs_views": "followers × views",
        "followers_vs_likes": "followers × likes",
        "content_length_vs_views": "content length × views",
    }
    for key, label in labels.items():
        lines.append(f"| {label} | {format_number(correlations[key])} |")

    lines.extend([
        "",
        "As correlações lineares marginais estão próximas de zero. O resultado não exclui dependência não linear, interações, confundimento ou efeitos condicionais.",
        "",
        "## Decisões autorizadas",
        "",
    ])
    lines.extend(f"- {item}" for item in decision["allowed"])
    lines.extend(["", "## Decisões bloqueadas", ""])
    lines.extend(f"- {item}" for item in decision["blocked"])
    lines.extend([
        "",
        "## Recomendação para a submissão",
        "",
        "Manter o Challenge 004 em duas camadas: Data Trust Gate e análise exploratória claramente rotulada da fixture. A entrega deve mostrar o sistema funcionando, bloquear recomendações sem sustentação e propor coleta de dados reais e experimentos para responder patrocínio, conteúdo, creator e audiência.",
        "",
        "## Reprodução",
        "",
        "```bash",
        "PYTHONDONTWRITEBYTECODE=1 python3 -B scripts/audit_dataset.py \\",
        "  --csv data/extracted/social_media_dataset.csv \\",
        "  --archive data/raw/social-media-sponsorship-and-engagement-dataset.zip \\",
        "  --challenge-brief evidence/sources/challenge-004-README.md \\",
        "  --dataset-metadata evidence/sources/kaggle-dataset-metadata.json \\",
        "  --json-output evidence/dataset-audit.json \\",
        "  --markdown-output reports/dataset-audit.md",
        "PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest discover -v",
        "```",
        "",
    ])
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True, type=Path)
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--challenge-brief", required=True, type=Path)
    parser.add_argument("--dataset-metadata", required=True, type=Path)
    parser.add_argument("--json-output", required=True, type=Path)
    parser.add_argument("--markdown-output", required=True, type=Path)
    args = parser.parse_args()

    audit = build_audit(
        args.csv,
        args.archive,
        args.challenge_brief,
        args.dataset_metadata,
    )
    args.json_output.parent.mkdir(parents=True, exist_ok=True)
    args.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    args.json_output.write_text(
        json.dumps(audit, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    args.markdown_output.write_text(render_markdown(audit), encoding="utf-8")
    print(json.dumps({
        "status": audit["decision_contract"]["overall_status"],
        "rows": audit["dataset"]["row_count"],
        "json_output": str(args.json_output),
        "markdown_output": str(args.markdown_output),
    }, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
