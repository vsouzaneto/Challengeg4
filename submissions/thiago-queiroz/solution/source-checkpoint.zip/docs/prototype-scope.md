# Escopo do protótipo V2: Desconstrução + Choque de Realidade

## Estado

`EXECUTIVE_REFINEMENT_IMPLEMENTED_PENDING_REVIEW -> SKEPTIC_REMEDIATION_IMPLEMENTED_PENDING_REVIEW`

A V2 substitui o painel anterior por uma narrativa executiva offline. A tese é restrita: 52.214 publicações contêm diferenças descritivas pequenas que não sustentam decisões operacionais sobre verba, criador, plataforma, formato, categoria, porte, hashtag, audiência, patrocínio ou período. Isso não prova ausência de efeitos reais, relações não lineares ou interações.

## Quatro respostas analíticas

1. **O que gera engajamento?** Exibir uma linha de referência por 1.000 visualizações para curtidas, compartilhamentos, comentários e ações de profundidade, com cortes por plataforma, tipo, categoria, porte e trimestre. A linha de referência e os cortes usam o mesmo estimando: razão das somas das ações pela soma das visualizações.
2. **Patrocínio muda o resultado?** Mostrar taxas brutas orgânica e patrocinada, repetição de raízes e ausência de custo, receita e retorno sobre investimento (ROI). A taxa composta bruta é média das razões por publicação: 19,9048% patrocinado versus 19,9059% orgânico, diferença de −0,0011 ponto percentual. A auditoria estratificada ajusta apenas visualizações, curtidas, compartilhamentos e comentários; não calcula taxa composta ajustada.
3. **A audiência diferencia o desempenho?** Mostrar idade, gênero e localização, incluindo amplitudes verificadas de ações de profundidade, sem segmentação operacional.
4. **O que não funciona?** Bloquear classificações marginais, garimpo de significância, verba incremental e escolha de microcriadores como vencedores.

## Matriz estratégica obrigatória

| Item | Resposta | Evidência ou limitação |
|---|---|---|
| Onde concentrar esforço | Instrumentação e qualidade dos dados. | Identidade instável, atribuição ausente e fonte sintética. |
| Frequência de postagem | RISCO ALTO: BASE INSUFICIENTE. | Sem desenho que isole frequência ou conta estável. |
| Política de patrocínio | Nenhuma verba incremental apenas com esta base; não cortar ações sustentadas por evidência externa. | Sem custo, receita, randomização ou atribuição causal. |
| Perfil e limiar de influenciador | RISCO ALTO: IDENTIDADE NÃO RASTREÁVEL; microcriador não é vencedor nesta base. | O identificador de criador não mantém identidade longitudinal. |
| O que parar | Parar a caça a classificações e correlações aleatórias. | Diferenças marginais pequenas e muitas comparações. |
| Ganhos rápidos desta semana | Criar identificadores estáveis, endereço único com parâmetros UTM, eventos, custo e receita; especificar o plano de potência sem executar experimento. | Pré-requisitos de medição; teste ao vivo não autorizado. |

## Hashtags

O método determinístico compara, para cada termo, a taxa total por publicação quando o termo está presente versus ausente. O efeito é a diferença média em ações por 1.000 visualizações. O erro padrão é o de Welch; o valor de significância usa aproximação normal bilateral pela função `erfc`; a correção de Holm cobre os 970 termos com ao menos 100 publicações no grupo presente, com alfa 0,05. A análise é exploratória. O artefato estruturado registra por termo quantidade presente, médias presente e ausente, efeito, erro padrão, valor de significância bruto e ajustado e indicador após Holm.

## Guardião da Qualidade dos Dados

Estados internos possíveis:

- `APTO_PARA_DECISAO`
- `APTO_APENAS_PARA_EXPLORACAO`
- `INSUFICIENTE_PARA_DECISAO`
- `BLOQUEADO_POR_INTEGRIDADE`

Estado interno desta base: `INSUFICIENTE_PARA_DECISAO`. Rótulo visível: “INSUFICIENTE PARA DECISÃO”. Ela não é classificada como corrompida. O guardião combina estrutura de colunas, proveniência, identidade, unicidade, unidade, dispersão e covariância, eventos zero, atribuição e múltiplas comparações. Não existe limite universal de variância.

## Contrato de evidência

Toda seção factual visível carrega `data-claim-id` e um bloco expandível “Como sabemos” com fonte, método e limitação. O construtor exige que o texto permitido, o método, a limitação, o identificador de método executado e as interpretações proibidas do mapa sejam semanticamente válidos. Também exige seis itens na matriz e referências somente a afirmações registradas. Nomes de criadores, endereços brutos e linhas brutas não entram no HTML. A expressão visível permitida é “base de seguidores informada na publicação”.

## Experimentos

Os contratos permanecem `DESIGN_ONLY`. O menor efeito relevante para o negócio (SESOI) de +0,5 ponto percentual é explicitamente provisório. Qualquer teste ao vivo exige validação humana, plano de potência, tamanho amostral, unidade de randomização e limites de segurança. Esta geração apenas especifica o plano; não executa experimento.

## Interface e verificação de qualidade

- HTML autocontido, offline e em português do Brasil (pt-BR).
- Títulos e subtítulos empilhados.
- Tabelas com rolagem própria.
- Sem sobreposição em 390, 768, 1024, 1280 e 1440 px.
- Verificação adicional em ampliação de 125% e 150%.
- A verificação navega bytes locais por `file://`, compara o corpo ao SHA-256 do HTML, produz 30 capturas e reabre cada arquivo antes de revalidar SHA-256.
- Erros de console, página, rede externa, transbordamento horizontal e sobreposição devem ser zero.

## Processo e histórico

As gerações rejeitadas permanecem em `reports/` e na linha do tempo. A geração HTML `9181a874…` continua bloqueada com Schema Gate `FAIL`, nota `7,4/10`, decisão `BLOCK` e severidades `C0/H4/M2/L1`; a geração `c46cf0a` continua bloqueada por falta dos insumos no checkout. O checkpoint `687ca17` recebeu Schema Gate `PASS`, nota `10,0/10`, `C0/H0/M0/L0` e foi apresentado à validação humana. Thiago aprovou a direção e solicitou refinamentos visuais. O próximo passo estável é testar, reconstruir, executar QA e revisar autoritativamente a nova geração antes de substituir o checkpoint. Publicação, envio remoto, solicitação de integração, submissão e experimentos ao vivo seguem bloqueados.
