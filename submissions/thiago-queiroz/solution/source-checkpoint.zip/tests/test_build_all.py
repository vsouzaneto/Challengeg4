from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import math
import re
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "build_all.py"


def load_module():
    spec = importlib.util.spec_from_file_location("build_all", MODULE_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("unable to load build module")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class V2BuildTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module = load_module()
        cls.result = cls.module.build_all(ROOT)
        cls.data_bytes = (ROOT / "evidence/prototype-data.json").read_bytes()
        cls.html_bytes = (ROOT / "dist/index.html").read_bytes()
        cls.manifest_bytes = (ROOT / "evidence/build-manifest.json").read_bytes()
        cls.data = json.loads(cls.data_bytes)
        cls.html = cls.html_bytes.decode("utf-8")
        cls.manifest = json.loads(cls.manifest_bytes)

    def test_hero_states_dataset_size_and_decision(self):
        self.assertIn("52.214 publicações", self.html)
        self.assertIn("nenhum sinal decisório material", self.html.lower())
        for factor in ("plataforma", "formato", "categoria", "porte", "hashtag", "patrocínio", "audiência", "período"):
            self.assertIn(factor, self.html.lower())

    def test_baseline_per_thousand_views_is_exact(self):
        baseline = self.data["engagement"]["baseline_per_1000_views"]
        self.assertAlmostEqual(baseline["likes"], 149.5279329000731)
        self.assertAlmostEqual(baseline["shares"], 29.70396314419904)
        self.assertAlmostEqual(baseline["comments"], 19.802954965773363)
        self.assertAlmostEqual(baseline["depth_actions"], 49.5069181099724)
        for label in ("Exposição", "Reação", "Amplificação", "Conversa", "Ações de profundidade"):
            self.assertIn(label, self.html)
        self.assertNotIn("intenção emocional", self.html.lower())

    def test_required_engagement_cuts_are_present(self):
        cuts = self.data["engagement"]["cuts"]
        self.assertEqual(set(cuts), {"platform", "content_type", "content_category", "follower_band", "quarter"})
        self.assertEqual(len(cuts["platform"]), 5)
        self.assertEqual(len(cuts["content_type"]), 4)
        self.assertEqual(len(cuts["content_category"]), 3)
        self.assertEqual(len(cuts["follower_band"]), 5)
        self.assertEqual(len(cuts["quarter"]), 9)

    def test_artificial_distribution_period_quarter_range_and_zero_events(self):
        quality = self.data["distribution_quality"]
        self.assertEqual(quality["period"], ["2023-05-29", "2025-05-28"])
        self.assertEqual(quality["quarter_rate_range_percent"], [19.899268067913134, 19.907375491925944])
        self.assertEqual(quality["zero_rows"], {"views": 0, "likes": 0, "shares": 0, "comments": 0, "interactions": 0})
        self.assertIn("19,8993% e 19,9074%", self.html)
        self.assertIn("artificialmente estreita", self.html.lower())

    def test_creator_identity_exactly_blocks_influencer_inference(self):
        identity = self.data["creator_identity"]
        self.assertEqual(identity["creator_ids"], 5000)
        self.assertEqual(identity["multi_name_creator_ids"], 5000)
        self.assertEqual(identity["id_name_platform_keys"], 52214)
        self.assertEqual(identity["singleton_keys"], 52214)
        expected = {
            "Bilibili": [1013, 999998], "Instagram": [1023, 999920],
            "RedNote": [1069, 999986], "TikTok": [1014, 999899],
            "YouTube": [1156, 999896],
        }
        self.assertEqual(identity["reported_follower_base_range_by_platform"], expected)
        self.assertIn("registros, não influenciadores", self.html)
        self.assertNotIn("follower_count", self.html)
        self.assertIn("base de seguidores informada na publicação", self.html)

    def test_sponsorship_exact_counts_rates_and_url_reuse(self):
        sponsor = self.data["sponsorship"]
        self.assertEqual(sponsor["organic_n"], 29900)
        self.assertEqual(sponsor["sponsored_n"], 22314)
        self.assertAlmostEqual(sponsor["organic_rate_percent"], 19.9059116939728)
        self.assertAlmostEqual(sponsor["sponsored_rate_percent"], 19.904840339325382)
        self.assertAlmostEqual(sponsor["difference_pp"], -0.0010713546474185875)
        self.assertEqual(sponsor["url_reuse"], {"distinct_roots": 28037, "reused_roots": 6074, "rows_in_reused_roots": 30251, "mixed_flags": 4361})
        for text in ("29.900", "22.314", "19,9059%", "19,9048%", "−0,0011 pp", "ponto percentual", "28.037", "6.074", "30.251", "4.361"):
            self.assertIn(text, self.html)
        self.assertIn("Sem custo, receita ou retorno sobre investimento (ROI)", self.html)

    def test_audience_depth_action_amplitudes_are_exact(self):
        audience = self.data["audience"]
        self.assertAlmostEqual(audience["age_depth_amplitude_per_1000"], 0.049689680129787916)
        self.assertAlmostEqual(audience["gender_depth_amplitude_per_1000"], 0.022305811868584158)
        self.assertAlmostEqual(audience["location_depth_amplitude_per_1000"], 0.042970956468479926)
        self.assertIn("idade, gênero e localização", self.html.lower())

    def test_hashtag_multiple_comparison_result_is_exact(self):
        hashtags = self.data["hashtags"]
        self.assertEqual(
            {key: hashtags[key] for key in ("terms", "tested_n_gte_100", "survive_multiple_comparisons", "combinations", "unique_combinations")},
            {"terms": 971, "tested_n_gte_100": 970, "survive_multiple_comparisons": 0, "combinations": 35637, "unique_combinations": 34601},
        )
        for text in ("Termos encontrados", "971", "Termos testados", "970", "Sinais após correção estatística", "zero", "Combinações", "35.637", "34.601 únicas"):
            self.assertIn(text, self.html)
        self.assertNotIn("hashtags vencedoras", self.html.lower())

    def test_human_visual_review_refinements_are_rendered(self):
        process_section = self.html.split('<section id="processo-ia"', 1)[1].split("</section>", 1)[0]
        for event in self.data["process"]["events"]:
            self.assertIn(event["event_id"], process_section)
        self.assertIn("V2 aprovada tecnicamente", process_section)
        self.assertIn("refinamento visual solicitado por Thiago", process_section)

        for fragment in (
            ".card span,.card strong{display:block}",
            ".cards + .panel,.three + .panel{margin-top:18px}",
            ".cards + .two{margin-top:18px}",
            '<span>Orgânico</span><strong>19,9059%</strong><small>29.900 publicações</small>',
            '<span>Patrocinado</span><strong>19,9048%</strong><small>22.314 publicações</small>',
            '<span>Diferença</span><strong>−0,0011 pp</strong><small>ponto percentual; patrocinado menos orgânico</small>',
            '<span>Termos encontrados</span><strong>971</strong>',
            '<span>Termos testados</span><strong>970</strong><small>100 ou mais publicações</small>',
            '<span>Sinais após correção estatística</span><strong>zero</strong>',
            '<span>Combinações</span><strong>35.637</strong><small>34.601 únicas</small>',
        ):
            self.assertIn(fragment, self.html)

        captures = {(name, width, target) for name, width, _, target, _ in self.module.QA_CAPTURE_SPECS}
        for required in (
            ("desktop-distribution", 1440, "#qualidade-distribuicao"),
            ("mobile-distribution", 390, "#qualidade-distribuicao"),
            ("desktop-hashtags", 1440, "#hashtags"),
            ("mobile-hashtags", 390, "#hashtags"),
            ("desktop-process", 1440, "#processo-ia"),
            ("mobile-process", 390, "#processo-ia"),
        ):
            self.assertIn(required, captures)

    def test_strategy_has_three_monday_priorities_and_no_micro_creator_winner(self):
        for text in (
            "Congelar novas decisões apoiadas só na base sintética",
            "Instrumentar identificadores, rastreamento, eventos, custo e receita",
            "Desenhar experimento após plano de potência",
            "Nenhuma verba incremental é justificada só pela base sintética",
            "Não cortar operações sustentadas por evidência externa",
        ):
            self.assertIn(text, self.html)
        self.assertIn("Não escolher microcriadores como vencedores", self.html)
        self.assertNotIn("Priorizar micro creators", self.html)

    def test_executive_translation_and_flatline_visual_are_rendered(self):
        hashtag_section = self.html.split('<section id="hashtags"', 1)[1].split("</section>", 1)[0]
        main_panel = hashtag_section.split('<article class="panel danger">', 1)[1].split("</article>", 1)[0]
        self.assertIn("candidatos que podem parecer vencedores apenas pelo acaso", main_panel)
        self.assertIn("nenhum manteve evidência suficiente", main_panel)
        self.assertNotIn("por sorte", main_panel)
        self.assertNotIn("ruído estatístico", main_panel)
        for technical in ("Welch", "erfc", "aproximação normal bilateral", "correção de Holm"):
            self.assertNotIn(technical, main_panel)
        self.assertIn("Welch", hashtag_section)
        self.assertIn("correção de Holm", hashtag_section)

        self.assertIn("Custo de Aquisição de Cliente (CAC)", self.html)
        self.assertIn("RISCO ALTO: BASE INSUFICIENTE", self.html)
        self.assertIn("RISCO ALTO: IDENTIDADE NÃO RASTREÁVEL", self.html)
        self.assertNotIn("Não estimável", self.html)

        self.assertIn('class="flatline-chart"', self.html)
        self.assertIn("Eletrocardiograma quase plano", self.html)
        self.assertIn('viewBox="0 0 900 180"', self.html)
        self.assertEqual(self.html.count('class="quarter-point"'), 9)
        self.assertIn("Deslize para ver os 9 trimestres", self.html)
        self.assertIn("não prova simulação isoladamente", self.html)

        self.assertIn("investir em criadores de 10 mil a 50 mil seguidores", self.html)
        self.assertIn("não rastreia o histórico real de influência", self.html)
        self.assertIn("Nossa meta da semana não é descobrir qual publicação performou melhor em um passado irreal", self.html)
        self.assertIn("definir desfecho, amostra, potência e atribuição", self.html)
        self.assertIn("detectar, com desenho prospectivo, variações reais de pelo menos +0,5 pp caso existam", self.html)
        self.assertNotIn("qualquer variação real acima de +0,5 pp", self.html)
        strategy_section = self.html.split('<section id="estrategia"', 1)[1].split("</section>", 1)[0]
        self.assertNotIn('id="matriz-estrategica"', strategy_section)
        self.assertLess(len(strategy_section), 8000)

    def test_data_quality_gatekeeper_state_and_rules(self):
        gate = self.data["data_quality_gatekeeper"]
        self.assertEqual(gate["state"], "INSUFICIENTE_PARA_DECISAO")
        self.assertEqual(gate["states"], ["APTO_PARA_DECISAO", "APTO_APENAS_PARA_EXPLORACAO", "INSUFICIENTE_PARA_DECISAO", "BLOQUEADO_POR_INTEGRIDADE"])
        self.assertEqual(set(gate["rules"]), {"schema", "provenance", "identity", "uniqueness", "unit", "dispersion_covariance", "zero_events", "attribution", "multiple_comparisons"})
        self.assertFalse(gate["universal_variance_threshold"])
        self.assertIn("Não é base corrompida", self.html)
        self.assertNotIn("BLOQUEADO_POR_INTEGRIDADE</code>", self.html)

    def test_ai_evidence_rejected_generations_and_design_only_experiments(self):
        self.assertIn("Gerações rejeitadas", self.html)
        self.assertIn("geração 1", self.html.lower())
        self.assertIn("geração 2", self.html.lower())
        self.assertIn("Portão de Confiabilidade dos Dados", self.html)
        self.assertIn("Somente desenho", self.html)
        self.assertIn("SESOI): +0,5 ponto percentual (pp), provisório", self.html)

    def test_glossary_expands_all_required_terms(self):
        self.assertIn('id="glossario"', self.html)
        for term in ("Taxa de engajamento", "Ponto percentual", "SESOI", "UTM", "ROI", "ID", "IA"):
            self.assertIn(term, self.html)
        self.assertIn("menor efeito relevante", self.html.lower())

    def test_four_required_answers_and_strategy_exist(self):
        for section in ("o-que-gera-engajamento", "o-que-nao-funciona", "audiencia", "patrocinio", "estrategia"):
            self.assertIn(f'id="{section}"', self.html)

    def test_all_visible_fact_sections_are_claim_bound(self):
        for section in re.findall(r'<section[^>]+>', self.html):
            self.assertIn("data-claim-id=", section, section)
        registered = set(self.data["registered_claim_ids"])
        for attrs in re.findall(r'data-claim-id="([^"]+)"', self.html):
            self.assertTrue(set(attrs.split()).issubset(registered))

    def test_no_raw_names_urls_saves_or_bookmarks(self):
        lower = self.html.lower()
        for forbidden in ("creator_name", "content_url", "http://", "https://", "save", "bookmark"):
            self.assertNotIn(forbidden, lower)
        self.assertNotRegex(lower, r"creator_[0-9]+|content_[0-9]+")

    def test_offline_ptbr_self_contained_and_tables_scroll(self):
        lower = self.html.lower()
        self.assertIn('<html lang="pt-br">', lower)
        self.assertIn(".table-wrap{overflow-x:auto", re.sub(r"\s+", "", lower))
        for forbidden in ("<link", "<script src", "fetch(", "@import", "url("):
            self.assertNotIn(forbidden, lower)

    def test_responsive_contract_includes_required_widths_and_zoom_safe_layout(self):
        widths = {item[1] for item in self.module.QA_CAPTURE_SPECS}
        self.assertTrue({390, 768, 1024, 1280, 1440}.issubset(widths))
        self.assertTrue({125, 150}.issubset({item[4] for item in self.module.QA_CAPTURE_SPECS}))
        for token in ("max-width:1024px", "max-width:768px", "zoom"):
            self.assertIn(token, re.sub(r"\s+", "", self.html.lower()))
        self.assertIn("min-width:0", re.sub(r"\s+", "", self.html.lower()))
        self.assertNotIn("position:absolute", re.sub(r"\s+", "", self.html.lower()))

    def test_qa_contract_requires_named_desktop_intermediate_mobile_captures(self):
        expected = self.module.QA_CAPTURE_SPECS
        self.assertGreaterEqual(len(expected), 12)
        widths = {item[1] for item in expected}
        self.assertTrue({390, 768, 1024, 1280, 1440}.issubset(widths))
        targets = {item[3] for item in expected}
        self.assertTrue({"#hero", "#o-que-gera-engajamento", "#patrocinio", "#audiencia", "#estrategia", "#matriz-estrategica", "#gatekeeper"}.issubset(targets))
        names = {item[0] for item in expected}
        self.assertTrue({"wide-strategy-matrix", "intermediate-strategy-matrix"}.issubset(names))

    def test_screenshot_directory_matches_authenticated_inventory_exactly(self):
        expected = {f"{spec[0]}.png" for spec in self.module.QA_CAPTURE_SPECS}
        actual = {path.name for path in (ROOT / "reports/screenshots").glob("*.png")}
        self.assertEqual(actual, expected)

    def test_manifest_status_and_determinism(self):
        self.assertEqual(self.manifest["workflow_transition"], "EXECUTIVE_REFINEMENT_IMPLEMENTED_PENDING_REVIEW -> SKEPTIC_REMEDIATION_IMPLEMENTED_PENDING_REVIEW")
        self.assertEqual(self.manifest["build_status"], "SKEPTIC_REMEDIATION_IMPLEMENTED_PENDING_REVIEW")
        before = (self.data_bytes, self.html_bytes, self.manifest_bytes)
        self.module.build_all(ROOT)
        after = tuple((ROOT / p).read_bytes() for p in ("evidence/prototype-data.json", "dist/index.html", "evidence/build-manifest.json"))
        self.assertEqual(before, after)

    def test_standard_unittest_log_is_recognized_as_passed(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            evidence = root / "evidence"
            evidence.mkdir()
            (evidence / "test-results.txt").write_text(
                "test_example ... ok\n\n----------------------------------------------------------------------\nRan 45 tests in 9.933s\n\nOK\n",
                encoding="utf-8",
            )
            result = self.module._test_evidence(root)
            self.assertEqual(result["status"], "passed")
            self.assertEqual(result["tests_run"], 45)

    def test_qa_evidence_rejects_forged_or_missing_screenshot(self):
        specs = self.module.QA_CAPTURE_SPECS
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "reports/screenshots").mkdir(parents=True)
            records = []
            for index, (name, width, height, target, zoom) in enumerate(specs):
                path = root / f"reports/screenshots/{name}.png"
                path.write_bytes(b"png" + bytes([index]))
                records.append({"name": name, "width": width, "height": height, "target": target, "zoom_percent": zoom, "horizontal_overflow": False, "vertical_overlap": False, "screenshot_path": f"reports/screenshots/{name}.png", "screenshot_sha256": digest(path.read_bytes())})
            payload = {"schema_version": 2, "status": "PASSED", "index_html_sha256": "1"*64, "prototype_data_sha256": "2"*64, "reviewed_document_path": "dist/index.html", "reviewed_document_sha256": "1"*64, "browser": "chromium", "browser_version": "test", "console_errors": 0, "page_errors": 0, "external_network_requests": 0, "console_error_messages": [], "page_error_messages": [], "external_request_urls": [], "viewports": records}
            outputs = {"dist/index.html": "1"*64, "evidence/prototype-data.json": "2"*64}
            state = self.module.validate_qa_evidence(payload, outputs, "a"*64, root)
            self.assertEqual(len(state["screenshots"]), len(specs))
            forged = copy.deepcopy(payload)
            forged["viewports"][0]["screenshot_sha256"] = "f"*64
            with self.assertRaises(ValueError):
                self.module.validate_qa_evidence(forged, outputs, "a"*64, root)

    def test_outputs_are_size_bounded_and_hash_bound(self):
        self.assertLess(len(self.html_bytes), 5 * 1024 * 1024)
        self.assertLess(len(self.data_bytes), 1024 * 1024)
        self.assertEqual(self.manifest["outputs"]["dist/index.html"]["sha256"], digest(self.html_bytes))
        self.assertEqual(self.manifest["outputs"]["evidence/prototype-data.json"]["sha256"], digest(self.data_bytes))

    def test_h01_strategy_matrix_answers_all_six_operational_questions(self):
        decision_map = json.loads((ROOT / "evidence/decision-map.json").read_text(encoding="utf-8"))
        expected = {
            "onde_concentrar_esforco": "Instrumentação e qualidade dos dados.",
            "frequencia_de_postagem": "RISCO ALTO: BASE INSUFICIENTE.",
            "politica_de_patrocinio": "Nenhuma verba incremental apenas com esta base; não cortar ações sustentadas por evidência externa.",
            "perfil_e_threshold_de_influenciador": "RISCO ALTO: IDENTIDADE NÃO RASTREÁVEL; microcriador não é vencedor nesta base.",
            "o_que_parar": "Parar a caça a classificações e correlações aleatórias.",
            "quick_wins_desta_semana": "Criar identificadores estáveis, URL única com parâmetros UTM, eventos, custo e receita; especificar o plano de potência sem executar experimento.",
        }
        matrix = decision_map["strategy_matrix"]
        self.assertEqual({item["item"]: item["answer"] for item in matrix}, expected)
        self.assertEqual(len(matrix), 6)
        for item in matrix:
            self.assertTrue(item["evidence_or_limitation"].strip())
            self.assertIn(item["answer"], self.html)
        self.assertIn('id="matriz-estrategica"', self.html)

    def test_h02_hashtag_holm_results_are_computed_and_reproducible(self):
        hashtags = self.data["hashtags"]
        self.assertEqual(hashtags["method"], "welch_normal_two_sided_holm")
        self.assertEqual(hashtags["alpha"], 0.05)
        self.assertEqual(hashtags["tested_n_gte_100"], 970)
        self.assertEqual(len(hashtags["results"]), 970)
        required = {"term", "n_present", "mean_present", "mean_absent", "effect_per_1000", "standard_error_welch", "p_value", "p_holm", "significant_holm"}
        self.assertTrue(all(set(item) == required for item in hashtags["results"]))
        self.assertEqual(hashtags["survive_multiple_comparisons"], sum(item["significant_holm"] for item in hashtags["results"]))
        ordered = sorted(hashtags["results"], key=lambda item: (item["p_value"], item["term"]))
        running = 0.0
        m = len(ordered)
        for rank, item in enumerate(ordered, 1):
            expected_adjusted = min(1.0, max(running, (m - rank + 1) * item["p_value"]))
            self.assertAlmostEqual(item["p_holm"], expected_adjusted)
            running = expected_adjusted
        self.assertIn("aproximação normal bilateral", self.html.lower())
        self.assertIn("exploratória", self.html.lower())

    def test_h02_hashtag_welch_math_on_independent_synthetic_rows(self):
        values = [100.0, 200.0, 300.0, 400.0]
        rows = []
        for index, value in enumerate(values):
            rows.append({"interactions": value, "views": 1000.0, "hashtags": "alvo" if index < 2 else "outro"})
        result = self.module._hashtag_analysis(rows, minimum_present=2)["results"]
        target = next(item for item in result if item["term"] == "alvo")
        self.assertEqual(target["n_present"], 2)
        self.assertAlmostEqual(target["mean_present"], 150.0)
        self.assertAlmostEqual(target["mean_absent"], 350.0)
        self.assertAlmostEqual(target["effect_per_1000"], -200.0)
        expected_se = math.sqrt(5000.0 / 2.0 + 5000.0 / 2.0)
        self.assertAlmostEqual(target["standard_error_welch"], expected_se)
        self.assertAlmostEqual(target["p_value"], math.erfc(abs(-200.0 / expected_se) / math.sqrt(2.0)))

    def test_h03_thesis_is_bounded_to_descriptive_differences(self):
        forbidden = "não existe associação material, consistente e replicável"
        self.assertNotIn(forbidden, self.html.lower())
        self.assertNotIn(forbidden, json.dumps(self.data, ensure_ascii=False).lower())
        self.assertIn("diferenças descritivas pequenas", self.html.lower())
        self.assertIn("não sustentam decisões operacionais", self.html.lower())

    def test_h04_sponsorship_separates_raw_composite_from_adjusted_components(self):
        sponsor = self.data["sponsorship"]
        self.assertNotIn("adjusted_result", sponsor)
        self.assertEqual(set(sponsor["adjusted_components"]), {"views", "likes", "shares", "comments_count"})
        self.assertNotIn("taxa ajustada", self.html.lower())
        self.assertNotIn("o ajuste não muda", self.html.lower())
        for label in ("visualizações", "curtidas", "compartilhamentos", "comentários"):
            self.assertIn(label, self.html.lower())

    def test_m01_baseline_and_cuts_share_ratio_of_sums_estimand(self):
        engagement = self.data["engagement"]
        self.assertEqual(engagement["estimand"], "ratio_of_sums_per_1000_views")
        rows = self.module._read_rows(ROOT / "data/extracted/social_media_dataset.csv")
        baseline = engagement["baseline_per_1000_views"]
        for key, metric in (("likes", "likes"), ("shares", "shares"), ("comments", "comments_count"), ("depth_actions", "depth_actions")):
            self.assertAlmostEqual(baseline[key], self.module._ratio_per_1000(rows, metric))
        self.assertIn("razão das somas", self.html.lower())

    def test_m02_maps_are_semantically_enforced_by_builder(self):
        claims = json.loads((ROOT / "evidence/claim-evidence-map.json").read_text(encoding="utf-8"))
        self.module.validate_semantic_maps(claims, json.loads((ROOT / "evidence/decision-map.json").read_text(encoding="utf-8")), self.html)
        broken = copy.deepcopy(claims)
        broken["claims"][0]["allowed_text"] = "frase obrigatória ausente"
        with self.assertRaisesRegex(ValueError, "allowed_text"):
            self.module.validate_semantic_maps(broken, json.loads((ROOT / "evidence/decision-map.json").read_text(encoding="utf-8")), self.html)
        broken = copy.deepcopy(claims)
        broken["claims"][0]["method_id"] = "método_inexistente"
        with self.assertRaisesRegex(ValueError, "method_id"):
            self.module.validate_semantic_maps(broken, json.loads((ROOT / "evidence/decision-map.json").read_text(encoding="utf-8")), self.html)

    def test_l01_canonical_docs_use_ptbr_business_language(self):
        docs = "\n".join((ROOT / path).read_text(encoding="utf-8").lower() for path in ("README.md", "docs/prototype-scope.md"))
        for anglicism in ("fixture", "creator", "creators", "baseline", "views", "shares", "threshold", "runner", "screenshot", "social media", "p-hacking"):
            self.assertNotRegex(docs, rf"\b{re.escape(anglicism)}\b")

    def test_clean_checkout_manifest_binds_both_frozen_dataset_inputs(self):
        inputs = self.manifest["inputs"]
        expected = {
            "data/extracted/social_media_dataset.csv": "693a2df6e609d1c099f3430d9a5b894b224fe12b2420c0d93e6defe90d15f18e",
            "data/raw/social-media-sponsorship-and-engagement-dataset.zip": "ce78ea3352fe1ae6093e6f5d48b506ad591c6e6ca90fbab6ac91866a8c34202e",
        }
        for path, expected_hash in expected.items():
            self.assertTrue((ROOT / path).is_file())
            self.assertEqual(inputs[path]["sha256"], expected_hash)
        scope = (ROOT / "docs/prototype-scope.md").read_text(encoding="utf-8")
        self.assertIn("30 capturas", scope)
        self.assertNotIn("18 estados", scope)


if __name__ == "__main__":
    unittest.main()
