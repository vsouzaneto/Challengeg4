from __future__ import annotations

import importlib.util
import math
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "audit_dataset.py"
DATASET_PATH = ROOT / "data" / "extracted" / "social_media_dataset.csv"
ARCHIVE_PATH = ROOT / "data" / "raw" / "social-media-sponsorship-and-engagement-dataset.zip"
CHALLENGE_BRIEF_PATH = ROOT / "evidence" / "sources" / "challenge-004-README.md"
DATASET_METADATA_PATH = ROOT / "evidence" / "sources" / "kaggle-dataset-metadata.json"


def load_module():
    spec = importlib.util.spec_from_file_location("audit_dataset", MODULE_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("unable to load audit module")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class AuditMathTests(unittest.TestCase):
    def test_quantile_uses_linear_interpolation(self):
        module = load_module()
        self.assertEqual(module.quantile([0.0, 10.0], 0.25), 2.5)
        self.assertEqual(module.quantile([0.0, 10.0], 0.50), 5.0)

    def test_pearson_detects_perfect_linear_relationship(self):
        module = load_module()
        self.assertTrue(
            math.isclose(
                module.pearson([1.0, 2.0, 3.0], [2.0, 4.0, 6.0]),
                1.0,
                rel_tol=0.0,
                abs_tol=1e-12,
            )
        )

    def test_numeric_parser_rejects_non_finite_and_negative_values(self):
        module = load_module()
        with self.assertRaises(ValueError):
            module.parse_numeric_column([{"views": "nan"}], "views")
        with self.assertRaises(ValueError):
            module.parse_numeric_column([{"views": "-1"}], "views")

    def test_archive_validator_rejects_path_traversal(self):
        module = load_module()
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            csv_path = root / "social_media_dataset.csv"
            csv_path.write_text("x\n1\n", encoding="utf-8")
            archive_path = root / "unsafe.zip"
            with ZipFile(archive_path, "w") as archive:
                archive.writestr("../social_media_dataset.csv", csv_path.read_bytes())
            with self.assertRaises(ValueError):
                module.validate_archive(archive_path, csv_path)


class RealDatasetAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        module = load_module()
        cls.module = module
        cls.audit = module.build_audit(
            DATASET_PATH,
            ARCHIVE_PATH,
            CHALLENGE_BRIEF_PATH,
            DATASET_METADATA_PATH,
        )

    def test_archive_and_csv_are_cryptographically_bound(self):
        archive = self.audit["archive_validation"]
        self.assertEqual(archive["member_count"], 1)
        self.assertEqual(archive["member_name"], "social_media_dataset.csv")
        self.assertTrue(archive["crc_pass"])
        self.assertTrue(archive["safe_member_name"])
        self.assertTrue(archive["member_matches_csv_sha256"])
        self.assertLess(archive["expansion_ratio"], archive["hard_max_expansion_ratio"])

    def test_source_claims_are_derived_from_frozen_snapshots(self):
        source = self.audit["source"]
        self.assertEqual(source["dataset_version"], 1)
        self.assertEqual(source["license"], "MIT")
        self.assertTrue(source["metadata_declares_simulated"])
        self.assertTrue(source["challenge_mentions_engagement_rate"])
        self.assertEqual(
            source["challenge_brief_sha256"],
            "1a8d1879d8e2ffed9a5cd51b524663da237b2fc4133892e27de9bff29c9c3f87",
        )
        self.assertEqual(
            source["dataset_metadata_sha256"],
            "9f8e2fd522d039c76f509f41e23cdf5ab5c85969c732e630ec130ada7e88e2fd",
        )

    def test_audit_payload_is_content_deterministic(self):
        self.assertNotIn("generated_at_utc", self.audit)

    def test_dataset_identity_is_bound(self):
        self.assertEqual(self.audit["dataset"]["row_count"], 52_214)
        self.assertEqual(self.audit["dataset"]["column_count"], 27)
        self.assertEqual(
            self.audit["dataset"]["csv_sha256"],
            "693a2df6e609d1c099f3430d9a5b894b224fe12b2420c0d93e6defe90d15f18e",
        )
        self.assertEqual(
            self.audit["dataset"]["archive_sha256"],
            "ce78ea3352fe1ae6093e6f5d48b506ad591c6e6ca90fbab6ac91866a8c34202e",
        )

    def test_creator_entity_is_not_stable(self):
        integrity = self.audit["entity_integrity"]
        self.assertEqual(integrity["creator_ids_with_multiple_names"], 5_000)
        self.assertEqual(integrity["creator_id_count"], 5_000)
        self.assertGreater(integrity["median_follower_range_per_creator"], 800_000)

    def test_sponsorship_has_no_material_effect_in_generated_data(self):
        effects = self.audit["sponsorship_effects"]
        for metric in ("views", "likes", "shares", "comments_count"):
            self.assertLess(abs(effects[metric]["cohen_d"]), 0.01)
            low, high = effects[metric]["difference_ci95"]
            self.assertLessEqual(low, 0.0)
            self.assertGreaterEqual(high, 0.0)
            self.assertTrue(effects[metric]["equivalent_within_declared_sesoi"])

    def test_sponsorship_is_also_compared_with_required_adjustment(self):
        adjusted = self.audit["adjusted_sponsorship_effects"]
        self.assertEqual(
            adjusted["method"],
            "stratified standardization by platform, content_category and follower_band",
        )
        self.assertGreater(adjusted["eligible_strata"], 0)
        for metric in ("views", "likes", "shares", "comments_count"):
            self.assertIn("difference", adjusted["metrics"][metric])
            self.assertIn("difference_ci95", adjusted["metrics"][metric])

    def test_report_exposes_quality_evidence_and_narrows_language(self):
        report = self.module.render_markdown(self.audit)
        for heading in (
            "## Proveniência congelada",
            "## Missingness e consistência",
            "## Estrutura temporal",
            "## Spreads entre grupos",
            "## Patrocinado versus orgânico com ajuste",
        ):
            self.assertIn(heading, report)
        self.assertNotIn("efetivamente independentes", report.lower())
        self.assertEqual(report, self.module.render_markdown(self.audit))

    def test_frozen_source_hashes_fail_closed_on_byte_change(self):
        with tempfile.TemporaryDirectory() as temporary:
            changed_brief = Path(temporary) / "README.md"
            changed_brief.write_bytes(CHALLENGE_BRIEF_PATH.read_bytes() + b"\nchanged\n")
            with self.assertRaises(ValueError):
                self.module.load_source_evidence(changed_brief, DATASET_METADATA_PATH)


if __name__ == "__main__":
    unittest.main()
