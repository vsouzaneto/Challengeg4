# G4 AI Master Challenge 004 · V2

Narrativa executiva offline para desconstruir a base sintética de mídias sociais e transformar diferenças descritivas pequenas em um plano de medição, sem extrapolação operacional.

## Estado atual

```text
EXECUTIVE_REFINEMENT_IMPLEMENTED_PENDING_REVIEW -> SKEPTIC_REMEDIATION_IMPLEMENTED_PENDING_REVIEW
```

- 52.214 publicações auditadas.
- Estado interno do Guardião da Qualidade dos Dados: `INSUFICIENTE_PARA_DECISAO`; rótulo visível: “INSUFICIENTE PARA DECISÃO”.
- Nenhuma verba, criador, plataforma, formato, categoria, porte, hashtag, audiência, patrocínio ou período é recomendado como vencedor.
- Experimentos permanecem `DESIGN_ONLY`; o menor efeito relevante para o negócio (SESOI) de +0,5 ponto percentual (pp) é provisório.
- Gerações rejeitadas e evidências históricas foram preservadas.
- Publicação, submissão e ações externas permanecem bloqueadas.

## Respostas estratégicas

A matriz visível responde onde concentrar esforço, frequência de postagem, política de patrocínio, perfil e limiar de influenciador, o que parar e ganhos rápidos desta semana. O foco autorizado é instrumentação e qualidade. Frequência e perfil não são estimáveis. Nenhuma verba incremental é autorizada apenas por esta base, sem mandar cortar evidência externa. Microcriador não é vencedor. Deve-se parar a caça a classificações e correlações aleatórias. Os ganhos rápidos são identificadores estáveis, endereço único com parâmetros de rastreamento de campanha (UTM), eventos, custo, receita e especificação do plano de potência — sem executar experimento.

## Artefatos

- `scripts/build_all.py`: único construtor determinístico.
- `dist/index.html`: narrativa offline autocontida.
- `evidence/prototype-data.json`: projeção estruturada V2, incluindo resultados por termo da análise de hashtags.
- `evidence/claim-evidence-map.json`: afirmações, fontes, métodos e limitações.
- `evidence/decision-map.json`: respostas analíticas e matriz estratégica de seis itens.
- `evidence/process-timeline.json`: processo de inteligência artificial (IA) e gerações rejeitadas.
- `scripts/run_visual_qa.py`: verificação visual local por `file://` e autenticação das capturas.
- `evidence/build-manifest.json`: impressões digitais, comandos e estado.

## Reprodução

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest discover -v
PYTHONDONTWRITEBYTECODE=1 python3 -B scripts/build_all.py
PYTHONDONTWRITEBYTECODE=1 /usr/local/lib/hermes-agent/venv/bin/python -B scripts/run_visual_qa.py --root .
```

A verificação visual cobre 390, 768, 1024, 1280 e 1440 px, além de ampliação de 125% e 150%. Ela exige zero erro de console, página ou rede; zero transbordamento; zero sobreposição; reabre as 30 capturas, incluindo matriz estratégica, identidade, eventos zero, patrocínio, audiência, hashtags e processo de IA em desktop e celular, e recalcula suas impressões digitais SHA-256.

## Limites

A fonte declara simulação. O HTML não contém nomes de criadores, endereços brutos, linhas brutas ou métricas de salvamento. Não há custo, receita ou atribuição para calcular retorno sobre investimento (ROI). A comparação bruta de patrocínio preserva 19,9048% versus 19,9059%, diferença de −0,0011 ponto percentual; a auditoria ajustada cobre somente visualizações, curtidas, compartilhamentos e comentários, não uma taxa composta. O próximo passo é revisão humana e cética dos bytes V2 atuais, não publicação.
